export type ExtensibleString<T extends string> = T | (string & {});

export type StartupModelMode = ExtensibleString<"BEDROCK" | "GROQ" | "DEMO_FALLBACK">;

export interface ProviderMetadata {
  mode: StartupModelMode;
  model_id: string | null;
  attempts?: number;
  duration_ms?: number;
  input_tokens?: number | null;
  output_tokens?: number | null;
  total_tokens?: number | null;
}

export interface ProgressCounts {
  answered: number;
  total: number;
  percent?: number;
}

export type StartupProgress = number | ProgressCounts;

export type AnalysisJobStatus = ExtensibleString<
  | "QUEUED"
  | "UPLOADING"
  | "EXTRACTING"
  | "ANALYSING"
  | "PROCESSING"
  | "COMPLETED"
  | "PARTIAL"
  | "FAILED"
  | "CANCELLED"
>;

export interface AnalysisJob {
  id: string;
  status: AnalysisJobStatus;
  progress?: StartupProgress;
  analysis_id?: string | null;
  stage?: string | null;
  message?: string | null;
  error?: AnalysisJobError | string | null;
  created_at?: string;
  updated_at?: string;
  [key: string]: unknown;
}

export interface AnalysisJobError {
  code: string;
  message: string;
}

export interface SourceReference {
  document?: string;
  page: number | null;
  section: string | null;
  snippet: string;
}

interface SourcedAnalysisItem {
  source: SourceReference;
  sources?: SourceReference[];
}

export interface TenderProductFeature extends SourcedAnalysisItem {
  id: string;
  title: string;
  plain_english: string;
  obligation_level: TenderObligationLevel;
  acceptance_criteria: string[];
}

export interface TenderDeliveryPhase extends SourcedAnalysisItem {
  id: string;
  sequence: number | null;
  name: string;
  deliverables: string[];
  timing: string | null;
  due_at: string | null;
  timezone?: string | null;
}

export interface TenderPaymentMilestone extends SourcedAnalysisItem {
  id: string;
  milestone: string;
  trigger: string;
  amount: string | null;
  timing: string | null;
  due_at: string | null;
  timezone?: string | null;
}

export type TenderObligationLevel = "MANDATORY" | "SCORED" | "OPTIONAL" | "UNCLEAR";

export type TenderDeadlineKind = ExtensibleString<
  | "CLARIFICATION"
  | "SUBMISSION"
  | "BID_BOND"
  | "BRIEFING"
  | "DELIVERY"
  | "PAYMENT"
  | "SITE_VISIT"
  | "OTHER"
>;

export type TenderConfidence = "HIGH" | "MEDIUM" | "LOW";

export interface TenderDeadline extends SourcedAnalysisItem {
  id: string;
  kind: TenderDeadlineKind;
  title: string;
  date_text: string;
  deadline_at: string | null;
  all_day: boolean;
  timezone: string;
  confidence: TenderConfidence;
  needs_review: boolean;
}

export interface TenderEligibilityRequirement extends SourcedAnalysisItem {
  id: string;
  title: string;
  plain_english: string;
  obligation_level: TenderObligationLevel;
}

export interface StartupChecklistItem {
  id: string;
  title: string;
  description: string;
  category: string;
  priority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  due_at: string | null;
  supporting_fact_ids: string[];
  sources?: SourceReference[];
}

export interface TenderRisk extends SourcedAnalysisItem {
  id: string;
  title: string;
  plain_english: string;
  mitigation: string | null;
}

export interface TenderGlossaryItem extends SourcedAnalysisItem {
  term: string;
  plain_english: string;
}

export interface TenderAnalysis {
  id: string;
  mode: StartupModelMode;
  model_id: string | null;
  document: {
    filename: string;
    media_type: string;
    page_count: number | null;
    character_count: number;
    sha256: string;
    scanned_pages: number[];
  };
  overview: {
    tender_title: string | null;
    agency: string | null;
    reference_number: string | null;
    summary: string;
    buyer_goal: string;
  };
  product_features: TenderProductFeature[];
  delivery_phases: TenderDeliveryPhase[];
  payment_milestones: TenderPaymentMilestone[];
  deadlines: TenderDeadline[];
  eligibility_requirements: TenderEligibilityRequirement[];
  startup_checklist: StartupChecklistItem[];
  risks: TenderRisk[];
  clarification_questions: string[];
  glossary: TenderGlossaryItem[];
  warnings: string[];
  human_review_required: boolean;
  [key: string]: unknown;
}

export interface CreateAnalysisJobInput {
  file: File;
  timezone: string;
}

export type ProposalSectionKey = ExtensibleString<
  | "SOLUTION"
  | "TECHNICAL_ARCHITECTURE"
  | "DELIVERY"
  | "SECURITY_PRIVACY"
  | "TEAM_GOVERNANCE"
  | "SERVICE_SUPPORT"
  | "RISK_CONTINUITY"
  | "COMMERCIAL"
  | "OTHER"
>;

export interface ProposalQuestion {
  id: string;
  section: ProposalSectionKey;
  question: string;
  why_it_matters: string;
  answer_guidance: string[];
  required: boolean;
  context_refs: string[];
}

export interface ProposalAnswer {
  question_id: string;
  section: ProposalSectionKey;
  question: string;
  raw_answer: string;
  formalized_answer: string;
  context_refs: string[];
}

export type ProposalFeedbackVerdict = ExtensibleString<
  "STRONG" | "NEEDS_DETAIL" | "RISKY_CLAIM"
>;

export interface ProposalFeedback {
  question_id: string;
  verdict: ProposalFeedbackVerdict;
  mentor_feedback: string;
  strengths: string[];
  gaps: string[];
  formalized_answer: string;
  answer_quotes: string[];
  evidence_needed: string[];
  unsupported_claims: string[];
  context_refs: string[];
  needs_follow_up: boolean;
  follow_up_question: string | null;
}

export interface GroundedProposalParagraph {
  text: string;
  supporting_answer_ids: string[];
  context_refs: string[];
}

export interface ProposalDraftSection {
  section_key: ProposalSectionKey;
  heading: string;
  paragraphs: GroundedProposalParagraph[];
}

export interface ProposalRequirementCoverage {
  context_ref: string;
  status: string;
  section_keys: ProposalSectionKey[];
  explanation: string;
}

export interface ProposalOpenItem {
  text: string;
  related_answer_ids: string[];
  context_refs: string[];
}

export interface ProposalDraft {
  title: string;
  executive_summary: GroundedProposalParagraph[];
  sections: ProposalDraftSection[];
  requirement_coverage: ProposalRequirementCoverage[];
  open_items: ProposalOpenItem[];
  review_notice: string;
  markdown: string;
}

export type ProposalSessionStatus = ExtensibleString<
  "IN_PROGRESS" | "READY" | "GENERATED"
>;

export interface ProposalSession extends ProviderMetadata {
  id: string;
  analysis_id: string;
  company_name: string;
  solution_name: string;
  status: ProposalSessionStatus;
  revision: number;
  progress: StartupProgress;
  current_question: ProposalQuestion | null;
  questions: ProposalQuestion[];
  answers: ProposalAnswer[];
  last_feedback: ProposalFeedback | null;
  draft: ProposalDraft | null;
  created_at?: string;
  updated_at?: string;
  [key: string]: unknown;
}

export interface CreateProposalSessionInput {
  analysis_id: string;
  company_name: string;
  solution_name: string;
}

export interface SubmitProposalAnswerInput {
  question_id: string;
  answer: string;
  revision: number;
}

export interface GenerateProposalInput {
  revision: number;
}

export interface CalendarStatus {
  provider: ExtensibleString<"GOOGLE">;
  configured: boolean;
  connected: boolean;
  account_email: string | null;
  reauthorization_required: boolean;
  scope?: string | null;
  ics_available: boolean;
  message: string;
  authorization_required?: boolean;
  [key: string]: unknown;
}

export interface CalendarDeadlineOverride {
  deadline_id: string;
  deadline_at?: string | null;
  all_day?: boolean | null;
  timezone?: string | null;
  title?: string | null;
  confirmed: boolean;
  reminder_minutes?: number[] | null;
  reminders?: CalendarReminder[] | null;
  attendees?: string[] | null;
}

export interface CalendarReminder {
  method: "popup" | "email";
  minutes: number;
}

export interface SyncCalendarInput {
  deadline_ids: string[];
  reminder_minutes?: number[];
  attendees?: string[];
  calendar_id?: string;
  deadline_overrides?: CalendarDeadlineOverride[];
  reminders?: CalendarReminder[];
}

export type CalendarSyncEventStatus = ExtensibleString<
  "CREATED" | "UPDATED" | "UNCHANGED" | "SKIPPED" | "FAILED"
>;

export interface CalendarSyncEvent {
  deadline_id: string;
  status: CalendarSyncEventStatus;
  event_id: string | null;
  event_link: string | null;
  payload_hash: string | null;
  html_link?: string | null;
  error: string | null;
  [key: string]: unknown;
}

export interface CalendarSyncResponse {
  status: ExtensibleString<"COMPLETE" | "PARTIAL" | "FAILED">;
  calendar_id: string;
  results: CalendarSyncEvent[];
  analysis_id?: string;
  synced_count?: number;
  skipped_count?: number;
  events?: CalendarSyncEvent[];
  warnings?: string[];
  [key: string]: unknown;
}

export interface CalendarDeadlineState {
  deadline_id: string;
  calendar_id: string;
  override: CalendarDeadlineOverride | null;
  reminders: CalendarReminder[] | null;
  attendees: string[] | null;
  event_id: string | null;
  event_link: string | null;
  payload_hash: string | null;
  status: CalendarSyncEventStatus | null;
  last_synced_at: string | null;
}

export interface CalendarAnalysisState {
  analysis_id: string;
  calendar_id: string;
  deadlines: CalendarDeadlineState[];
}

export type CalendarSyncResult = CalendarSyncResponse;
export type AnalysisDeadline = TenderDeadline;
