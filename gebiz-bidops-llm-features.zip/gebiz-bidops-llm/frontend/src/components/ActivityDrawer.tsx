import { Activity, ChevronRight, History, X } from "lucide-react";
import { useEffect, useRef, type KeyboardEvent } from "react";
import type { ActivityEvent } from "../types/bid";

function eventLabel(eventType: string) {
  return eventType
    .toLowerCase()
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function formatTime(value: string) {
  return new Intl.DateTimeFormat("en-SG", {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Singapore",
    hour12: false,
  }).format(new Date(/[zZ]|[+-]\d{2}:\d{2}$/.test(value) ? value : `${value}Z`));
}

interface ActivityDrawerProps {
  open: boolean;
  onClose: () => void;
  events: ActivityEvent[];
}

export function ActivityDrawer({ open, onClose, events }: ActivityDrawerProps) {
  const drawerRef = useRef<HTMLElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    previousFocusRef.current = document.activeElement as HTMLElement | null;
    window.setTimeout(() => closeRef.current?.focus(), 0);
    return () => previousFocusRef.current?.focus();
  }, [open]);

  function handleKeyDown(event: KeyboardEvent<HTMLElement>) {
    if (event.key === "Escape") {
      event.preventDefault();
      onClose();
      return;
    }
    if (event.key !== "Tab") return;
    const focusable = [...(drawerRef.current?.querySelectorAll<HTMLElement>(
      'button:not(:disabled), a[href], input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])',
    ) ?? [])];
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable.at(-1)!;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  }

  if (!open) return null;

  return (
    <>
      <div
        aria-hidden="true"
        className="drawer-backdrop open"
        onClick={onClose}
      />
      <aside
        ref={drawerRef}
        className="activity-drawer open"
        role="dialog"
        aria-modal="true"
        aria-labelledby="activity-drawer-title"
        onKeyDown={handleKeyDown}
      >
        <div className="drawer-header">
          <div>
            <span className="eyebrow">What changed</span>
            <h2 id="activity-drawer-title">Audit trail</h2>
          </div>
          <button ref={closeRef} className="icon-button" onClick={onClose} aria-label="Close activity drawer">
            <X size={19} />
          </button>
        </div>
        <div className="drawer-note">
          <History size={17} />
          <p>Each entry records what changed, when it changed, and which bid item was affected.</p>
        </div>
        <div className="activity-timeline">
          {events.map((event, index) => (
            <article key={event.id} className="activity-event">
              <div className="activity-rail">
                <span className={index < 3 ? "recent" : ""}>
                  <Activity size={11} />
                </span>
              </div>
              <time>{formatTime(event.timestamp)}</time>
              <div>
                <span className="activity-type">{eventLabel(event.event_type)}</span>
                <p>{event.summary}</p>
                {event.entity_id && (
                  <small>
                    {event.entity_id} <ChevronRight size={11} />
                  </small>
                )}
              </div>
            </article>
          ))}
        </div>
      </aside>
    </>
  );
}
