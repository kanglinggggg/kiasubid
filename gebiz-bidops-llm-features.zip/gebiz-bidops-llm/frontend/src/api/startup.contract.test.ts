import { afterEach, describe, expect, it, vi } from "vitest";

import { startupApi } from "./startup";

function jsonResponse(payload: unknown, status = 200, statusText = "OK") {
  return new Response(JSON.stringify(payload), {
    status,
    statusText,
    headers: { "Content-Type": "application/json" },
  });
}

describe("startupApi", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
  });

  it("uploads the raw file with encoded metadata, its media type, and the supplied signal", async () => {
    const job = {
      id: "JOB-001",
      status: "QUEUED",
      stage: "Queued",
      progress: 0,
      analysis_id: null,
      error: null,
    };
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(jsonResponse(job, 202, "Accepted"));
    vi.stubGlobal("fetch", fetchMock);
    const file = new File(["Tender requirements"], "ITT & ITQ #17.pdf", {
      type: "application/pdf",
    });
    const controller = new AbortController();

    await expect(
      startupApi.createAnalysisJob(
        { file, timezone: "Asia/Singapore" },
        controller.signal,
      ),
    ).resolves.toEqual(job);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [requestTarget, init] = fetchMock.mock.calls[0]!;
    const requestUrl = new URL(String(requestTarget), "https://bidops.example");
    const headers = new Headers(init?.headers);

    expect(requestUrl.pathname).toBe("/api/startup/analysis-jobs");
    expect(requestUrl.searchParams.get("filename")).toBe(file.name);
    expect(requestUrl.searchParams.get("timezone")).toBe("Asia/Singapore");
    expect(init?.method).toBe("POST");
    expect(init?.body).toBe(file);
    expect(init?.signal).toBe(controller.signal);
    expect(headers.get("Content-Type")).toBe("application/pdf");
    expect(headers.get("Accept")).toBe("application/json");
  });

  it("returns the ICS response as a blob and forwards cancellation", async () => {
    const calendar = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nEND:VCALENDAR\r\n";
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(
      new Response(calendar, { headers: { "Content-Type": "text/calendar" } }),
    );
    vi.stubGlobal("fetch", fetchMock);
    const controller = new AbortController();

    const blob = await startupApi.downloadCalendarIcs("ANALYSIS / 7", controller.signal);

    expect(blob.type).toContain("text/calendar");
    expect(blob.size).toBeGreaterThan(0);
    const [requestTarget, init] = fetchMock.mock.calls[0]!;
    expect(requestTarget).toBe("/api/startup/analyses/ANALYSIS%20%2F%207/calendar.ics");
    expect(init?.signal).toBe(controller.signal);
    expect(new Headers(init?.headers).get("Accept")).toBe("text/calendar");
  });

  it("loads connection-scoped calendar state for an encoded analysis id", async () => {
    const state = { analysis_id: "ANALYSIS / 7", calendar_id: "primary", deadlines: [] };
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(jsonResponse(state));
    vi.stubGlobal("fetch", fetchMock);
    const controller = new AbortController();

    await expect(
      startupApi.getCalendarState("ANALYSIS / 7", controller.signal),
    ).resolves.toEqual(state);

    const [requestTarget, init] = fetchMock.mock.calls[0]!;
    expect(requestTarget).toBe(
      "/api/startup/analyses/ANALYSIS%20%2F%207/calendar/state",
    );
    expect(init?.signal).toBe(controller.signal);
    expect(new Headers(init?.headers).get("Accept")).toBe("application/json");
  });

  it("turns validation payloads into an ApiError callers can present", async () => {
    const fetchMock = vi.fn<typeof fetch>().mockResolvedValue(
      jsonResponse(
        {
          detail: [
            {
              loc: ["query", "timezone"],
              msg: "Input should be a valid IANA time-zone name",
              type: "value_error",
            },
          ],
        },
        422,
        "Unprocessable Entity",
      ),
    );
    vi.stubGlobal("fetch", fetchMock);

    const request = startupApi.getAnalysisJob("JOB-INVALID");

    await expect(request).rejects.toMatchObject({
      name: "ApiError",
      status: 422,
      message: "query.timezone: Input should be a valid IANA time-zone name",
    });
  });
});
