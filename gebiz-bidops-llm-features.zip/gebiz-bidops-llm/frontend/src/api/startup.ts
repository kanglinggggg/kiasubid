import type {
  AnalysisJob,
  CalendarAnalysisState,
  CalendarStatus,
  CalendarSyncResponse,
  CreateAnalysisJobInput,
  CreateProposalSessionInput,
  GenerateProposalInput,
  ProposalSession,
  SubmitProposalAnswerInput,
  SyncCalendarInput,
  TenderAnalysis,
} from "../types/startup";

const STARTUP_API_ROOT = "/api/startup";

export const GOOGLE_CALENDAR_AUTHORIZE_URL = `${STARTUP_API_ROOT}/calendar/google/authorize`;

export class ApiError extends Error {
  readonly status: number;
  readonly details: unknown;

  constructor(message: string, status: number, details: unknown = null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

function cleanServerText(value: string) {
  const withoutMarkup = value.replace(/<[^>]*>/g, " ");
  return withoutMarkup.replace(/\s+/g, " ").trim().slice(0, 800);
}

function validationMessage(value: unknown): string | null {
  if (typeof value === "string") {
    return cleanServerText(value) || null;
  }

  if (!value || typeof value !== "object") {
    return null;
  }

  const record = value as Record<string, unknown>;
  const message = record.msg ?? record.message ?? record.detail ?? record.error ?? record.title;
  if (typeof message !== "string") {
    return null;
  }

  const location = Array.isArray(record.loc)
    ? record.loc.filter((part) => typeof part === "string" || typeof part === "number").join(".")
    : "";
  const cleanMessage = cleanServerText(message);
  return location && cleanMessage ? `${location}: ${cleanMessage}` : cleanMessage || null;
}

function errorMessage(payload: unknown, response: Response) {
  if (Array.isArray(payload)) {
    const messages = payload.map(validationMessage).filter((item): item is string => Boolean(item));
    if (messages.length) return messages.join("; ");
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    if (Array.isArray(record.detail)) {
      const messages = record.detail
        .map(validationMessage)
        .filter((item): item is string => Boolean(item));
      if (messages.length) return messages.join("; ");
    }

    for (const candidate of [record.detail, record.message, record.error, record.title]) {
      const message = validationMessage(candidate);
      if (message) return message;
    }
  }

  const directMessage = validationMessage(payload);
  if (directMessage) return directMessage;

  return response.statusText
    ? `Request failed with status ${response.status}: ${response.statusText}.`
    : `Request failed with status ${response.status}.`;
}

async function readPayload(response: Response): Promise<unknown> {
  const text = await response.text();
  if (!text.trim()) return null;

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return cleanServerText(text);
  }
}

function headersWithAccept(init: RequestInit, accept: string) {
  const headers = new Headers(init.headers);
  if (!headers.has("Accept")) headers.set("Accept", accept);
  return headers;
}

async function requestJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: headersWithAccept(init, "application/json"),
  });
  const payload = await readPayload(response);

  if (!response.ok) {
    throw new ApiError(errorMessage(payload, response), response.status, payload);
  }

  if (payload === null) return undefined as T;
  if (typeof payload === "string") {
    throw new ApiError("The server returned an invalid JSON response.", response.status, payload);
  }
  return payload as T;
}

function postJson<TResponse>(path: string, payload: unknown, signal?: AbortSignal) {
  return requestJson<TResponse>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal,
  });
}

async function requestBlob(path: string, signal?: AbortSignal) {
  const response = await fetch(path, {
    headers: { Accept: "text/calendar" },
    signal,
  });

  if (!response.ok) {
    const payload = await readPayload(response);
    throw new ApiError(errorMessage(payload, response), response.status, payload);
  }

  return response.blob();
}

function resourceId(value: string) {
  return encodeURIComponent(value);
}

function uploadContentType(file: File) {
  if (file.type) return file.type;
  const extension = file.name.toLowerCase().split(".").at(-1);
  if (extension === "pdf") return "application/pdf";
  if (extension === "docx") {
    return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  }
  if (extension === "md" || extension === "markdown") return "text/markdown";
  if (extension === "txt") return "text/plain";
  return "application/octet-stream";
}

export const startupApi = {
  createAnalysisJob(input: CreateAnalysisJobInput, signal?: AbortSignal) {
    const query = new URLSearchParams({
      filename: input.file.name,
      timezone: input.timezone,
    });

    return requestJson<AnalysisJob>(`${STARTUP_API_ROOT}/analysis-jobs?${query.toString()}`, {
      method: "POST",
      headers: {
        "Content-Type": uploadContentType(input.file),
      },
      body: input.file,
      signal,
    });
  },

  getAnalysisJob(jobId: string, signal?: AbortSignal) {
    return requestJson<AnalysisJob>(
      `${STARTUP_API_ROOT}/analysis-jobs/${resourceId(jobId)}`,
      { signal },
    );
  },

  getAnalysis(analysisId: string, signal?: AbortSignal) {
    return requestJson<TenderAnalysis>(
      `${STARTUP_API_ROOT}/analyses/${resourceId(analysisId)}`,
      { signal },
    );
  },

  createProposalSession(input: CreateProposalSessionInput, signal?: AbortSignal) {
    return postJson<ProposalSession>(`${STARTUP_API_ROOT}/proposal-sessions`, input, signal);
  },

  getProposalSession(sessionId: string, signal?: AbortSignal) {
    return requestJson<ProposalSession>(
      `${STARTUP_API_ROOT}/proposal-sessions/${resourceId(sessionId)}`,
      { signal },
    );
  },

  submitProposalAnswer(
    sessionId: string,
    input: SubmitProposalAnswerInput,
    signal?: AbortSignal,
  ) {
    return postJson<ProposalSession>(
      `${STARTUP_API_ROOT}/proposal-sessions/${resourceId(sessionId)}/answers`,
      input,
      signal,
    );
  },

  generateProposal(
    sessionId: string,
    input: GenerateProposalInput,
    signal?: AbortSignal,
  ) {
    return postJson<ProposalSession>(
      `${STARTUP_API_ROOT}/proposal-sessions/${resourceId(sessionId)}/generate`,
      input,
      signal,
    );
  },

  getCalendarStatus(signal?: AbortSignal) {
    return requestJson<CalendarStatus>(`${STARTUP_API_ROOT}/calendar/status`, { signal });
  },

  getCalendarState(analysisId: string, signal?: AbortSignal) {
    return requestJson<CalendarAnalysisState>(
      `${STARTUP_API_ROOT}/analyses/${resourceId(analysisId)}/calendar/state`,
      { signal },
    );
  },

  getGoogleCalendarAuthorizationUrl() {
    return GOOGLE_CALENDAR_AUTHORIZE_URL;
  },

  downloadCalendarIcs(analysisId: string, signal?: AbortSignal) {
    return requestBlob(
      `${STARTUP_API_ROOT}/analyses/${resourceId(analysisId)}/calendar.ics`,
      signal,
    );
  },

  syncCalendar(analysisId: string, input: SyncCalendarInput, signal?: AbortSignal) {
    return postJson<CalendarSyncResponse>(
      `${STARTUP_API_ROOT}/analyses/${resourceId(analysisId)}/calendar/sync`,
      input,
      signal,
    );
  },
};
