import { Rocket, Shield, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { BidControlRoom } from "./views/BidControlRoom";
import { StartupStudio } from "./views/startup/StartupStudio";

type WorkspaceMode = "sme" | "startup";

function modeFromHash(): WorkspaceMode {
  return window.location.hash.startsWith("#startup") ? "startup" : "sme";
}

function App() {
  const [mode, setMode] = useState<WorkspaceMode>(modeFromHash);

  useEffect(() => {
    const handleHashChange = () => setMode(modeFromHash());
    window.addEventListener("hashchange", handleHashChange);
    window.addEventListener("popstate", handleHashChange);
    return () => {
      window.removeEventListener("hashchange", handleHashChange);
      window.removeEventListener("popstate", handleHashChange);
    };
  }, []);

  function selectMode(nextMode: WorkspaceMode) {
    setMode(nextMode);
    const nextHash = nextMode === "startup" ? "#startup/decipher" : "#sme";
    if (window.location.hash !== nextHash) window.history.pushState(null, "", nextHash);
  }

  return (
    <div className="product-shell">
      <a className="skip-link" href="#workspace-content">
        Skip to workspace
      </a>
      <nav className="app-modebar" aria-label="GeBIZ BidOps workspace">
        <div className="brand-lockup">
          <span className="brand-mark" aria-hidden="true">
            <Shield size={18} />
          </span>
          <div>
            <strong>GeBIZ BidOps</strong>
            <small>Supplier-side bid control</small>
          </div>
        </div>
        <div className="workspace-mode-switch" role="group" aria-label="Choose workspace">
          <button
            type="button"
            className={mode === "sme" ? "active" : ""}
            aria-pressed={mode === "sme"}
            aria-label="SME Control Room"
            onClick={() => selectMode("sme")}
          >
            <ShieldCheck size={15} />
            <span>SME Control Room</span>
          </button>
          <button
            type="button"
            className={mode === "startup" ? "active" : ""}
            aria-pressed={mode === "startup"}
            aria-label="Startup Studio"
            onClick={() => selectMode("startup")}
          >
            <Rocket size={15} />
            <span>Startup Studio</span>
          </button>
        </div>
      </nav>
      <div id="workspace-content" tabIndex={-1}>
        {mode === "sme" ? <BidControlRoom /> : <StartupStudio />}
      </div>
    </div>
  );
}

export default App;
