import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  BookOpen,
  CalendarClock,
  CalendarPlus,
  Check,
  CheckCircle2,
  ClipboardCheck,
  Clock3,
  Copy,
  Download,
  ExternalLink,
  FileCheck2,
  FileText,
  HelpCircle,
  ListChecks,
  LoaderCircle,
  MessageSquare,
  RefreshCcw,
  Rocket,
  Send,
  Sparkles,
  Upload,
  WalletCards,
  X,
} from "lucide-react";
import {
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
  type FormEvent,
  type KeyboardEvent,
} from "react";
import { ApiError, startupApi } from "../../api/startup";
import type {
  AnalysisJob,
  CalendarDeadlineState,
  CalendarStatus,
  CalendarSyncResponse,
  ProposalDraft,
  ProposalSession,
  SourceReference,
  TenderAnalysis,
  TenderDeadline,
} from "../../types/startup";

type StudioTab = "decipher" | "proposal" | "milestones";

const tabOrder: StudioTab[] = ["decipher", "proposal", "milestones"];
const ANALYSIS_STORAGE_KEY = "gebiz-bidops.startup.analysis-id";
const SESSION_STORAGE_KEY = "gebiz-bidops.startup.proposal-session-id";
export const PROPOSAL_ANSWER_MAX_CHARACTERS = 4_000;

function activeTabFromHash(): StudioTab {
  const match = window.location.hash.match(/^#startup\/(decipher|proposal|milestones)/);
  return (match?.[1] as StudioTab | undefined) ?? "decipher";
}

function analysisIdFromHash() {
  const queryStart = window.location.hash.indexOf("?");
  if (queryStart < 0) return null;
  return new URLSearchParams(window.location.hash.slice(queryStart + 1)).get("analysis");
}

function errorMessage(reason: unknown, fallback: string) {
  if (reason instanceof ApiError || reason instanceof Error) return reason.message;
  return fallback;
}

function isAbort(reason: unknown) {
  return reason instanceof DOMException && reason.name === "AbortError";
}

function jobError(job: AnalysisJob) {
  if (typeof job.error === "string") return job.error;
  if (job.error && typeof job.error.message === "string") return job.error.message;
  return job.message || "The document could not be analysed.";
}

function delay(milliseconds: number, signal: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    const abort = () => {
      window.clearTimeout(timer);
      reject(new DOMException("The operation was cancelled.", "AbortError"));
    };
    const timer = window.setTimeout(() => {
      signal.removeEventListener("abort", abort);
      resolve();
    }, milliseconds);
    signal.addEventListener("abort", abort, { once: true });
  });
}

function normalizedProgress(progress: AnalysisJob["progress"] | ProposalSession["progress"]) {
  if (typeof progress === "number") return Math.max(0, Math.min(100, progress));
  if (progress && typeof progress === "object") {
    if (typeof progress.percent === "number") {
      return Math.max(0, Math.min(100, progress.percent));
    }
    if (progress.total > 0) return Math.round((progress.answered / progress.total) * 100);
  }
  return 0;
}

function providerLabel(mode: string | null | undefined) {
  if (!mode) return "Awaiting analysis";
  if (mode === "BEDROCK") return "Amazon Bedrock";
  if (mode === "GROQ") return "Groq";
  if (mode === "DEMO_FALLBACK") return "Demo fallback";
  return mode.replaceAll("_", " ");
}

function safeExternalUrl(value: string | null | undefined) {
  if (!value) return null;
  try {
    const url = new URL(value, window.location.origin);
    return url.protocol === "https:" || url.protocol === "http:" ? url.href : null;
  } catch {
    return null;
  }
}

function ProviderBadge({ mode, modelId }: { mode?: string | null; modelId?: string | null }) {
  return (
    <span className={`studio-provider provider-${(mode ?? "pending").toLowerCase()}`}>
      <Sparkles size={13} aria-hidden="true" />
      <span>{providerLabel(mode)}</span>
      {modelId && <small>{modelId}</small>}
    </span>
  );
}

function formatFileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function validDocument(file: File) {
  const extension = file.name.toLowerCase().split(".").at(-1);
  return file.size > 0 && ["pdf", "docx", "txt", "md", "markdown"].includes(extension ?? "");
}

export function calendarReminderRules(minutes: number[], emailEscalations: boolean) {
  const offsets = [...new Set(minutes)]
    .filter((value) => Number.isInteger(value) && value >= 0 && value <= 40320)
    .sort((left, right) => right - left)
    .slice(0, 5);
  const rules: Array<{ method: "popup" | "email"; minutes: number }> = offsets.map(
    (value) => ({ method: "popup", minutes: value }),
  );
  if (emailEscalations) {
    const emailCapacity = Math.max(0, 5 - rules.length);
    rules.push(...offsets.slice(0, emailCapacity).map((value) => ({
      method: "email" as const,
      minutes: value,
    })));
  }
  return rules;
}

function formatDateTime(value: string | null, timezone = "Asia/Singapore", fallback = "Not stated") {
  if (!value) return fallback;
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return fallback;
  try {
    return new Intl.DateTimeFormat("en-SG", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: timezone,
      timeZoneName: "short",
    }).format(parsed);
  } catch {
    return new Intl.DateTimeFormat("en-SG", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Singapore",
      timeZoneName: "short",
    }).format(parsed);
  }
}

function dateTimeParts(value: Date, timezone: string) {
  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: timezone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });
  const parts = Object.fromEntries(
    formatter
      .formatToParts(value)
      .filter((part) => part.type !== "literal")
      .map((part) => [part.type, Number(part.value)]),
  );
  return {
    year: parts.year,
    month: parts.month,
    day: parts.day,
    hour: parts.hour,
    minute: parts.minute,
    second: parts.second,
  };
}

function localDateTimeValue(value: string | null, timezone?: string) {
  if (!value) return "";
  const parsed = new Date(value);
  if (timezone && !Number.isNaN(parsed.getTime())) {
    try {
      const parts = dateTimeParts(parsed, timezone);
      if (Object.values(parts).every(Number.isFinite)) {
        const pad = (item: number) => String(item).padStart(2, "0");
        return `${parts.year}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hour)}:${pad(parts.minute)}`;
      }
    } catch {
      // Preserve a usable wall-clock value if the source timezone is invalid.
    }
  }
  const match = value.match(/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})/);
  return match?.[1] ?? "";
}

/** Convert an HTML datetime-local value into RFC3339 in an arbitrary IANA zone. */
export function rfc3339FromLocal(value: string, timezone: string) {
  if (!value) return null;
  const match = value.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
  if (!match) return null;
  const [, yearText, monthText, dayText, hourText, minuteText] = match;
  const expected = {
    year: Number(yearText),
    month: Number(monthText),
    day: Number(dayText),
    hour: Number(hourText),
    minute: Number(minuteText),
    second: 0,
  };
  const wallClockUtc = Date.UTC(
    expected.year,
    expected.month - 1,
    expected.day,
    expected.hour,
    expected.minute,
  );
  const normalized = new Date(wallClockUtc);
  if (
    normalized.getUTCFullYear() !== expected.year
    || normalized.getUTCMonth() + 1 !== expected.month
    || normalized.getUTCDate() !== expected.day
    || normalized.getUTCHours() !== expected.hour
    || normalized.getUTCMinutes() !== expected.minute
  ) return null;

  try {
    // Collect the offsets immediately around the wall date. A local time is safe only when
    // exactly one candidate instant round-trips; zero is a DST gap and two is a DST fold.
    const offsets = new Set<number>();
    for (const probeHours of [-48, -24, -12, 0, 12, 24, 48]) {
      const probe = wallClockUtc + probeHours * 60 * 60 * 1000;
      const atProbe = dateTimeParts(new Date(probe), timezone);
      offsets.add(Date.UTC(
        atProbe.year,
        atProbe.month - 1,
        atProbe.day,
        atProbe.hour,
        atProbe.minute,
        atProbe.second,
      ) - probe);
    }
    const matchingInstants = [...offsets]
      .map((offset) => wallClockUtc - offset)
      .filter((candidate) => {
        const roundTrip = dateTimeParts(new Date(candidate), timezone);
        return Object.entries(expected).every(
          ([key, number]) => roundTrip[key as keyof typeof roundTrip] === number,
        );
      });
    if (matchingInstants.length !== 1) return null;

    const [instant] = matchingInstants;
    const offsetMinutes = Math.round((wallClockUtc - instant) / 60_000);
    const sign = offsetMinutes >= 0 ? "+" : "-";
    const absoluteOffset = Math.abs(offsetMinutes);
    const pad = (item: number) => String(item).padStart(2, "0");
    return `${value}:00${sign}${pad(Math.floor(absoluteOffset / 60))}:${pad(absoluteOffset % 60)}`;
  } catch {
    return null;
  }
}

function SourceCitation({ source }: { source?: SourceReference | null }) {
  if (!source) return null;
  const location = [source.page ? `Page ${source.page}` : null, source.section]
    .filter(Boolean)
    .join(" · ");
  return (
    <details className="source-citation">
      <summary>
        <FileText size={13} aria-hidden="true" /> {location || "Source passage"}
      </summary>
      <p>{source.snippet || "No source excerpt was returned."}</p>
    </details>
  );
}

function SourceCitations({
  source,
  sources,
}: {
  source?: SourceReference | null;
  sources?: SourceReference[];
}) {
  const values = sources?.length ? sources : source ? [source] : [];
  return values.map((value, index) => (
    <SourceCitation
      key={`${value.page ?? "page"}-${value.section ?? "section"}-${index}`}
      source={value}
    />
  ));
}

function EmptyFeatureState({
  icon: Icon,
  title,
  children,
  onStart,
}: {
  icon: typeof FileText;
  title: string;
  children: string;
  onStart?: () => void;
}) {
  return (
    <section className="panel studio-empty-state">
      <span className="studio-empty-icon" aria-hidden="true">
        <Icon size={25} />
      </span>
      <h2>{title}</h2>
      <p>{children}</p>
      {onStart && (
        <button type="button" className="studio-primary-button" onClick={onStart}>
          Upload a tender <ArrowRight size={15} aria-hidden="true" />
        </button>
      )}
    </section>
  );
}

interface TenderDecipherProps {
  analysis: TenderAnalysis | null;
  onAnalysisComplete: (analysis: TenderAnalysis) => void;
  onContinue: (tab: StudioTab) => void;
}

function TenderDecipher({ analysis, onAnalysisComplete, onContinue }: TenderDecipherProps) {
  const [file, setFile] = useState<File | null>(null);
  const [job, setJob] = useState<AnalysisJob | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const controllerRef = useRef<AbortController | null>(null);
  const mutationRef = useRef(false);

  useEffect(() => () => controllerRef.current?.abort(), []);

  function selectFile(nextFile: File | null) {
    setError(null);
    if (!nextFile) {
      setFile(null);
      return;
    }
    if (!validDocument(nextFile)) {
      setFile(null);
      setError("Choose a non-empty PDF, DOCX, Markdown or plain-text tender document.");
      return;
    }
    setFile(nextFile);
    setJob(null);
  }

  async function runAnalysis(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file || mutationRef.current) return;
    mutationRef.current = true;
    const controller = new AbortController();
    controllerRef.current = controller;
    setBusy(true);
    setError(null);
    try {
      let current = await startupApi.createAnalysisJob(
        {
          file,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Singapore",
        },
        controller.signal,
      );
      setJob(current);

      for (let attempt = 0; attempt < 900; attempt += 1) {
        const status = current.status.toUpperCase();
        if (status === "FAILED" || status === "CANCELLED") {
          throw new Error(jobError(current));
        }
        if (status === "COMPLETED" || status === "PARTIAL") {
          if (!current.analysis_id) {
            throw new Error("Analysis completed without a result identifier.");
          }
          const result = await startupApi.getAnalysis(current.analysis_id, controller.signal);
          onAnalysisComplete(result);
          return;
        }
        await delay(Math.min(800 + attempt * 40, 2500), controller.signal);
        current = await startupApi.getAnalysisJob(current.id, controller.signal);
        setJob(current);
      }
      throw new Error("Analysis is taking longer than expected. You can retry without reloading.");
    } catch (reason) {
      if (!isAbort(reason)) {
        setError(errorMessage(reason, "Unable to analyse this tender."));
      }
    } finally {
      controllerRef.current = null;
      mutationRef.current = false;
      setBusy(false);
    }
  }

  function cancelAnalysis() {
    controllerRef.current?.abort();
    controllerRef.current = null;
    mutationRef.current = false;
    setBusy(false);
  }

  function handleDrop(event: DragEvent<HTMLLabelElement>) {
    event.preventDefault();
    setDragging(false);
    selectFile(event.dataTransfer.files.item(0));
  }

  const progress = job ? normalizedProgress(job.progress) : 0;

  return (
    <div className="studio-view-stack">
      <section className="panel decipher-upload-panel" aria-labelledby="decipher-title">
        <div className="studio-panel-heading">
          <div>
            <span className="eyebrow">B1 · Tender Jargon Decipher</span>
            <h2 id="decipher-title">Turn the tender into a startup action plan</h2>
            <p>Upload the original document. The AI will simplify it without hiding source evidence.</p>
          </div>
          <ProviderBadge mode={analysis?.mode} modelId={analysis?.model_id} />
        </div>
        <form className="decipher-upload-form" onSubmit={(event) => void runAnalysis(event)}>
          <label
            className={`document-dropzone ${dragging ? "dragging" : ""}`}
            htmlFor="tender-document"
            onDragEnter={() => setDragging(true)}
            onDragLeave={() => setDragging(false)}
            onDragOver={(event) => event.preventDefault()}
            onDrop={handleDrop}
          >
            <input
              id="tender-document"
              className="visually-hidden-file"
              type="file"
              accept=".pdf,.docx,.txt,.md,.markdown,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain,text/markdown"
              disabled={busy}
              onChange={(event: ChangeEvent<HTMLInputElement>) =>
                selectFile(event.target.files?.item(0) ?? null)
              }
            />
            <span className="dropzone-icon" aria-hidden="true">
              {file ? <FileCheck2 size={24} /> : <Upload size={24} />}
            </span>
            {file ? (
              <span className="dropzone-copy">
                <strong>{file.name}</strong>
                <small>{formatFileSize(file.size)} · Ready to analyse</small>
              </span>
            ) : (
              <span className="dropzone-copy">
                <strong>Choose or drop a tender document</strong>
                <small>PDF, DOCX, Markdown or plain text · ITT and ITQ documents supported</small>
              </span>
            )}
          </label>
          <div className="upload-actions">
            {busy ? (
              <button type="button" className="studio-secondary-button" onClick={cancelAnalysis}>
                <X size={15} aria-hidden="true" /> Stop waiting
              </button>
            ) : (
              <button
                type="submit"
                className="studio-primary-button"
                disabled={!file}
              >
                <Sparkles size={15} aria-hidden="true" /> Analyse tender
              </button>
            )}
          </div>
        </form>
        {busy && (
          <div className="analysis-progress" role="status" aria-live="polite">
            <div>
              <LoaderCircle className="spin" size={16} aria-hidden="true" />
              <span>
                <strong>{job?.stage || "Preparing document"}</strong>
                <small>{job?.message || "Extracting and checking tender facts…"}</small>
              </span>
              <b>{progress}%</b>
            </div>
            <span className="analysis-progress-track">
              <i style={{ width: `${progress}%` }} />
            </span>
          </div>
        )}
        {error && (
          <div className="studio-alert studio-alert-error" role="alert">
            <AlertCircle size={17} aria-hidden="true" />
            <span>{error}</span>
          </div>
        )}
      </section>

      {analysis ? (
        <AnalysisResult key={analysis.id} analysis={analysis} onContinue={onContinue} />
      ) : (
        <section className="analysis-placeholder" aria-label="What the analysis will produce">
          <article>
            <FileText size={20} aria-hidden="true" />
            <strong>Plain-English brief</strong>
            <span>What the buyer actually needs</span>
          </article>
          <article>
            <ListChecks size={20} aria-hidden="true" />
            <strong>Action checklist</strong>
            <span>Exactly what your team must prepare</span>
          </article>
          <article>
            <WalletCards size={20} aria-hidden="true" />
            <strong>Delivery and payment</strong>
            <span>Phases, triggers and stated dates</span>
          </article>
        </section>
      )}
    </div>
  );
}

function AnalysisResult({
  analysis,
  onContinue,
}: {
  analysis: TenderAnalysis;
  onContinue: (tab: StudioTab) => void;
}) {
  const storageKey = `${ANALYSIS_STORAGE_KEY}.checklist.${analysis.id}`;
  const [checked, setChecked] = useState<Set<string>>(() => {
    try {
      const stored = JSON.parse(window.localStorage.getItem(storageKey) ?? "[]") as string[];
      return new Set(stored);
    } catch {
      return new Set();
    }
  });

  function toggleChecklist(id: string) {
    setChecked((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      window.localStorage.setItem(storageKey, JSON.stringify([...next]));
      return next;
    });
  }

  return (
    <div className="analysis-results" aria-live="polite">
      <section className="panel analysis-overview">
        <div className="analysis-overview-copy">
          <span className="eyebrow">What the government wants</span>
          <h2>{analysis.overview.tender_title || analysis.document.filename}</h2>
          <p className="analysis-summary">{analysis.overview.summary}</p>
          <div className="buyer-goal">
            <Rocket size={18} aria-hidden="true" />
            <span>
              <small>Buyer goal, in plain English</small>
              <strong>{analysis.overview.buyer_goal}</strong>
            </span>
          </div>
        </div>
        <dl className="analysis-metrics">
          <div>
            <dt>Pages read</dt>
            <dd>{analysis.document.page_count ?? "—"}</dd>
          </div>
          <div>
            <dt>Product needs</dt>
            <dd>{analysis.product_features.length}</dd>
          </div>
          <div>
            <dt>Delivery phases</dt>
            <dd>{analysis.delivery_phases.length}</dd>
          </div>
          <div>
            <dt>Key dates</dt>
            <dd>{analysis.deadlines.length}</dd>
          </div>
        </dl>
      </section>

      {analysis.warnings.length > 0 && (
        <section className="studio-alert studio-alert-warning" aria-labelledby="analysis-warnings">
          <AlertTriangle size={18} aria-hidden="true" />
          <div>
            <strong id="analysis-warnings">Review before relying on this analysis</strong>
            <ul>{analysis.warnings.map((warning) => <li key={warning}>{warning}</li>)}</ul>
          </div>
        </section>
      )}

      <div className="analysis-two-column">
        <section className="panel analysis-section">
          <div className="studio-section-heading">
            <span className="section-icon blue"><Sparkles size={17} /></span>
            <div>
              <span className="eyebrow">Requested solution</span>
              <h2>Product capabilities</h2>
            </div>
            <span className="studio-count">{analysis.product_features.length}</span>
          </div>
          <div className="analysis-card-list">
            {analysis.product_features.length ? analysis.product_features.map((feature) => (
              <article className="analysis-item" key={feature.id ?? feature.title}>
                <div className="analysis-item-title">
                  <strong>{feature.title || "Product requirement"}</strong>
                  <span className={`obligation-chip obligation-${(feature.obligation_level ?? "unclear").toLowerCase()}`}>
                    {feature.obligation_level ?? "Review"}
                  </span>
                </div>
                <p>{feature.plain_english || "No plain-English explanation returned."}</p>
                {feature.acceptance_criteria && feature.acceptance_criteria.length > 0 && (
                  <ul className="compact-list">
                    {feature.acceptance_criteria.map((criterion) => <li key={criterion}>{criterion}</li>)}
                  </ul>
                )}
                <SourceCitations source={feature.source} sources={feature.sources} />
              </article>
            )) : <p className="studio-muted">No product capabilities were identified.</p>}
          </div>
        </section>

        <section className="panel analysis-section">
          <div className="studio-section-heading">
            <span className="section-icon green"><BadgeCheck size={17} /></span>
            <div>
              <span className="eyebrow">Can we participate?</span>
              <h2>Eligibility requirements</h2>
            </div>
            <span className="studio-count">{analysis.eligibility_requirements.length}</span>
          </div>
          <div className="analysis-card-list">
            {analysis.eligibility_requirements.length ? analysis.eligibility_requirements.map((item) => (
              <article className="analysis-item" key={item.id}>
                <div className="analysis-item-title">
                  <strong>{item.title || "Eligibility requirement"}</strong>
                  <span className={`obligation-chip obligation-${(item.obligation_level ?? "unclear").toLowerCase()}`}>
                    {item.obligation_level ?? "Review"}
                  </span>
                </div>
                <p>{item.plain_english || "Check this requirement against your startup's evidence."}</p>
                <SourceCitations source={item.source} sources={item.sources} />
              </article>
            )) : <p className="studio-muted">No separate eligibility requirements were identified.</p>}
          </div>
        </section>
      </div>

      <section className="panel analysis-section">
        <div className="studio-section-heading">
          <span className="section-icon amber"><Clock3 size={17} /></span>
          <div>
            <span className="eyebrow">How delivery happens</span>
            <h2>Delivery phases and payment triggers</h2>
          </div>
        </div>
        <div className="delivery-payment-grid">
          <div className="delivery-timeline">
            <h3>Delivery plan</h3>
            {analysis.delivery_phases.length ? analysis.delivery_phases.map((phase, index) => (
              <article className="timeline-item" key={phase.id}>
                <span>{phase.sequence ?? index + 1}</span>
                <div>
                  <strong>{phase.name || `Phase ${index + 1}`}</strong>
                  <small>{phase.timing || formatDateTime(phase.due_at)}</small>
                  {phase.deliverables.length > 0 && (
                    <ul className="compact-list">{phase.deliverables.map((item) => <li key={item}>{item}</li>)}</ul>
                  )}
                  <SourceCitations source={phase.source} sources={phase.sources} />
                </div>
              </article>
            )) : <p className="studio-muted">No phased delivery plan was stated.</p>}
          </div>
          <div className="payment-list">
            <h3>When payment happens</h3>
            {analysis.payment_milestones.length ? analysis.payment_milestones.map((payment) => (
              <article className="payment-item" key={payment.id}>
                <WalletCards size={17} aria-hidden="true" />
                <div>
                  <strong>{payment.milestone || "Payment milestone"}</strong>
                  <p>{payment.trigger || "Payment trigger not stated."}</p>
                  <small>
                    {[payment.amount, payment.timing, payment.due_at ? formatDateTime(payment.due_at) : null]
                      .filter(Boolean)
                      .join(" · ") || "Amount and timing not stated"}
                  </small>
                  <SourceCitations source={payment.source} sources={payment.sources} />
                </div>
              </article>
            )) : <p className="studio-muted">No payment schedule was stated. Add this to your clarification questions.</p>}
          </div>
        </div>
      </section>

      <div className="analysis-two-column checklist-risk-grid">
        <section className="panel analysis-section">
          <div className="studio-section-heading">
            <span className="section-icon green"><ClipboardCheck size={17} /></span>
            <div>
              <span className="eyebrow">Your next moves</span>
              <h2>Startup action checklist</h2>
            </div>
            <span className="studio-count">{checked.size}/{analysis.startup_checklist.length}</span>
          </div>
          <div className="startup-checklist">
            {analysis.startup_checklist.length ? analysis.startup_checklist.map((item, index) => {
              const id = item.id || `${index}-${item.title}`;
              const sources = item.sources ?? [];
              return (
                <article className="startup-checklist-item" key={id}>
                  <label className={checked.has(id) ? "checked" : ""}>
                    <input
                      type="checkbox"
                      checked={checked.has(id)}
                      onChange={() => toggleChecklist(id)}
                    />
                    <span className="check-control" aria-hidden="true"><Check size={13} /></span>
                    <span>
                      <strong>{item.title || "Prepare bid item"}</strong>
                      <small>{item.description || item.category || "Add this item to your bid plan."}</small>
                    </span>
                    <b className={`priority-label priority-${(item.priority ?? "medium").toLowerCase()}`}>
                      {item.priority ?? "MEDIUM"}
                    </b>
                  </label>
                  {sources.length > 0 && (
                    <div
                      className="checklist-source-list"
                      role="group"
                      aria-label={`Sources for ${item.title || "checklist item"}`}
                    >
                      {sources.map((source, sourceIndex) => (
                        <SourceCitation key={`${id}-source-${sourceIndex}`} source={source} />
                      ))}
                    </div>
                  )}
                </article>
              );
            }) : <p className="studio-muted">No checklist items were returned.</p>}
          </div>
        </section>

        <section className="panel analysis-section">
          <div className="studio-section-heading">
            <span className="section-icon red"><AlertTriangle size={17} /></span>
            <div>
              <span className="eyebrow">Before you commit</span>
              <h2>Risks and questions</h2>
            </div>
          </div>
          <div className="risk-list">
            {analysis.risks.map((risk) => (
              <article key={risk.id}>
                <strong>{risk.title || "Tender risk"}</strong>
                <p>{risk.plain_english || "Review this item with the bid owner."}</p>
                {risk.mitigation && <small>Next step: {risk.mitigation}</small>}
                <SourceCitations source={risk.source} sources={risk.sources} />
              </article>
            ))}
            {analysis.clarification_questions.length > 0 && (
              <div className="clarification-box">
                <strong><HelpCircle size={15} /> Questions to ask the agency</strong>
                <ol>{analysis.clarification_questions.map((question) => <li key={question}>{question}</li>)}</ol>
              </div>
            )}
            {!analysis.risks.length && !analysis.clarification_questions.length && (
              <p className="studio-muted">No separate risks or clarification questions were returned.</p>
            )}
          </div>
        </section>
      </div>

      {analysis.glossary.length > 0 && (
        <section className="panel glossary-panel">
          <div className="studio-section-heading">
            <span className="section-icon blue"><BookOpen size={17} /></span>
            <div>
              <span className="eyebrow">Procurement language</span>
              <h2>Plain-English glossary</h2>
            </div>
          </div>
          <dl>{analysis.glossary.map((entry) => (
            <div key={entry.term}>
              <dt>{entry.term || "Tender term"}</dt>
              <dd>
                {entry.plain_english || "No definition returned."}
                <SourceCitations source={entry.source} sources={entry.sources} />
              </dd>
            </div>
          ))}</dl>
        </section>
      )}

      <section className="analysis-next-actions">
        <div>
          <strong>Analysis complete</strong>
          <span>Use the same verified tender context in the next two tools.</span>
        </div>
        <button type="button" className="studio-secondary-button" onClick={() => onContinue("milestones")}>
          <CalendarClock size={15} /> Review {analysis.deadlines.length} dates
        </button>
        <button type="button" className="studio-primary-button" onClick={() => onContinue("proposal")}>
          Build the proposal <ArrowRight size={15} />
        </button>
      </section>
      {analysis.human_review_required && (
        <p className="human-review-note">
          <AlertCircle size={14} /> AI output is a working interpretation. Your team remains responsible for checking the original tender.
        </p>
      )}
    </div>
  );
}

function ProposalBuilder({
  analysis,
  session,
  onSessionChange,
  onStartAnalysis,
}: {
  analysis: TenderAnalysis | null;
  session: ProposalSession | null;
  onSessionChange: (session: ProposalSession) => void;
  onStartAnalysis: () => void;
}) {
  const [companyName, setCompanyName] = useState("");
  const [solutionName, setSolutionName] = useState("");
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const answerRef = useRef<HTMLTextAreaElement>(null);
  const mutationRef = useRef(false);

  async function startSession(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!analysis || mutationRef.current) return;
    if (!companyName.trim() || !solutionName.trim()) {
      setError("Enter your company and solution names to start the guided interview.");
      return;
    }
    mutationRef.current = true;
    setBusy(true);
    setError(null);
    try {
      const result = await startupApi.createProposalSession({
        analysis_id: analysis.id,
        company_name: companyName.trim(),
        solution_name: solutionName.trim(),
      });
      onSessionChange(result);
      setNotice("Mentor session created. Answer in your own words—the AI will formalise it.");
      window.setTimeout(() => answerRef.current?.focus(), 0);
    } catch (reason) {
      setError(errorMessage(reason, "Unable to start the proposal session."));
    } finally {
      mutationRef.current = false;
      setBusy(false);
    }
  }

  async function submitAnswer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!session?.current_question || mutationRef.current) return;
    if (!answer.trim()) {
      setError("Write a short answer before continuing.");
      answerRef.current?.focus();
      return;
    }
    mutationRef.current = true;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const result = await startupApi.submitProposalAnswer(session.id, {
        question_id: session.current_question.id,
        answer: answer.trim(),
        revision: session.revision,
      });
      onSessionChange(result);
      setAnswer("");
      setNotice(result.current_question ? "Answer saved. Here is your next question." : "Interview complete. Your draft is ready to generate.");
      window.setTimeout(() => answerRef.current?.focus(), 0);
    } catch (reason) {
      setError(errorMessage(reason, "Unable to save this answer."));
    } finally {
      mutationRef.current = false;
      setBusy(false);
    }
  }

  async function generateDraft() {
    if (!session || mutationRef.current) return;
    mutationRef.current = true;
    setBusy(true);
    setError(null);
    try {
      const result = await startupApi.generateProposal(session.id, { revision: session.revision });
      onSessionChange(result);
      setNotice("Professional draft generated. Review every claim and open item before submission.");
    } catch (reason) {
      setError(errorMessage(reason, "Unable to generate the proposal draft."));
    } finally {
      mutationRef.current = false;
      setBusy(false);
    }
  }

  async function copyDraft(draft: ProposalDraft) {
    try {
      await navigator.clipboard.writeText(draft.markdown || draftAsText(draft));
      setNotice("Proposal draft copied to the clipboard.");
    } catch {
      setError("Your browser blocked clipboard access. Select and copy the draft manually.");
    }
  }

  if (!analysis) {
    return (
      <EmptyFeatureState icon={MessageSquare} title="Analyse a tender before building its proposal" onStart={onStartAnalysis}>
        The mentor needs the tender requirements first so its questions and draft stay grounded in the buyer's request.
      </EmptyFeatureState>
    );
  }

  if (!session) {
    return (
      <section className="panel proposal-start-panel">
        <div className="proposal-intro">
          <span className="section-icon blue"><MessageSquare size={20} /></span>
          <span className="eyebrow">B2 · Guided Proposal Builder</span>
          <h2>Explain your idea like you would to a mentor</h2>
          <p>
            The AI asks targeted questions based on <strong>{analysis.overview.tender_title || analysis.document.filename}</strong>, critiques gaps, then converts your answers into procurement-ready language.
          </p>
        </div>
        <form className="proposal-start-form" onSubmit={(event) => void startSession(event)}>
          <label>
            <span>Company name</span>
            <input
              value={companyName}
              onChange={(event) => setCompanyName(event.target.value)}
              autoComplete="organization"
              minLength={2}
              required
            />
          </label>
          <label>
            <span>Solution name</span>
            <input
              value={solutionName}
              onChange={(event) => setSolutionName(event.target.value)}
              minLength={2}
              required
            />
          </label>
          <button type="submit" className="studio-primary-button" disabled={busy}>
            {busy ? <LoaderCircle className="spin" size={15} /> : <Sparkles size={15} />}
            Start mentor interview
          </button>
        </form>
        {error && <div className="studio-alert studio-alert-error" role="alert"><AlertCircle size={17} />{error}</div>}
      </section>
    );
  }

  const progress = normalizedProgress(session.progress);
  const canGenerate = session.status === "READY" && !session.draft;

  return (
    <div className="proposal-workspace">
      <section className="panel mentor-panel" aria-labelledby="mentor-heading">
        <div className="studio-panel-heading compact">
          <div>
            <span className="eyebrow">AI incubator mentor</span>
            <h2 id="mentor-heading">Practice and critique</h2>
          </div>
          <ProviderBadge mode={session.mode} modelId={session.model_id} />
        </div>
        <div className="proposal-progress" aria-label={`${progress}% of interview completed`}>
          <span><i style={{ width: `${progress}%` }} /></span>
          <strong>{progress}%</strong>
        </div>

        {session.last_feedback && (
          <article className="mentor-feedback" aria-live="polite">
            <div className="feedback-title">
              <BadgeCheck size={17} />
              <span><small>Mentor critique</small><strong>{session.last_feedback.verdict.replaceAll("_", " ")}</strong></span>
            </div>
            <p>{session.last_feedback.mentor_feedback}</p>
            {session.last_feedback.strengths.length > 0 && (
              <div className="feedback-points positive"><strong>What works</strong><ul>{session.last_feedback.strengths.map((item) => <li key={item}>{item}</li>)}</ul></div>
            )}
            {session.last_feedback.gaps.length > 0 && (
              <div className="feedback-points warning"><strong>What is missing</strong><ul>{session.last_feedback.gaps.map((item) => <li key={item}>{item}</li>)}</ul></div>
            )}
            {session.last_feedback.unsupported_claims.length > 0 && (
              <div className="feedback-points negative"><strong>Claims needing evidence</strong><ul>{session.last_feedback.unsupported_claims.map((item) => <li key={item}>{item}</li>)}</ul></div>
            )}
            {session.last_feedback.formalized_answer && (
              <div className="formal-answer"><strong>Procurement-ready version</strong><p>{session.last_feedback.formalized_answer}</p></div>
            )}
          </article>
        )}

        {session.current_question ? (
          <form className="mentor-question" onSubmit={(event) => void submitAnswer(event)}>
            <span className="question-section">{session.current_question.section.replaceAll("_", " ")}</span>
            <h3>{session.current_question.question}</h3>
            <p className="why-question"><HelpCircle size={14} /> {session.current_question.why_it_matters}</p>
            {session.current_question.answer_guidance.length > 0 && (
              <details className="answer-guidance">
                <summary>What to cover in your answer</summary>
                <ul>{session.current_question.answer_guidance.map((guide) => <li key={guide}>{guide}</li>)}</ul>
              </details>
            )}
            <label htmlFor="proposal-answer">Your answer—in simple words</label>
            <textarea
              ref={answerRef}
              id="proposal-answer"
              rows={7}
              value={answer}
              onChange={(event) => setAnswer(event.target.value)}
              maxLength={PROPOSAL_ANSWER_MAX_CHARACTERS}
              placeholder="For example: We run the service across two cloud zones, so if one goes down…"
              aria-describedby="answer-privacy-note"
            />
            <small id="answer-privacy-note">
              Use facts you can support. Do not paste passwords, API keys or personal data.{" "}
              {answer.length.toLocaleString()} /{" "}
              {PROPOSAL_ANSWER_MAX_CHARACTERS.toLocaleString()} characters.
            </small>
            <button type="submit" className="studio-primary-button" disabled={busy || !answer.trim()}>
              {busy ? <LoaderCircle className="spin" size={15} /> : <Send size={15} />}
              Get critique and continue
            </button>
          </form>
        ) : (
          <div className="interview-complete">
            <CheckCircle2 size={29} />
            <h3>Interview complete</h3>
            <p>The mentor has enough grounded information to assemble your first draft.</p>
          </div>
        )}

        {canGenerate && (
          <button type="button" className="studio-generate-button" onClick={() => void generateDraft()} disabled={busy}>
            {busy ? <LoaderCircle className="spin" size={17} /> : <Sparkles size={17} />}
            Generate professional draft
          </button>
        )}
        {error && <div className="studio-alert studio-alert-error" role="alert"><AlertCircle size={17} />{error}</div>}
        {notice && <div className="studio-inline-status" role="status"><CheckCircle2 size={15} />{notice}</div>}
      </section>

      <section className="panel draft-panel" aria-labelledby="draft-heading">
        <div className="studio-panel-heading compact">
          <div>
            <span className="eyebrow">Live output</span>
            <h2 id="draft-heading">Professional proposal draft</h2>
          </div>
          {session.draft && (
            <button type="button" className="studio-icon-text-button" onClick={() => void copyDraft(session.draft!)}>
              <Copy size={14} /> Copy draft
            </button>
          )}
        </div>
        {session.draft ? <ProposalDraftView draft={session.draft} /> : (
          <div className="draft-placeholder">
            <FileText size={29} />
            <strong>Your draft will build here</strong>
            <p>Each response adds grounded material. The AI must flag unsupported claims instead of inventing credentials or experience.</p>
            <div className="draft-outline">
              {["Executive summary", "Proposed solution", "Technical approach", "Security and continuity", "Delivery plan"].map((item) => (
                <span key={item}><i />{item}</span>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

function draftAsText(draft: ProposalDraft) {
  return [
    draft.title,
    ...draft.executive_summary.map((paragraph) => paragraph.text),
    ...draft.sections.flatMap((section) => [section.heading, ...section.paragraphs.map((paragraph) => paragraph.text)]),
    draft.review_notice,
  ].filter(Boolean).join("\n\n");
}

function ProposalDraftView({ draft }: { draft: ProposalDraft }) {
  return (
    <article className="proposal-draft-document">
      <h3>{draft.title}</h3>
      {draft.executive_summary.length > 0 && (
        <section><h4>Executive summary</h4>{draft.executive_summary.map((paragraph, index) => <p key={index}>{paragraph.text}</p>)}</section>
      )}
      {draft.sections.map((section) => (
        <section key={section.section_key}>
          <h4>{section.heading}</h4>
          {section.paragraphs.map((paragraph, index) => <p key={index}>{paragraph.text}</p>)}
        </section>
      ))}
      {draft.open_items.length > 0 && (
        <section className="proposal-open-items">
          <h4>Open items requiring your input</h4>
          <ul>{draft.open_items.map((item) => <li key={item.text}>{item.text}</li>)}</ul>
        </section>
      )}
      <footer><AlertCircle size={14} /> {draft.review_notice}</footer>
    </article>
  );
}

interface DeadlineEdit {
  localValue: string;
  confirmed: boolean;
  allDay: boolean;
  timezone: string;
  title: string;
}

function deadlineEditChanged(deadline: TenderDeadline, edit: DeadlineEdit | undefined) {
  if (!edit) return false;
  return edit.localValue !== localDateTimeValue(deadline.deadline_at, deadline.timezone)
    || edit.allDay !== deadline.all_day
    || edit.timezone.trim() !== deadline.timezone
    || edit.title.trim() !== deadline.title;
}

function deadlineValueForConversion(deadline: TenderDeadline, edit: DeadlineEdit | undefined) {
  const localValue = edit?.localValue ?? localDateTimeValue(deadline.deadline_at, deadline.timezone);
  const allDay = edit?.allDay ?? deadline.all_day;
  // An all-day event represents a civil date, so resolve it at noon rather than at a
  // midnight that some IANA zones skip during a daylight-saving transition.
  return allDay && localValue ? `${localValue.split("T")[0]}T12:00` : localValue;
}

function deadlineTimeChanged(deadline: TenderDeadline, edit: DeadlineEdit | undefined) {
  if (!edit) return false;
  return edit.localValue !== localDateTimeValue(deadline.deadline_at, deadline.timezone)
    || edit.allDay !== deadline.all_day
    || edit.timezone.trim() !== deadline.timezone;
}

function effectiveDeadlineAt(deadline: TenderDeadline, edit: DeadlineEdit | undefined) {
  if (deadline.deadline_at && !deadlineTimeChanged(deadline, edit)) {
    return deadline.deadline_at;
  }
  return rfc3339FromLocal(
    deadlineValueForConversion(deadline, edit),
    edit?.timezone.trim() || deadline.timezone,
  );
}

function formatDeadline(
  value: string | null,
  timezone: string,
  allDay: boolean,
  fallback: string,
) {
  if (!value || !allDay) return formatDateTime(value, timezone, fallback);
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return fallback;
  try {
    return new Intl.DateTimeFormat("en-SG", {
      day: "numeric",
      month: "short",
      year: "numeric",
      timeZone: timezone,
    }).format(parsed);
  } catch {
    return fallback;
  }
}

function MilestoneSync({ analysis, onStartAnalysis }: { analysis: TenderAnalysis | null; onStartAnalysis: () => void }) {
  const [calendar, setCalendar] = useState<CalendarStatus | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [edits, setEdits] = useState<Record<string, DeadlineEdit>>({});
  const [expandedDeadlines, setExpandedDeadlines] = useState<Set<string>>(new Set());
  const [reminders, setReminders] = useState<Set<number>>(new Set([10080, 1440, 120]));
  const [emailEscalations, setEmailEscalations] = useState(true);
  const [attendees, setAttendees] = useState("");
  const [savedDeadlineState, setSavedDeadlineState] = useState<Record<string, CalendarDeadlineState>>({});
  const [notificationSettingsDirty, setNotificationSettingsDirty] = useState(false);
  const [syncResult, setSyncResult] = useState<CalendarSyncResponse | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [loadingSavedState, setLoadingSavedState] = useState(false);
  const [savedStateReady, setSavedStateReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const mutationRef = useRef(false);

  function clearSyncFeedback() {
    setSyncResult(null);
    setNotice(null);
    setError(null);
  }

  useEffect(() => {
    const controller = new AbortController();
    startupApi.getCalendarStatus(controller.signal)
      .then(setCalendar)
      .catch((reason: unknown) => {
        if (!isAbort(reason)) setError(errorMessage(reason, "Unable to check Google Calendar status."));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingStatus(false);
      });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!analysis) return;
    setSelected(new Set(analysis.deadlines.filter((item) => item.deadline_at && !item.needs_review).map((item) => item.id)));
    setEdits(Object.fromEntries(analysis.deadlines.map((item) => [item.id, {
      localValue: localDateTimeValue(item.deadline_at, item.timezone),
      confirmed: !item.needs_review,
      allDay: item.all_day,
      timezone: item.timezone,
      title: item.title,
    }])));
    setExpandedDeadlines(new Set());
    setSavedDeadlineState({});
    setNotificationSettingsDirty(false);
    setSyncResult(null);
    setNotice(null);
  }, [analysis]);

  useEffect(() => {
    if (!analysis || !calendar?.connected) {
      setLoadingSavedState(false);
      setSavedStateReady(false);
      return;
    }
    const controller = new AbortController();
    setLoadingSavedState(true);
    setSavedStateReady(false);
    startupApi.getCalendarState(analysis.id, controller.signal)
      .then((state) => {
        const savedByDeadline = new Map(
          state.deadlines.map((deadline) => [deadline.deadline_id, deadline]),
        );
        setSavedDeadlineState(Object.fromEntries(savedByDeadline));
        setNotificationSettingsDirty(false);
        setEdits((current) => Object.fromEntries(analysis.deadlines.map((deadline) => {
          const saved = savedByDeadline.get(deadline.id)?.override;
          if (!saved) {
            return [deadline.id, current[deadline.id] ?? {
              localValue: localDateTimeValue(deadline.deadline_at, deadline.timezone),
              confirmed: !deadline.needs_review,
              allDay: deadline.all_day,
              timezone: deadline.timezone,
              title: deadline.title,
            }];
          }
          const timezone = saved.timezone?.trim() || deadline.timezone;
          const deadlineAt = saved.deadline_at ?? deadline.deadline_at;
          return [deadline.id, {
            localValue: localDateTimeValue(deadlineAt, timezone),
            confirmed: saved.confirmed,
            allDay: saved.all_day ?? deadline.all_day,
            timezone,
            title: saved.title?.trim() || deadline.title,
          }];
        })));
        setSelected((current) => {
          const next = new Set(current);
          for (const deadline of state.deadlines) {
            if (deadline.override?.confirmed && deadline.override.deadline_at) {
              next.add(deadline.deadline_id);
            }
          }
          return next;
        });

        const latestSettings = [...state.deadlines]
          .filter((deadline) => deadline.reminders !== null || deadline.attendees !== null)
          .sort((left, right) => (
            Date.parse(right.last_synced_at ?? "") - Date.parse(left.last_synced_at ?? "")
          ))[0];
        if (latestSettings?.reminders !== null && latestSettings?.reminders !== undefined) {
          setReminders(new Set(
            latestSettings.reminders
              .filter((reminder) => reminder.method === "popup")
              .map((reminder) => reminder.minutes),
          ));
          setEmailEscalations(
            latestSettings.reminders.some((reminder) => reminder.method === "email"),
          );
        }
        if (latestSettings?.attendees !== null && latestSettings?.attendees !== undefined) {
          setAttendees(latestSettings.attendees.join(", "));
        }
        if (state.deadlines.length > 0) {
          setSyncResult({
            status: "COMPLETE",
            calendar_id: state.calendar_id,
            results: state.deadlines
              .filter((deadline) => deadline.status !== null)
              .map((deadline) => ({
                deadline_id: deadline.deadline_id,
                status: deadline.status ?? "UNCHANGED",
                event_id: deadline.event_id,
                event_link: deadline.event_link,
                payload_hash: deadline.payload_hash,
                error: null,
              })),
          });
        }
        setSavedStateReady(true);
      })
      .catch((reason: unknown) => {
        if (!isAbort(reason)) {
          setError(errorMessage(
            reason,
            "Unable to restore saved calendar corrections. Reload them before syncing.",
          ));
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingSavedState(false);
      });
    return () => controller.abort();
  }, [analysis, calendar]);

  async function refreshCalendarStatus() {
    setLoadingStatus(true);
    setError(null);
    setNotice(null);
    setSyncResult(null);
    try {
      setCalendar(await startupApi.getCalendarStatus());
    } catch (reason) {
      setError(errorMessage(reason, "Unable to refresh Google Calendar status."));
    } finally {
      setLoadingStatus(false);
    }
  }

  function connectGoogle() {
    setError(null);
    const popup = window.open(
      startupApi.getGoogleCalendarAuthorizationUrl(),
      "gebiz-google-calendar",
      "popup,width=620,height=760",
    );
    if (!popup) {
      setError("Your browser blocked the Google sign-in window. Allow pop-ups and try again.");
      return;
    }
    setNotice("Complete Google sign-in, then select “Refresh connection”.");
  }

  function toggleDeadline(deadline: TenderDeadline) {
    if (busy) return;
    const edit = edits[deadline.id];
    const confirmationRequired = deadline.needs_review || deadlineEditChanged(deadline, edit);
    if (
      (!deadline.deadline_at && !edit?.localValue)
      || (confirmationRequired && !edit?.confirmed)
    ) return;
    setSelected((current) => {
      const next = new Set(current);
      if (next.has(deadline.id)) next.delete(deadline.id);
      else next.add(deadline.id);
      return next;
    });
    clearSyncFeedback();
  }

  function updateEdit(deadlineId: string, patch: Partial<DeadlineEdit>) {
    if (busy) return;
    setEdits((current) => ({
      ...current,
      [deadlineId]: {
        localValue: "",
        confirmed: false,
        allDay: false,
        timezone: "",
        title: "",
        ...current[deadlineId],
        ...patch,
      },
    }));
    setSelected((current) => {
      const next = new Set(current);
      next.delete(deadlineId);
      return next;
    });
    clearSyncFeedback();
  }

  function toggleReminder(minutes: number) {
    if (busy || loadingSavedState) return;
    const next = new Set(reminders);
    if (next.has(minutes)) next.delete(minutes);
    else next.add(minutes);
    setReminders(next);
    setNotificationSettingsDirty(true);
    if (next.size === 0) setEmailEscalations(false);
    clearSyncFeedback();
  }

  async function downloadIcs() {
    if (!analysis || mutationRef.current) return;
    mutationRef.current = true;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      const blob = await startupApi.downloadCalendarIcs(analysis.id);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${analysis.document.filename.replace(/\.[^.]+$/, "") || "tender"}-deadlines.ics`;
      document.body.append(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 0);
      setNotice("Calendar file downloaded. Import it into Google Calendar, Outlook or Apple Calendar.");
    } catch (reason) {
      setError(errorMessage(reason, "Unable to export the calendar file."));
    } finally {
      mutationRef.current = false;
      setBusy(false);
    }
  }

  async function syncCalendar() {
    if (
      !analysis
      || !calendar?.connected
      || !savedStateReady
      || selected.size === 0
      || mutationRef.current
    ) return;
    const parsedAttendees = [...new Set(
      attendees.split(/[\s,;]+/).map((item) => item.trim().toLowerCase()).filter(Boolean),
    )];
    const invalidEmail = parsedAttendees.find((item) => !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(item));
    if (invalidEmail) {
      setError(`Check the attendee email address: ${invalidEmail}`);
      return;
    }
    if (parsedAttendees.length > 50) {
      setError("Google Calendar supports at most 50 team recipients in this workflow.");
      return;
    }
    const reminderMinutes = [...reminders].sort((a, b) => b - a);
    const reminderRules = calendarReminderRules(reminderMinutes, emailEscalations);
    const deadlineOverrides = analysis.deadlines
      .filter((deadline) => selected.has(deadline.id))
      .map((deadline) => {
        const edit = edits[deadline.id];
        const timezone = edit?.timezone.trim() || deadline.timezone;
        const allDay = edit?.allDay ?? deadline.all_day;
        const savedSettings = savedDeadlineState[deadline.id];
        const preserveSavedSettings = notificationSettingsDirty ? undefined : savedSettings;
        return {
          deadline_id: deadline.id,
          deadline_at: effectiveDeadlineAt(deadline, edit),
          all_day: allDay,
          timezone,
          title: edit?.title.trim() || deadline.title,
          confirmed: edit?.confirmed ?? !deadline.needs_review,
          ...(preserveSavedSettings?.reminders !== null
            && preserveSavedSettings?.reminders !== undefined
            ? { reminders: preserveSavedSettings.reminders }
            : {}),
          ...(preserveSavedSettings?.attendees !== null
            && preserveSavedSettings?.attendees !== undefined
            ? { attendees: preserveSavedSettings.attendees }
            : {}),
        };
      });
    const invalidOverride = deadlineOverrides.find((override) => (
      !override.deadline_at || !override.timezone || !override.title
    ));
    if (invalidOverride) {
      const deadline = analysis.deadlines.find((item) => item.id === invalidOverride.deadline_id);
      setError(
        `Check the date, time and timezone for ${deadline?.title ?? "the selected deadline"}. `
        + "The local time may be invalid or ambiguous because of a daylight-saving transition.",
      );
      return;
    }
    mutationRef.current = true;
    setBusy(true);
    setError(null);
    setNotice(null);
    setSyncResult(null);
    try {
      const result = await startupApi.syncCalendar(analysis.id, {
        deadline_ids: [...selected],
        reminder_minutes: reminderMinutes,
        reminders: reminderRules,
        attendees: parsedAttendees,
        deadline_overrides: deadlineOverrides,
      });
      setSyncResult(result);
      setNotice(result.status === "COMPLETE"
        ? "Selected deadlines are now up to date in Google Calendar."
        : "Calendar sync finished with items that need attention.");
    } catch (reason) {
      setError(errorMessage(reason, "Unable to sync the selected deadlines."));
    } finally {
      mutationRef.current = false;
      setBusy(false);
    }
  }

  if (!analysis) {
    return (
      <EmptyFeatureState icon={CalendarClock} title="Analyse a tender to reveal its hidden dates" onStart={onStartAnalysis}>
        Clarification, submission, briefing, bid-bond and delivery dates will appear here with their original source passages.
      </EmptyFeatureState>
    );
  }

  const orderedDeadlines = [...analysis.deadlines].sort((left, right) => {
    if (!left.deadline_at) return right.deadline_at ? 1 : 0;
    if (!right.deadline_at) return -1;
    return new Date(left.deadline_at).getTime() - new Date(right.deadline_at).getTime();
  });

  return (
    <div className="milestone-workspace">
      <section className="panel deadline-panel" aria-labelledby="milestone-heading">
        <div className="studio-panel-heading">
          <div>
            <span className="eyebrow">B3 · Smart Milestone Sync</span>
            <h2 id="milestone-heading">Review every date before it reaches your calendar</h2>
            <p>{analysis.deadlines.length} date{analysis.deadlines.length === 1 ? "" : "s"} extracted in the document's stated timezone.</p>
          </div>
          <span className="selected-deadline-count" role="status" aria-live="polite" aria-atomic="true">
            {selected.size} selected
          </span>
        </div>
        <div className="deadline-list">
          {orderedDeadlines.length ? orderedDeadlines.map((deadline, deadlineIndex) => {
            const edit = edits[deadline.id];
            const changed = deadlineEditChanged(deadline, edit);
            const confirmationRequired = deadline.needs_review || changed;
            const correctionsId = `deadline-corrections-${deadlineIndex}`;
            const effectiveTimezone = edit?.timezone.trim() || deadline.timezone;
            const effectiveAllDay = edit?.allDay ?? deadline.all_day;
            const effectiveDate = effectiveDeadlineAt(deadline, edit);
            const effectiveTitle = edit?.title.trim() || deadline.title;
            const correctionConfirmed = edit?.confirmed ?? false;
            const reviewLabel = changed
              ? correctionConfirmed ? "Correction confirmed" : "Correction needs confirmation"
              : deadline.needs_review
                ? correctionConfirmed ? "Source checked" : "Needs review"
                : `${deadline.confidence} confidence`;
            const selectable = Boolean(
              effectiveDate
              && (!confirmationRequired || edit?.confirmed),
            );
            const result = syncResult?.results?.find((item) => item.deadline_id === deadline.id)
              ?? syncResult?.events?.find((item) => item.deadline_id === deadline.id);
            const eventLink = safeExternalUrl(result?.event_link || result?.html_link);
            return (
              <article className={`deadline-card ${deadline.needs_review ? "needs-review" : ""}`} key={deadline.id}>
                <label className="deadline-selector">
                  <input
                    type="checkbox"
                    checked={selected.has(deadline.id)}
                    disabled={busy || !selectable}
                    aria-label={`Select ${deadline.title} for calendar sync`}
                    onChange={() => toggleDeadline(deadline)}
                  />
                  <span className="check-control" aria-hidden="true"><Check size={13} /></span>
                  <span className="deadline-kind">{deadline.kind.replaceAll("_", " ")}</span>
                </label>
                <div className="deadline-copy">
                  <div>
                    <h3>{effectiveTitle}</h3>
                    <span className={`confidence-chip confidence-${
                      changed || deadline.needs_review
                        ? correctionConfirmed ? "high" : "low"
                        : String(deadline.confidence).toLowerCase()
                    }`}>
                      {reviewLabel}
                    </span>
                  </div>
                  <time dateTime={effectiveDate ?? undefined}>
                    {formatDeadline(
                      effectiveDate,
                      effectiveTimezone,
                      effectiveAllDay,
                      edit?.localValue
                        ? `${edit.localValue.replace("T", " ")} · ${effectiveTimezone} (check value)`
                        : deadline.date_text || "Date not resolved",
                    )}
                  </time>
                  <small>
                    Original wording: {deadline.date_text} · {deadline.timezone} · {deadline.confidence.toLowerCase()} extraction confidence
                  </small>
                  {!deadline.needs_review && deadline.deadline_at && (
                    <button
                      type="button"
                      className="text-button"
                      disabled={busy}
                      aria-expanded={expandedDeadlines.has(deadline.id)}
                      aria-controls={correctionsId}
                      onClick={() => setExpandedDeadlines((current) => {
                        const next = new Set(current);
                        if (next.has(deadline.id)) next.delete(deadline.id);
                        else next.add(deadline.id);
                        return next;
                      })}
                    >
                      {expandedDeadlines.has(deadline.id) ? "Hide corrections" : "Review or correct"}
                    </button>
                  )}
                  {(deadline.needs_review || !deadline.deadline_at || expandedDeadlines.has(deadline.id)) && (
                    <div className="deadline-review-controls" id={correctionsId}>
                      <label>
                        <span>Calendar event title</span>
                        <input
                          type="text"
                          disabled={busy}
                          value={edit?.title ?? deadline.title}
                          maxLength={500}
                          onChange={(event) => updateEdit(deadline.id, {
                            title: event.target.value,
                            confirmed: false,
                          })}
                        />
                      </label>
                      <label>
                        <span>{edit?.allDay ? "Confirmed date" : "Confirmed date and time"}</span>
                        <input
                          type={edit?.allDay ? "date" : "datetime-local"}
                          disabled={busy}
                          value={edit?.allDay ? (edit.localValue.split("T")[0] ?? "") : (edit?.localValue ?? "")}
                          onChange={(event) => updateEdit(deadline.id, {
                            localValue: edit?.allDay && event.target.value
                              ? `${event.target.value}T00:00`
                              : event.target.value,
                            confirmed: false,
                          })}
                        />
                      </label>
                      <label className="confirm-date-check">
                        <input
                          type="checkbox"
                          disabled={busy}
                          checked={edit?.allDay ?? deadline.all_day}
                          onChange={(event) => updateEdit(deadline.id, {
                            allDay: event.target.checked,
                            localValue: event.target.checked && edit?.localValue
                              ? `${edit.localValue.split("T")[0]}T00:00`
                              : edit?.localValue ?? "",
                            confirmed: false,
                          })}
                        />
                        Treat this as an all-day deadline
                      </label>
                      <label>
                        <span>IANA timezone</span>
                        <input
                          type="text"
                          disabled={busy}
                          value={edit?.timezone ?? deadline.timezone}
                          placeholder="Asia/Singapore"
                          maxLength={100}
                          onChange={(event) => updateEdit(deadline.id, {
                            timezone: event.target.value,
                            confirmed: false,
                          })}
                        />
                      </label>
                      <label className="confirm-date-check">
                        <input
                          type="checkbox"
                          checked={edit?.confirmed ?? false}
                          disabled={
                            !edit?.localValue
                            || !edit?.timezone.trim()
                            || !edit?.title.trim()
                            || !effectiveDate
                            || busy
                          }
                          onChange={(event) => updateEdit(deadline.id, { confirmed: event.target.checked })}
                        />
                        I checked this against the source
                      </label>
                      <small className="deadline-timezone-note">
                        Interpreted in {edit?.timezone || deadline.timezone}. Check the tender's
                        stated timezone before confirming. Editing removes this date from the sync
                        selection until you confirm and select it again.
                      </small>
                      {edit?.localValue && edit?.timezone.trim() && !effectiveDate && (
                        <small className="deadline-correction-error" role="alert">
                          This local time is invalid or occurs twice in that timezone. Check the
                          tender and choose an unambiguous time before syncing.
                        </small>
                      )}
                    </div>
                  )}
                  <SourceCitation source={deadline.source} />
                  {result && (
                    <div className={`calendar-item-result result-${result.status.toLowerCase()}`}>
                      <span>{result.status.replaceAll("_", " ")}</span>
                      {eventLink && (
                        <a href={eventLink} target="_blank" rel="noreferrer">
                          Open event <ExternalLink size={12} />
                        </a>
                      )}
                      {result.error && <small>{result.error}</small>}
                    </div>
                  )}
                </div>
              </article>
            );
          }) : <p className="studio-muted deadline-empty">No dates were confidently extracted. Review the original tender manually.</p>}
        </div>
      </section>

      <aside className="panel calendar-panel" aria-labelledby="calendar-heading">
        <div className="studio-panel-heading compact">
          <div>
            <span className="eyebrow">Calendar destination</span>
            <h2 id="calendar-heading">Google Calendar</h2>
          </div>
          {loadingStatus ? (
            <span role="status" aria-label="Checking calendar connection">
              <LoaderCircle className="spin" size={18} aria-hidden="true" />
            </span>
          ) : calendar?.connected ? (
            <CheckCircle2 className="connected-icon" size={20} aria-hidden="true" />
          ) : (
            <CalendarPlus size={20} aria-hidden="true" />
          )}
        </div>
        <div className={`calendar-connection ${calendar?.connected ? "connected" : ""}`}>
          <strong>{calendar?.connected ? "Calendar connected" : calendar?.configured ? "Ready to connect" : "Google sync is not configured"}</strong>
          <p>{calendar?.connected
            ? calendar.account_email || "Authorized Google account"
            : calendar?.message || "Connect securely to create or update events without duplicates."}</p>
          {calendar?.connected ? (
            <button type="button" className="studio-secondary-button" onClick={() => void refreshCalendarStatus()} disabled={loadingStatus || busy}>
              <RefreshCcw size={14} aria-hidden="true" /> Refresh connection
            </button>
          ) : calendar?.configured ? (
            <div className="connection-actions">
              <button type="button" className="studio-primary-button" onClick={connectGoogle} disabled={busy}>
                <CalendarPlus size={15} /> Connect Google Calendar
              </button>
              {notice && (
                <button
                  type="button"
                  className="text-button"
                  onClick={() => void refreshCalendarStatus()}
                  disabled={loadingStatus || busy}
                >
                  Refresh connection
                </button>
              )}
            </div>
          ) : null}
        </div>

        <fieldset className="reminder-settings">
          <legend>Automatic reminders</legend>
          {[[10080, "7 days before"], [1440, "1 day before"], [120, "2 hours before"]].map(([minutes, label]) => (
            <label key={minutes}>
              <input
                type="checkbox"
                disabled={busy || loadingSavedState}
                checked={reminders.has(minutes as number)}
                onChange={() => toggleReminder(minutes as number)}
              />
              <span className="check-control" aria-hidden="true"><Check size={12} /></span>
              {label}
            </label>
          ))}
        </fieldset>
        <label className="calendar-escalation-setting">
          <input
            type="checkbox"
            checked={emailEscalations && reminders.size > 0}
            disabled={busy || loadingSavedState || reminders.size === 0}
            onChange={(event) => {
              setEmailEscalations(event.target.checked);
              setNotificationSettingsDirty(true);
              clearSyncFeedback();
            }}
          />
          <span>
            <strong>Email escalation reminders</strong>
            <small>
              Also email the connected calendar owner at the earliest selected checkpoints,
              within Google's five-reminder limit.
            </small>
          </span>
        </label>
        <label className="attendee-field">
          <span>Team escalation recipients <small>Optional</small></span>
          <textarea
            rows={3}
            disabled={busy || loadingSavedState}
            value={attendees}
            onChange={(event) => {
              setAttendees(event.target.value);
              setNotificationSettingsDirty(true);
              clearSyncFeedback();
            }}
            placeholder="teammate@example.com"
          />
          <small>
            Separate addresses with commas. Google sends invitation and update notifications;
            each recipient's own Calendar settings control their deadline reminders.
          </small>
        </label>

        <button
          type="button"
          className="studio-primary-button calendar-sync-button"
          disabled={
            !calendar?.connected
            || !savedStateReady
            || selected.size === 0
            || busy
          }
          onClick={() => void syncCalendar()}
          aria-busy={busy}
        >
          {busy
            ? <LoaderCircle className="spin" size={16} aria-hidden="true" />
            : <CalendarPlus size={16} aria-hidden="true" />}
          {busy
            ? "Syncing deadlines…"
            : loadingSavedState
              ? "Restoring saved calendar settings…"
              : `Sync ${selected.size || "selected"} to Google Calendar`}
        </button>
        <div className="export-divider"><span>or export dates not flagged for review</span></div>
        <button
          type="button"
          className="studio-secondary-button calendar-export-button"
          onClick={() => void downloadIcs()}
          disabled={
            busy
            || calendar?.ics_available === false
            || !analysis.deadlines.some((item) => item.deadline_at && !item.needs_review)
          }
        >
          <Download size={15} aria-hidden="true" /> Export calendar (.ics)
        </button>
        <small className="calendar-export-note">
          The .ics file contains only dated items the analysis did not flag for review. Local
          corrections, attendees and reminder settings apply to Google sync only; still verify
          every exported date against the tender.
        </small>
        <p className="calendar-honesty-note">
          Tiered popup/email reminders and attendee notifications are sent through Google. Delivery
          is not guaranteed, so assign an accountable owner to every critical deadline.
        </p>
        {error && <div className="studio-alert studio-alert-error" role="alert"><AlertCircle size={17} />{error}</div>}
        {notice && <div className="studio-inline-status" role="status"><CheckCircle2 size={15} />{notice}</div>}
      </aside>
    </div>
  );
}

export function StartupStudio() {
  const [activeTab, setActiveTab] = useState<StudioTab>(activeTabFromHash);
  const [analysis, setAnalysis] = useState<TenderAnalysis | null>(null);
  const [session, setSession] = useState<ProposalSession | null>(null);
  const [resumeNotice, setResumeNotice] = useState<string | null>(null);

  useEffect(() => {
    const savedAnalysisId = analysisIdFromHash() || window.sessionStorage.getItem(ANALYSIS_STORAGE_KEY);
    if (!savedAnalysisId) return;
    const controller = new AbortController();
    startupApi.getAnalysis(savedAnalysisId, controller.signal)
      .then(setAnalysis)
      .catch((reason: unknown) => {
        if (!isAbort(reason)) {
          window.sessionStorage.removeItem(ANALYSIS_STORAGE_KEY);
          setResumeNotice("Your previous analysis could not be restored. Upload the tender again.");
        }
      });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!analysis || !session?.analysis_id || session.analysis_id === analysis.id) return;
    setSession(null);
    window.sessionStorage.removeItem(SESSION_STORAGE_KEY);
  }, [analysis, session]);

  useEffect(() => {
    const savedSessionId = window.sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (!savedSessionId) return;
    const controller = new AbortController();
    startupApi.getProposalSession(savedSessionId, controller.signal)
      .then(setSession)
      .catch((reason: unknown) => {
        if (!isAbort(reason)) window.sessionStorage.removeItem(SESSION_STORAGE_KEY);
      });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    const handleNavigation = () => setActiveTab(activeTabFromHash());
    window.addEventListener("hashchange", handleNavigation);
    window.addEventListener("popstate", handleNavigation);
    return () => {
      window.removeEventListener("hashchange", handleNavigation);
      window.removeEventListener("popstate", handleNavigation);
    };
  }, []);

  function selectTab(tab: StudioTab) {
    setActiveTab(tab);
    const analysisQuery = analysis ? `?analysis=${encodeURIComponent(analysis.id)}` : "";
    window.history.pushState(null, "", `#startup/${tab}${analysisQuery}`);
  }

  function handleTabKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
    event.preventDefault();
    const currentIndex = tabOrder.indexOf(activeTab);
    const delta = event.key === "ArrowRight" ? 1 : -1;
    const nextTab = tabOrder[(currentIndex + delta + tabOrder.length) % tabOrder.length];
    selectTab(nextTab);
    document.getElementById(`studio-tab-${nextTab}`)?.focus();
  }

  function completeAnalysis(result: TenderAnalysis) {
    setAnalysis(result);
    setSession(null);
    window.sessionStorage.setItem(ANALYSIS_STORAGE_KEY, result.id);
    window.sessionStorage.removeItem(SESSION_STORAGE_KEY);
    setResumeNotice(null);
  }

  function updateSession(result: ProposalSession) {
    setSession(result);
    window.sessionStorage.setItem(SESSION_STORAGE_KEY, result.id);
  }

  return (
    <div className="startup-studio">
      <header className="startup-hero">
        <div className="hero-grid-glow" />
        <div className="page-width startup-hero-content">
          <div>
            <span className="startup-kicker"><Rocket size={14} /> Startup tender workspace</span>
            <h1>From intimidating tender to a plan your team can execute</h1>
            <p>Decode requirements, practise your pitch, and protect every deadline—without pretending the AI replaces human review.</p>
          </div>
          <div className="startup-context-card">
            <span>Active tender</span>
            <strong>{analysis?.overview.tender_title || "No document analysed yet"}</strong>
            <small>{analysis
              ? `${analysis.document.page_count === null ? "Page count unavailable" : `${analysis.document.page_count} pages`} · ${analysis.deadlines.length} dates found`
              : "Start with an ITT or ITQ document"}</small>
          </div>
        </div>
      </header>

      <main className="page-width studio-main">
        <div className="studio-tabs" role="tablist" aria-label="Startup Studio tools" onKeyDown={handleTabKeyDown}>
          <button
            id="studio-tab-decipher"
            type="button"
            role="tab"
            aria-selected={activeTab === "decipher"}
            aria-controls="studio-panel"
            tabIndex={activeTab === "decipher" ? 0 : -1}
            className={activeTab === "decipher" ? "active" : ""}
            onClick={() => selectTab("decipher")}
          >
            <span><FileText size={17} /></span>
            <div><small>Step 1</small><strong>Decipher tender</strong></div>
            {analysis && <CheckCircle2 className="tab-complete" size={15} />}
          </button>
          <button
            id="studio-tab-proposal"
            type="button"
            role="tab"
            aria-selected={activeTab === "proposal"}
            aria-controls="studio-panel"
            tabIndex={activeTab === "proposal" ? 0 : -1}
            className={activeTab === "proposal" ? "active" : ""}
            onClick={() => selectTab("proposal")}
          >
            <span><MessageSquare size={17} /></span>
            <div><small>Step 2</small><strong>Build proposal</strong></div>
            {session?.draft && <CheckCircle2 className="tab-complete" size={15} />}
          </button>
          <button
            id="studio-tab-milestones"
            type="button"
            role="tab"
            aria-selected={activeTab === "milestones"}
            aria-controls="studio-panel"
            tabIndex={activeTab === "milestones" ? 0 : -1}
            className={activeTab === "milestones" ? "active" : ""}
            onClick={() => selectTab("milestones")}
          >
            <span><CalendarClock size={17} /></span>
            <div><small>Step 3</small><strong>Sync milestones</strong></div>
            {analysis && <b>{analysis.deadlines.length}</b>}
          </button>
        </div>

        {resumeNotice && <div className="studio-alert studio-alert-warning" role="status"><AlertTriangle size={17} />{resumeNotice}</div>}

        <section
          id="studio-panel"
          role="tabpanel"
          aria-labelledby={`studio-tab-${activeTab}`}
          tabIndex={0}
          className="studio-tab-panel"
        >
          {activeTab === "decipher" && (
            <TenderDecipher analysis={analysis} onAnalysisComplete={completeAnalysis} onContinue={selectTab} />
          )}
          {activeTab === "proposal" && (
            <ProposalBuilder analysis={analysis} session={session} onSessionChange={updateSession} onStartAnalysis={() => selectTab("decipher")} />
          )}
          {activeTab === "milestones" && (
            <MilestoneSync analysis={analysis} onStartAnalysis={() => selectTab("decipher")} />
          )}
        </section>
      </main>
    </div>
  );
}

export default StartupStudio;
