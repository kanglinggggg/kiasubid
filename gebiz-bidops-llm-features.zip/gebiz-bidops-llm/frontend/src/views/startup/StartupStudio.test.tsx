import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

import App from "../../App";
import type { ProposalSession, TenderAnalysis } from "../../types/startup";
import {
  calendarReminderRules,
  PROPOSAL_ANSWER_MAX_CHARACTERS,
  rfc3339FromLocal,
  StartupStudio,
} from "./StartupStudio";

const apiMocks = vi.hoisted(() => ({
  createAnalysisJob: vi.fn(),
  getAnalysisJob: vi.fn(),
  getAnalysis: vi.fn(),
  createProposalSession: vi.fn(),
  getProposalSession: vi.fn(),
  submitProposalAnswer: vi.fn(),
  generateProposal: vi.fn(),
  getCalendarStatus: vi.fn(),
  getCalendarState: vi.fn(),
  getGoogleCalendarAuthorizationUrl: vi.fn(() => "/api/startup/calendar/google/authorize"),
  downloadCalendarIcs: vi.fn(),
  syncCalendar: vi.fn(),
}));

vi.mock("../../api/startup", async () => {
  const actual = await vi.importActual<typeof import("../../api/startup")>("../../api/startup");
  return { ...actual, startupApi: apiMocks };
});

vi.mock("../BidControlRoom", () => ({
  BidControlRoom: () => <main><h1>SME workspace test double</h1></main>,
}));

const analysisFixture: TenderAnalysis = {
  id: "ANALYSIS-001",
  mode: "BEDROCK",
  model_id: "example.tender-model-v1",
  document: {
    filename: "cybersecurity-itt.pdf",
    media_type: "application/pdf",
    page_count: 312,
    character_count: 420_000,
    sha256: "a".repeat(64),
    scanned_pages: [],
  },
  overview: {
    tender_title: "Cybersecurity Monitoring Platform",
    agency: "Example Government Agency",
    reference_number: "EGA/ITT/2026/17",
    summary: "The agency wants a monitored security platform with a staged rollout.",
    buyer_goal: "Detect incidents quickly and keep essential services available.",
  },
  product_features: [
    {
      id: "FEATURE-1",
      title: "Round-the-clock monitoring",
      plain_english: "Watch the agency systems continuously and respond to alerts.",
      obligation_level: "MANDATORY",
      acceptance_criteria: ["Monitoring operates 24 hours a day"],
      source: { page: 17, section: "4.2", snippet: "The Tenderer shall provide 24x7 monitoring." },
    },
  ],
  delivery_phases: [
    {
      id: "PHASE-1",
      sequence: 1,
      name: "Deployment",
      deliverables: ["Configured monitoring service"],
      timing: "Within six weeks of award",
      due_at: null,
      source: { page: 31, section: "7.1", snippet: "Deployment shall complete within six weeks." },
      sources: [
        { page: 31, section: "7.1", snippet: "Deployment shall complete within six weeks." },
        { page: 32, section: "7.2", snippet: "Acceptance testing follows deployment." },
      ],
    },
  ],
  payment_milestones: [
    {
      id: "PAYMENT-1",
      milestone: "Deployment acceptance",
      trigger: "Agency signs the acceptance certificate",
      amount: "30%",
      timing: "After phase one acceptance",
      due_at: null,
      source: { page: 42, section: "9.3", snippet: "Thirty percent is payable upon acceptance." },
      sources: [
        { page: 42, section: "9.3", snippet: "Thirty percent is payable upon acceptance." },
        { page: 43, section: "9.4", snippet: "Payment follows the signed certificate." },
      ],
    },
  ],
  deadlines: [
    {
      id: "DEADLINE-1",
      kind: "SUBMISSION",
      title: "Tender submission",
      date_text: "30 September 2026, 4:00 PM Singapore time",
      deadline_at: "2026-09-30T16:00:00+08:00",
      all_day: false,
      timezone: "Asia/Singapore",
      confidence: "HIGH",
      needs_review: false,
      source: { page: 3, section: "1.4", snippet: "Submissions close at 4:00 PM on 30 September 2026." },
    },
  ],
  eligibility_requirements: [],
  startup_checklist: [
    {
      id: "CHECKLIST-1",
      title: "Confirm monitoring evidence",
      description: "Prepare evidence that the 24x7 monitoring control is staffed.",
      category: "Technical",
      priority: "HIGH",
      due_at: null,
      supporting_fact_ids: ["FACT-1", "FACT-2"],
      sources: [
        {
          page: 18,
          section: "4.5",
          snippet: "The Tenderer shall provide a staffing plan for 24x7 monitoring.",
        },
        {
          page: 19,
          section: "4.6",
          snippet: "The Tenderer shall attach evidence of responder availability.",
        },
      ],
    },
  ],
  risks: [],
  clarification_questions: [],
  glossary: [],
  warnings: [],
  human_review_required: true,
};

const proposalSessionFixture: ProposalSession = {
  id: "PROPOSAL-001",
  analysis_id: analysisFixture.id,
  company_name: "Student Startup",
  solution_name: "Secure Portal",
  status: "IN_PROGRESS",
  revision: 0,
  progress: { answered: 0, total: 5, percent: 0 },
  current_question: {
    id: "Q-SOLUTION",
    section: "SOLUTION",
    question: "How will your solution meet the buyer's needs?",
    why_it_matters: "The evaluator needs a concrete response.",
    answer_guidance: ["Explain the approach in plain language."],
    required: true,
    context_refs: ["FEATURE-1"],
  },
  questions: [],
  answers: [],
  last_feedback: null,
  draft: null,
  mode: "BEDROCK",
  model_id: "example.tender-model-v1",
};

const reviewAnalysisFixture: TenderAnalysis = {
  ...analysisFixture,
  id: "ANALYSIS-REVIEW",
  deadlines: [{
    ...analysisFixture.deadlines[0]!,
    deadline_at: null,
    confidence: "LOW",
    needs_review: true,
  }],
};

function oneFile(file: File) {
  return {
    0: file,
    length: 1,
    item(index: number) {
      return index === 0 ? file : null;
    },
  } as unknown as FileList;
}

describe("Startup Studio", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    window.localStorage.clear();
    window.sessionStorage.clear();
    window.history.replaceState(null, "", "#startup/decipher");
    apiMocks.getCalendarStatus.mockResolvedValue({
      configured: false,
      connected: false,
      provider: "GOOGLE",
      account_email: null,
      reauthorization_required: false,
      scope: null,
      ics_available: true,
      message: "Google Calendar is not configured.",
    });
    apiMocks.getCalendarState.mockResolvedValue({
      analysis_id: analysisFixture.id,
      calendar_id: "primary",
      deadlines: [],
    });
  });

  it("converts reviewed wall-clock deadlines in their IANA timezone", () => {
    expect(rfc3339FromLocal("2026-07-01T09:30", "America/New_York")).toBe(
      "2026-07-01T09:30:00-04:00",
    );
    expect(rfc3339FromLocal("2026-12-01T09:30", "America/New_York")).toBe(
      "2026-12-01T09:30:00-05:00",
    );
    expect(rfc3339FromLocal("2026-03-08T02:30", "America/New_York")).toBeNull();
    expect(rfc3339FromLocal("2026-11-01T01:30", "America/New_York")).toBeNull();
    expect(rfc3339FromLocal("2026-09-30T16:00", "Not/A_Timezone")).toBeNull();
  });

  it("creates tiered popup and email escalation reminders within Google's limit", () => {
    expect(calendarReminderRules([10080, 1440, 120], true)).toEqual([
      { method: "popup", minutes: 10080 },
      { method: "popup", minutes: 1440 },
      { method: "popup", minutes: 120 },
      { method: "email", minutes: 10080 },
      { method: "email", minutes: 1440 },
    ]);
    expect(calendarReminderRules([120], false)).toEqual([
      { method: "popup", minutes: 120 },
    ]);
  });

  it("requires review before selecting a corrected all-day deadline and sends a grounded override", async () => {
    window.sessionStorage.setItem(
      "gebiz-bidops.startup.analysis-id",
      reviewAnalysisFixture.id,
    );
    window.history.replaceState(
      null,
      "",
      `#startup/milestones?analysis=${reviewAnalysisFixture.id}`,
    );
    apiMocks.getAnalysis.mockResolvedValue(reviewAnalysisFixture);
    apiMocks.getCalendarStatus.mockResolvedValue({
      configured: true,
      connected: true,
      provider: "GOOGLE",
      account_email: "owner@example.com",
      reauthorization_required: false,
      scope: "https://www.googleapis.com/auth/calendar.events",
      ics_available: true,
      message: "Google Calendar is connected.",
    });
    apiMocks.syncCalendar.mockResolvedValue({
      status: "COMPLETE",
      calendar_id: "primary",
      results: [{
        deadline_id: "DEADLINE-1",
        status: "CREATED",
        event_id: "event-1",
        event_link: "https://calendar.google.com/event?eid=event-1",
        error: null,
        payload_hash: "hash-1",
      }],
    });

    const { container } = render(<StartupStudio />);

    const deadlineSelector = await screen.findByRole("checkbox", {
      name: "Select Tender submission for calendar sync",
    });
    await screen.findByText("Calendar connected");
    expect(deadlineSelector).toBeDisabled();

    fireEvent.click(screen.getByRole("checkbox", {
      name: "Treat this as an all-day deadline",
    }));
    fireEvent.change(screen.getByLabelText("Confirmed date"), {
      target: { value: "2026-09-30" },
    });
    expect(container.querySelector("time")).toHaveAttribute(
      "datetime",
      "2026-09-30T12:00:00+08:00",
    );
    fireEvent.click(screen.getByRole("checkbox", {
      name: "I checked this against the source",
    }));
    expect(deadlineSelector).toBeEnabled();

    fireEvent.click(deadlineSelector);
    fireEvent.click(screen.getByRole("button", {
      name: "Sync 1 to Google Calendar",
    }));

    await waitFor(() => expect(apiMocks.syncCalendar).toHaveBeenCalledWith(
      reviewAnalysisFixture.id,
      {
        deadline_ids: ["DEADLINE-1"],
        reminder_minutes: [10080, 1440, 120],
        reminders: [
          { method: "popup", minutes: 10080 },
          { method: "popup", minutes: 1440 },
          { method: "popup", minutes: 120 },
          { method: "email", minutes: 10080 },
          { method: "email", minutes: 1440 },
        ],
        attendees: [],
        deadline_overrides: [{
          deadline_id: "DEADLINE-1",
          deadline_at: "2026-09-30T12:00:00+08:00",
          all_day: true,
          timezone: "Asia/Singapore",
          title: "Tender submission",
          confirmed: true,
        }],
      },
    ));
  });

  it("hydrates saved deadline corrections and preserves their exact notification payload", async () => {
    window.sessionStorage.setItem("gebiz-bidops.startup.analysis-id", analysisFixture.id);
    window.history.replaceState(
      null,
      "",
      `#startup/milestones?analysis=${analysisFixture.id}`,
    );
    apiMocks.getAnalysis.mockResolvedValue(analysisFixture);
    apiMocks.getCalendarStatus.mockResolvedValue({
      configured: true,
      connected: true,
      provider: "GOOGLE",
      account_email: "owner@example.com",
      reauthorization_required: false,
      scope: "https://www.googleapis.com/auth/calendar.events",
      ics_available: true,
      message: "Google Calendar is connected.",
    });
    apiMocks.getCalendarState.mockResolvedValue({
      analysis_id: analysisFixture.id,
      calendar_id: "primary",
      deadlines: [{
        deadline_id: "DEADLINE-1",
        calendar_id: "primary",
        override: {
          deadline_id: "DEADLINE-1",
          deadline_at: "2026-09-30T18:30:00+08:00",
          all_day: false,
          timezone: "Asia/Singapore",
          title: "Corrected tender closing",
          confirmed: true,
        },
        reminders: [
          { method: "popup", minutes: 1440 },
          { method: "email", minutes: 120 },
        ],
        attendees: ["ops@example.com", "founder@example.com"],
        event_id: "event-1",
        event_link: "https://calendar.google.com/event?eid=event-1",
        payload_hash: "hash-1",
        status: "UPDATED",
        last_synced_at: "2026-09-09T12:00:00Z",
      }],
    });
    apiMocks.syncCalendar.mockResolvedValue({
      status: "COMPLETE",
      calendar_id: "primary",
      results: [],
    });

    render(<StartupStudio />);

    expect(await screen.findByDisplayValue(
      "ops@example.com, founder@example.com",
    )).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", {
      name: "Sync 1 to Google Calendar",
    }));

    await waitFor(() => expect(apiMocks.syncCalendar).toHaveBeenCalledWith(
      analysisFixture.id,
      expect.objectContaining({
        deadline_overrides: [expect.objectContaining({
          deadline_id: "DEADLINE-1",
          deadline_at: "2026-09-30T18:30:00+08:00",
          title: "Corrected tender closing",
          confirmed: true,
          reminders: [
            { method: "popup", minutes: 1440 },
            { method: "email", minutes: 120 },
          ],
          attendees: ["ops@example.com", "founder@example.com"],
        })],
      }),
    ));
  });

  it("switches between the SME and Startup workspaces and updates the URL", () => {
    window.history.replaceState(null, "", "#sme");
    render(<App />);

    const smeButton = screen.getByRole("button", { name: /SME Control Room/i });
    const startupButton = screen.getByRole("button", { name: /Startup Studio/i });
    expect(smeButton).toHaveAttribute("aria-pressed", "true");

    fireEvent.click(startupButton);

    expect(window.location.hash).toBe("#startup/decipher");
    expect(startupButton).toHaveAttribute("aria-pressed", "true");
    expect(screen.getByRole("heading", { name: /From intimidating tender/i })).toBeInTheDocument();

    fireEvent.click(smeButton);
    expect(window.location.hash).toBe("#sme");
    expect(screen.getByRole("heading", { name: "SME workspace test double" })).toBeInTheDocument();
  });

  it("announces an unsupported upload and leaves analysis unavailable", () => {
    render(<StartupStudio />);
    const input = screen.getByLabelText(/Choose or drop a tender document/i, {
      selector: "input",
    });

    fireEvent.change(input, {
      target: {
        files: oneFile(
          new File(["not supported"], "requirements.xlsx", {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          }),
        ),
      },
    });

    expect(screen.getByRole("alert")).toHaveTextContent(
      "Choose a non-empty PDF, DOCX, Markdown or plain-text tender document.",
    );
    expect(screen.getByRole("button", { name: /Analyse tender/i })).toBeDisabled();
    expect(apiMocks.createAnalysisJob).not.toHaveBeenCalled();
  });

  it("supports arrow-key tab navigation and explains the B2 and B3 prerequisites", async () => {
    render(<StartupStudio />);
    const tabs = screen.getAllByRole("tab");

    fireEvent.keyDown(tabs[0], { key: "ArrowRight" });

    expect(tabs[1]).toHaveFocus();
    expect(tabs[1]).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("heading", { name: /Analyse a tender before building its proposal/i })).toBeInTheDocument();

    fireEvent.keyDown(tabs[1], { key: "ArrowRight" });

    expect(tabs[2]).toHaveFocus();
    expect(tabs[2]).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("heading", { name: /Analyse a tender to reveal its hidden dates/i })).toBeInTheDocument();
    await waitFor(() => expect(apiMocks.getCalendarStatus).toHaveBeenCalledTimes(1));
  });

  it("hands a completed B1 analysis into the proposal builder", async () => {
    apiMocks.createAnalysisJob.mockResolvedValue({
      id: "JOB-001",
      status: "COMPLETED",
      stage: "Complete",
      progress: 100,
      analysis_id: analysisFixture.id,
      error: null,
    });
    apiMocks.getAnalysis.mockResolvedValue(analysisFixture);
    render(<StartupStudio />);
    const file = new File(["Tender body"], analysisFixture.document.filename, {
      type: "application/pdf",
    });
    const input = screen.getByLabelText(/Choose or drop a tender document/i, {
      selector: "input",
    });

    fireEvent.change(input, { target: { files: oneFile(file) } });
    fireEvent.click(screen.getByRole("button", { name: /Analyse tender/i }));

    expect(
      await screen.findByRole("heading", { name: analysisFixture.overview.tender_title! }),
    ).toBeInTheDocument();
    expect(screen.getByText("Round-the-clock monitoring")).toBeInTheDocument();
    expect(screen.getByText("Deployment acceptance")).toBeInTheDocument();
    expect(screen.getByText("Acceptance testing follows deployment.")).toBeInTheDocument();
    expect(screen.getByText("Payment follows the signed certificate.")).toBeInTheDocument();
    const checklistSources = screen.getByRole("group", {
      name: "Sources for Confirm monitoring evidence",
    });
    expect(checklistSources).toHaveTextContent("Page 18 · 4.5");
    expect(checklistSources).toHaveTextContent("Page 19 · 4.6");
    expect(checklistSources).toHaveTextContent("staffing plan for 24x7 monitoring");
    expect(checklistSources).toHaveTextContent("evidence of responder availability");
    expect(window.sessionStorage.getItem("gebiz-bidops.startup.analysis-id")).toBe(
      analysisFixture.id,
    );
    expect(apiMocks.createAnalysisJob).toHaveBeenCalledWith(
      expect.objectContaining({ file }),
      expect.any(AbortSignal),
    );

    fireEvent.click(screen.getByRole("button", { name: /Build the proposal/i }));

    expect(screen.getByRole("heading", { name: /Explain your idea like you would to a mentor/i })).toBeInTheDocument();
    expect(screen.getAllByText(analysisFixture.overview.tender_title!).length).toBeGreaterThan(0);
  });

  it("shows and enforces the shared proposal answer character limit", async () => {
    window.history.replaceState(
      null,
      "",
      `#startup/proposal?analysis=${analysisFixture.id}`,
    );
    window.sessionStorage.setItem(
      "gebiz-bidops.startup.analysis-id",
      analysisFixture.id,
    );
    window.sessionStorage.setItem(
      "gebiz-bidops.startup.proposal-session-id",
      proposalSessionFixture.id,
    );
    apiMocks.getAnalysis.mockResolvedValue(analysisFixture);
    apiMocks.getProposalSession.mockResolvedValue(proposalSessionFixture);

    render(<StartupStudio />);

    const answer = await screen.findByLabelText(/Your answer—in simple words/i);
    expect(answer).toHaveAttribute(
      "maxlength",
      PROPOSAL_ANSWER_MAX_CHARACTERS.toString(),
    );
    expect(screen.getByText(/0 \/ 4,000 characters/i)).toBeInTheDocument();
  });
});
