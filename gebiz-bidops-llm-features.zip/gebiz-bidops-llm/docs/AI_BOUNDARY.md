# Runtime AI boundary

GeBIZ BidOps uses one selected provider for its language work: Amazon Bedrock Runtime's Converse
API or Groq's OpenAI-compatible Chat Completions API. Calls use near-zero temperature and request
JSON output. Responses are parsed into strict Pydantic models, checked against trusted source
state, and retried once by default when a repair is possible. A configured provider name is never
reported as having produced a result until that result has been validated and persisted.

Tender contents are untrusted data. Text inside an uploaded document that asks the model to ignore
instructions, reveal prompts, call tools, or choose a business outcome has no authority. The model
clients expose no tools. Model output reaches an application workflow only through its typed
schema and additional grounding checks.

## SME Control Room model jobs

The original Control Room gives the selected model two bounded interpretation jobs:

1. **Tender Requirement Interpretation** converts supplied tender page/section text into validated
   `StructuredRequirement` records. It preserves document, page, section, and an exact source
   snippet. Ambiguous details must be returned as `UNCERTAIN` and left null.
2. **Corrigendum Semantic Change Interpretation** compares one existing structured requirement
   with new corrigendum text. It returns `ADDED`, `MODIFIED`, `REMOVED`, or `UNCHANGED`, the affected
   stable key when identifiable, and the exact structured fields changed.

Source document, page, and section come from the trusted request envelope. A non-contiguous or
fabricated source snippet fails validation and is retried; it is not silently accepted. After
validation, ordinary code maps typed procurement rules into the supported requirement vocabulary.
It may normalize vocabulary aliases, but it cannot add a missing qualification, count, deadline,
or criticality. A duration without an authoritative date remains deadline-null.

The model output cannot set an assessment, feasibility state, coverage percentage, task, or
deadline risk. The main corrigendum flow proceeds only when the validated change satisfies its
guard conditions; otherwise it stops before superseding an assessment.

## Startup Studio model jobs

Startup Studio adds three connected, persisted workflows. These use the same selected provider but
do not use the synthetic Control Room fallback.

### B1: Tender Jargon Decipher

Ordinary code first validates the upload, extracts machine-readable blocks, enforces byte, page,
character, archive, and chunk limits, and calculates document metadata. The model receives bounded
chunks with stable block identifiers. It extracts typed, source-backed facts and then synthesizes
them into a plain-English overview, product features, delivery phases, payment milestones,
deadlines, eligibility requirements, a startup checklist, risks, clarification questions, and a
glossary.

Grounding checks require referenced block identifiers to exist and supporting snippets to match the
extracted text. Critical deadline fields are tied back to deadline facts. Unparseable or ambiguous
dates remain unresolved and require human review; the model is not permitted to invent a date from
a duration or an implication. The persisted analysis reports the actual provider, model, attempts,
latency, and token counts returned by the provider boundary.

PDF extraction is text extraction, not OCR. An image-only or extremely sparse PDF fails with an
OCR-required error rather than being sent to the model as if it contained usable text. DOCX,
UTF-8/UTF-16 text, and Markdown extraction also happens locally before any model call. Complex
tables, diagrams, footnotes, and reading order can still be imperfect and require comparison with
the original document.

### B2: Guided Proposal Builder

The model uses the validated B1 analysis and the team's supplied company and solution names to
create a bounded interview plan. For each conversational answer it returns a mentor critique, a
procurement-style reformulation, and at most one targeted follow-up. The application persists the
question, raw answer, feedback, revision, and progress so stale browser writes are rejected. A
per-answer ceiling plus aggregate answer and prompt budgets stop oversized sessions before a model
call.

Draft generation receives the same compacted analysis context and the team's recorded answers.
The result is validated section data that ordinary code renders as Markdown. Exact quotations of
team answers must be traceable, and new numeric claims are rejected when they were not present in
the tender context or team answers. These controls reduce unsupported claims; they do not guarantee
that a generated statement is true, compliant, persuasive, or legally sufficient. The draft is
never submitted to GeBIZ.

### B3: Smart Milestone Sync

The model's role ends with B1's source-backed deadline extraction. Date review, overrides, reminder
validation, `.ics` generation, OAuth state/PKCE handling, token refresh, deterministic Google event
identifiers, and create/update decisions are ordinary code. Unresolved or review-required dates are
not silently converted into events; the user must provide and confirm a correction before sync.

Google Calendar sync requests only the `calendar.events` scope. Access and refresh tokens are
encrypted at rest using a key derived from the application secret and are associated with a
browser-scoped session in this local MVP. Reminder delivery is controlled by Google Calendar and
recipient settings, so reminders are not a guaranteed escalation service. The credential-free
`.ics` export remains available when OAuth is not configured.

## Deterministic Control Room execution

After interpretation, ordinary code controls all of the following:

- immutable requirement version creation;
- assessment superseding;
- CISSP, CV, validity, and availability evidence matching;
- requirement assessment;
- four-state Operational Feasibility;
- Critical Gates and Submission Coverage;
- recovery candidate selection and dependency-aware recovery tasks;
- Deadline Risk;
- SQLite persistence, calculation traces, audit events, and the UI read model.

LangGraph sequences these deterministic mutations, but LangGraph itself is not an LLM. Assessments
remain labelled `RULE` because no assessment is model-generated. Startup Studio is a separate
workflow and does not alter these feasibility calculations.

## Demo fallback

If the selected provider is not configured, unavailable, or repeatedly returns malformed structured
output, a deliberately narrow rule-based parser can handle the synthetic main Control Room fixture.
This is not an LLM. The UI displays `Interpretation: Bedrock` or `Interpretation: Groq` only after
a completed workflow has persisted that actual provider mode; configuration alone is not enough.
Otherwise the Control Room displays `Interpretation: Demo fallback`.

The fallback understands the demo's CISSP manpower count amendment, explicit removal,
equivalent-count wording, obvious deadline-only changes, and ambiguous clauses. Unmatched language
returns `UNCERTAIN`; it does not guess.
Instruction-like source text addressed to a model or AI also returns `UNCERTAIN` and cannot apply a
change through the fallback.

This fallback is never used for uploaded Startup Studio documents, question plans, critiques, or
proposal drafts. Those operations return an explicit provider-unavailable or structured-validation
failure, and the asynchronous analysis job records the failure instead of persisting invented
content.

## Human control

Humans control which tender is uploaded, whether an authorized live provider is configured,
evidence verification, task completion, interpretation and date review, deadline corrections,
Calendar connection and event selection, proposal editing, internal approval, and any real tender
submission. BidOps never submits to GeBIZ or makes a binding legal, compliance, or commercial
decision.

## Evaluation boundary

The evaluation-only harness under `backend/evaluation/` keeps synthetic development fixtures, the
nine known GeBIZ-derived regression cases, and eight teammate-supplied cases frozen in a distinct
blind partition separate. It invokes interpretation with fallback disabled and scores requirement
extraction, corrigendum matching, and ambiguity handling. Final operational state is scored only
when a frozen downstream adapter or deterministic facts exist; multi-obligation cases can supply
one fact set per typed rule. Missing rule/fact bindings fail closed to `UNCERTAIN`; cases with no
adapter are `NOT_RUN`, not fabricated failures or passes. Unsafe-green errors are reported when
ground truth is `BLOCKED` or `UNCERTAIN` but deterministic output becomes `FEASIBLE`. Expected
answers and deterministic facts are never sent to the model. The separate generic-rule benchmark
scores deterministic requirement results and final bid states. Missing source content is handled
by a deterministic safety guard because sending absent text to a model would invite invention.
