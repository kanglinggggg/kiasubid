# Judge Q&A

These answers describe the build we can demonstrate today. They separate working product behavior,
measured Bedrock results, and limitations that still need human review.

The current application has two workspaces: the original **SME Control Room** for the measured R17
corrigendum story, and **Startup Studio** for source-backed document analysis, a guided proposal
mentor, and reviewed deadline export or Google Calendar sync. Historical benchmark figures below
measure the Control Room interpretation boundary, not the new end-to-end Startup Studio workflow.

## Why not ChatGPT plus Excel?

ChatGPT can summarize prose and Excel can track rows, but neither combination automatically gives
us stable requirement identities, immutable versions, evidence links, superseded assessments,
dependency-aware recovery tasks, deterministic gate precedence, or a reproducible audit trail.
BidOps confines the LLM to validated interpretation and drafting jobs. Ordinary code owns source
checks, workflow state, calendar operations, and every operational decision. The value is
controlled, persisted preparation—not an untraceable chat answer.

Evidence to show: R17 v1 remains stored after the corrigendum, its assessment becomes
`SUPERSEDED`, R17 v2 is created, and every visible metric exposes backend calculation details.

## What if the LLM misses a mandatory requirement?

The current MVP cannot guarantee perfect recall. That is the most important remaining model-risk
limitation. It reduces the risk by retaining exact source provenance, validating output with strict
Pydantic schemas, treating document text as untrusted data, refusing invented mandatory details,
and returning `UNCERTAIN` when wording is ambiguous. Blind evaluation is separated from the known
regression set, and unsafe-green errors are reported explicitly. Human review remains required;
BidOps does not represent an extraction as a legal or compliance guarantee.

## Why can Submission Coverage be high while status is BLOCKED?

They answer different questions. Submission Coverage measures preparation completeness with a
fixed formula: 50% current requirement assessments, 30% linked usable evidence, and 20% task
completion. Operational Feasibility uses gate precedence. One known mandatory, unrecoverable gate
forces `BLOCKED` even if nearly every other item is complete. This prevents an average score from
hiding a fatal obligation.

Evidence to show: select **BLOCKED · no fourth engineer**. Coverage remains relatively high while
the feasibility card and unresolved-gate explanation show the blocking reason.

## What is actually Agentic AI here?

BidOps is agentic in a narrow operational sense: it carries a change across the bid instead of
returning a one-off chat answer. LangGraph coordinates requirement versioning, assessment
superseding, evidence rechecks, recovery planning, metric updates, and the audit trail. Every step
reads and writes typed state and stops when the evidence is insufficient. Bedrock interprets the
language; rules make the operational decision; a person keeps final approval and submission.

This is intentionally narrow agency: useful autonomy inside a controlled procurement workflow,
not a bot that can decide or submit a bid on its own.

## What is LLM-driven versus deterministic?

LLM-driven, when a configured provider succeeds:

1. extracting typed requirements from supplied page/section text;
2. interpreting a corrigendum as `ADDED`, `MODIFIED`, `REMOVED`, or `UNCHANGED`, matching a stable
   requirement where possible, and listing changed fields;
3. extracting and synthesizing source-backed plain-English facts from a Startup Studio upload;
4. planning the proposal interview, critiquing and formalizing team answers, and producing the
   grounded proposal draft.

Deterministic:

- Pydantic validation and exact-snippet provenance checks;
- requirement versioning and `SUPERSEDED` lifecycle state;
- evidence matching and assessment calculation;
- generic procurement-rule evaluation;
- `FEASIBLE`, `RECOVERABLE`, `BLOCKED`, `UNCERTAIN` precedence;
- Critical Gates, Submission Coverage, recovery tasks, dependencies, and Deadline Risk;
- duplicate-corrigendum protection and persistence;
- upload validation and text extraction, source-reference checks, date-review gates, `.ics`
  generation, OAuth state/PKCE, token encryption/refresh, and Calendar event upserts.

Human-controlled: source completeness, ambiguous-clause clarification, extracted-date correction,
Calendar event selection, evidence verification, proposal review, commercial judgment, final
approval, and GeBIZ submission.

## How do you handle hallucination and ambiguity?

Model output is accepted only through strict schemas. Source document, page, section, and snippet
must agree with the supplied input, and source snippets must match extracted text. Invalid output is
retried within a small fixed limit and otherwise fails gracefully. Ambiguous Control Room
requirements remain `UNCERTAIN`; unresolved Startup Studio dates remain review-required without a
parsed timestamp. The LLM cannot set feasibility, mark evidence verified, sync a review-required
date without confirmation, or submit anything. Prompt-injection text is treated as document
content, not as an instruction.

The honest limitation is that schema validation cannot prove semantic completeness. That is why
blind cases, unsafe-green reporting, provenance inspection, and human review remain necessary.

## How do corrigenda propagate?

The interpreter compares corrigendum text with an existing structured requirement and returns the
affected stable key plus exact field changes. The workflow creates a new requirement version,
retains the old version, marks only its prior assessment `SUPERSEDED`, rechecks linked evidence,
recomputes the current assessment, creates recovery tasks when justified, and recalculates all
metrics. A deadline-only amendment does not invalidate R17; unrelated changes are isolated; a
duplicate corrigendum returns `409 Conflict` without duplicate versions or tasks.

Evidence to show: **Apply Corrigendum #2** produces R17 minimum `3 → 4`, v1 `SUPERSEDED`, v2
`PARTIAL`, and `FEASIBLE → RECOVERABLE`.

## Why not automatically submit?

Tender submission carries legal declarations, commercial commitments, and irreversible external
effects. The local MVP has no GeBIZ submission integration and deliberately ends at a locked human
checkpoint. Automation supports preparation and verification; an authorized person must review,
approve, and submit through the official channel.

## How is this different from existing GeBIZ functionality?

GeBIZ is the official publication and transaction channel. BidOps does not replace or scrape it.
BidOps is a supplier-side operational control layer after documents are obtained: it turns clauses
into versioned obligations, connects them to internal evidence, detects amendment impact, and makes
the recovery path and deadline consequences visible. There is no claim of privileged GeBIZ data or
an existing GeBIZ integration in this build.

## Why should we trust the percentages and statuses?

The frontend displays backend values and backend-provided trace objects. Operational precedence,
the full mandatory-gate numerator and denominator, the 50/30/20 coverage arithmetic, and the
deadline driver/slack are all deterministic and covered by tests. The UI labels Submission
Coverage as preparation completeness, not a compliance score.

## Does the demo depend on a live model being available?

The original Control Room story does not. Its main synthetic fixture is clearly labelled
**Interpretation: Demo fallback**, so that scenario remains reliable offline. Startup Studio's
document analysis and proposal mentor deliberately require a configured Bedrock or Groq model and
fail visibly instead of applying the fixture-specific fallback. With the active sandbox, Nova Lite has
also completed the live R17 path; the UI changed to **Interpretation: Bedrock** only after that
result was persisted. The post-hardening known regression remains mixed: exact requirement
interpretation passed 6/7, corrigendum matching passed 2/2, ambiguity handling passed 9/9, and
final operational state passed 8/9. The frozen blind-v1 set scored 2/8, not applicable, 7/8, and 4/8
respectively, with zero unsafe-green errors.

## What evidence do you have today?

The quantitative results below are the preserved Control Room validation snapshot. They are not
presented as end-to-end accuracy measurements for the later Startup Studio workflows.

- backend and frontend regression tests;
- Ruff, TypeScript, production build, and npm audit checks;
- a 9/9 GeBIZ-derived deterministic regression benchmark across the six generic rule types;
- mocked Bedrock/Groq boundaries, malformed-output, provenance, ambiguity, injection, semantic
  isolation, duplicate, and R17 end-to-end tests;
- a real Nova Lite Bedrock smoke test and live R17 `FEASIBLE → RECOVERABLE` transition;
- a live final known regression of 6/7 requirement interpretation, 2/2 corrigendum matching,
  9/9 ambiguity handling, and 8/9 final state, with every failure retained;
- a frozen eight-case blind result of 2/8 requirement interpretation, 7/8 ambiguity handling, and
  4/8 final state, with zero unsafe-green errors;
- saved desktop and mobile QA screenshots and three repeatable main-demo runs.

The nine regression cases informed development and are not presented as unseen model accuracy.
The separate U1-U8 blind-v1 cases were frozen before their first successful model run. They were
not used to select this round's prompt, normalizers, or model, and were not rerun after those
known-regression-driven changes. A separate empty blind-v2 intake is ready for the next teammate-
sealed evaluation.

## What are the current limitations?

- Nova Lite v1 does not support Bedrock-native `outputConfig`; it uses prompted JSON followed by
  strict Pydantic and provenance validation. Claude Haiku 4.5 native structured output remains
  blocked because the sandbox role lacks the required AWS Marketplace subscription actions.
- Exact requirement interpretation remains the main limitation: 6/7 on known regression and 2/8
  on the historical frozen blind-v1 run. Corrigendum matching, ambiguity safety, zero unsafe-green outcomes, and
  the R17 hero path are the stronger live results.
- The Control Room demo uses synthetic tender, company, evidence, and personnel data. Startup
  Studio can accept a user's PDF, DOCX, TXT, or Markdown tender, but there is no live GeBIZ
  retrieval.
- PDF upload is implemented, but OCR is not. Image-only or extremely sparse PDFs must be
  OCR-processed before upload, and complex tables or reading order can be extracted imperfectly.
- Extraction completeness remains below release quality and still requires human review and
  broader independent evaluation.
- SQLite and the local single-user process are demonstration architecture, not production
  multi-user deployment.
- Guided proposal generation is implemented, but the output is a human-reviewed draft and never an
  automatic submission. There is no pricing optimization or competitor intelligence.
- Google OAuth connects Calendar only; it is not general user authentication. Browser-scoped
  Calendar sessions, local token encryption, and reminder/attendee notifications are not a
  production identity system or a guaranteed escalation service.
