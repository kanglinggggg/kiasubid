# Startup Studio guide

Startup Studio is the upload-to-draft workflow alongside the synthetic SME Control Room. It has
three capabilities:

- **Tender Jargon Decipher (B1):** extracts machine-readable tender text, creates a source-backed
  plain-English analysis, and identifies features, phases, payments, eligibility, actions, risks,
  jargon, and key dates.
- **Guided Proposal Builder (B2):** interviews the team, critiques each conversational answer, and
  produces a structured Markdown proposal draft grounded in the tender analysis and those answers.
- **Smart Milestone Sync (B3):** lets a user review or correct extracted dates and export them as an
  `.ics` file or create/update events in a connected Google Calendar.

None of these workflows submits a tender or replaces review of the original procurement documents.

## Configure an LLM provider

Startup Studio requires one real provider. Copy `.env.example` to `.env`, then use one of these
configurations:

| Provider | Required values | Optional provider values |
| --- | --- | --- |
| Amazon Bedrock | `LLM_PROVIDER=bedrock`, `BEDROCK_MODEL_ID`, and normal AWS credentials/profile | `AWS_DEFAULT_REGION`, `BEDROCK_STRUCTURED_OUTPUT` |
| Groq | `LLM_PROVIDER=groq`, `GROQ_API_KEY`, and `GROQ_MODEL_ID` or `GROQ_MODEL` | `GROQ_BASE_URL`, `GROQ_STRUCTURED_OUTPUT`, `GROQ_TIMEOUT_SECONDS` |

Use a model ID that is enabled for the selected account; the application does not guess one. The
legacy synthetic Control Room has a deliberately narrow rule-based fallback, but Startup Studio
does not. A missing provider, provider outage, or repeatedly invalid structured response produces a
visible failed operation rather than synthetic content.

`LLM_MAX_RETRIES` controls the repair retry count and `LLM_MAX_OUTPUT_TOKENS` caps each structured
response. Native structured output should only be enabled when the chosen model supports the
provider's JSON-schema feature. Otherwise the schema is placed in the prompt and the returned JSON
is still validated locally.

## B1: analyse a tender

Supported inputs are machine-readable PDF, DOCX, TXT, and Markdown. The defaults are:

| Setting | Default |
| --- | ---: |
| `STARTUP_UPLOAD_MAX_BYTES` | 31,457,280 bytes (30 MiB) |
| `STARTUP_ANALYSIS_MAX_PAGES` | 750 pages |
| `STARTUP_ANALYSIS_MAX_CHARACTERS` | 3,000,000 characters |
| `STARTUP_ANALYSIS_CHUNK_CHARACTERS` | 28,000 characters |
| `STARTUP_TIMEZONE` | `Asia/Singapore` |

The server checks file signatures and structure; renaming an unsupported file does not make it a
valid upload. DOCX archives are bounded and checked before extraction. Text files must be UTF-8 or
UTF-16. PDF parsing extracts embedded text only. Scanned/image-only PDFs must be OCR-processed
outside BidOps before upload.

Analysis is asynchronous:

1. `POST /api/startup/analysis-jobs?filename=ITT.pdf&timezone=Asia%2FSingapore` with the file bytes as
   the body.
2. Poll `GET /api/startup/analysis-jobs/{job_id}`. Status moves through `QUEUED`, `EXTRACTING`, and
   `ANALYSING`, then becomes `COMPLETED` or `FAILED`.
3. On completion, read `analysis_id` and call `GET /api/startup/analyses/{analysis_id}`.

Example:

```bash
curl --request POST \
  --header "Content-Type: application/pdf" \
  --data-binary @ITT.pdf \
  "http://127.0.0.1:8000/api/startup/analysis-jobs?filename=ITT.pdf&timezone=Asia%2FSingapore"
```

The completed response includes the original filename, media type, page and character counts,
SHA-256 hash, detected scanned pages, provider/model metadata, source-backed analysis fields,
warnings, and `human_review_required: true`. A citation contains the extracted page when available,
section/locator when available, and matching source snippet.

Date extraction keeps both the verbatim `date_text` and a parsed offset-aware `deadline_at` when it
can be established. Deadline kinds include clarification, submission, bid bond, briefing,
delivery, payment, and other. An unresolved date has no `deadline_at` and remains marked
`needs_review`; a low-confidence date should also be checked against the source citation.

### What the safeguards do not prove

Schema and provenance checks can reject malformed output, invented source snippets, invalid fact
references, and unsafe date shapes. They cannot prove that every clause was extracted, that a
complex table was read in the intended order, or that a plain-English explanation is legally
correct. Always compare mandatory requirements, monetary terms, eligibility, and dates with the
original tender and its latest corrigenda.

## B2: build a proposal draft

Create a session after B1 finishes:

```http
POST /api/startup/proposal-sessions
Content-Type: application/json

{
  "analysis_id": "ANL-...",
  "company_name": "Example Startup Pte. Ltd.",
  "solution_name": "Example Platform"
}
```

The response contains five to ten mentor questions, including required coverage of the solution,
technical architecture, delivery, security/privacy, and team/governance. Read an existing session
with `GET /api/startup/proposal-sessions/{session_id}`.

Submit the current answer with its session revision:

```http
POST /api/startup/proposal-sessions/{session_id}/answers
Content-Type: application/json

{
  "question_id": "architecture",
  "answer": "We run stateless services behind a load balancer...",
  "revision": 0
}
```

The model returns a verdict, mentor feedback, strengths, gaps, evidence still needed, unsupported
claims, a procurement-style reformulation, and optionally one follow-up question. The raw answer is
retained alongside the reformulation; it is not silently replaced. Continue until the session is
`READY`, then call:

Each conversational answer is limited to 4,000 characters. The server also caps a session at 20
answers, 120,000 combined raw/reformulated answer characters, and 280,000 dynamic prompt
characters. An input that would cross a session or prompt budget is rejected before a provider call
with an actionable `422` response; start a fresh session with shorter answers if the accumulated
session is already at its limit.

The B2 handoff includes at most 80 items from each B1 result list (100 checklist items). Whenever a
count or model-input limit omits items, the mentor receives an explicit reduced-context notice and
the same limitation is appended to the generated draft's visible review notice and Markdown. Review
the complete B1 analysis when preparing the final submission.

```http
POST /api/startup/proposal-sessions/{session_id}/generate
Content-Type: application/json

{"revision": 7}
```

The generated draft includes an executive summary, sectioned content, requirement-coverage notes,
open items, and rendered Markdown. Each paragraph carries internal references to tender context or
recorded answers. The application also rejects ungrounded new numeric claims. The team must still
verify every assertion, attach real evidence, complete pricing and declarations, obtain approvals,
and submit through the procurement channel itself.

Revisions are optimistic-concurrency controls. If another browser has advanced a session, reload
the latest session and retry rather than overwriting its state.

## B3: review and sync milestones

The B1 result is the source of deadlines. Before creating events:

- inspect the source snippet and original page;
- correct the title, date/time, all-day setting, and IANA timezone when needed;
- explicitly confirm an override for an unresolved or review-required deadline;
- choose up to five reminder offsets, each from 0 to 40,320 minutes before the event; and
- add attendee addresses only when notification is intended and permitted.

The default reminder offsets are seven days, one day, and two hours. With email escalation enabled,
the sync adds popup reminders at all three checkpoints plus email reminders at the first two,
staying within Google's five-reminder limit. Optional team recipients receive Google invitation and
event-update notifications. Reminder delivery and recipient-side alerts depend on Google and each
recipient's settings; this integration does not claim to be a guaranteed paging or on-call service.

### `.ics` export

`GET /api/startup/analyses/{analysis_id}/calendar.ics` returns a standard calendar file for
resolved, review-safe dates. It needs no Google credentials. Downloading a file is an export, not a
live sync: later BidOps changes do not alter an event already imported into another calendar.

### Google Calendar OAuth

Enable the Google Calendar API, create a Google Cloud OAuth client of type **Web application**, and
register the configured callback exactly. The local default is:

```text
http://127.0.0.1:8000/api/startup/calendar/google/callback
```

Set:

```dotenv
APP_SECRET_KEY=<long random secret>
GOOGLE_CLIENT_ID=<web client id>
GOOGLE_CLIENT_SECRET=<web client secret>
GOOGLE_REDIRECT_URI=http://127.0.0.1:8000/api/startup/calendar/google/callback
CALENDAR_COOKIE_SECURE=false
```

For a deployed service, use its HTTPS callback, add that exact URI in Google Cloud, and set
`CALENDAR_COOKIE_SECURE=true`. Changing `APP_SECRET_KEY` invalidates existing encrypted tokens, so
users must reconnect afterward.

The calendar endpoints are:

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/api/startup/calendar/status` | Report configuration and browser-session connection state |
| `GET` | `/api/startup/calendar/google/authorize` | Begin OAuth authorization with state and PKCE |
| `GET` | `/api/startup/calendar/google/callback` | Exact Google redirect target; exchanges the one-time code |
| `GET` | `/api/startup/analyses/{analysis_id}/calendar/state` | Restore confirmed corrections and notification settings |
| `DELETE` | `/api/startup/calendar/connection` | Remove the local connection for this browser session |
| `POST` | `/api/startup/analyses/{analysis_id}/calendar/sync` | Create or update selected Google events |

A sync request names selected `deadline_ids`, the calendar (default `primary`), reminders,
attendees, and any confirmed per-deadline overrides. Deterministic event identifiers and payload
hashes make a repeated sync update or preserve the corresponding event instead of blindly creating
duplicates. The response reports each item as created, updated, unchanged, skipped, or failed; a
batch can be partial, so inspect item results.

Confirmed corrections, reminder rules, and attendee lists are retained per connected browser,
calendar, analysis, and deadline after a successful sync. Reloading restores those values so a
later sync does not silently revert a corrected date or clear recipients. An explicit empty
reminder or attendee list remains an intentional removal.

## Data and security notes

- Tender text chunks are sent to the selected LLM provider. Proposal context and team answers are
  also sent for the relevant B2 calls. Apply the provider account's retention, regional, and data
  classification policies before uploading sensitive material.
- Raw upload bytes are staged temporarily under `data/startup_uploads/` during extraction and
  analysis. The application deletes that staged file on completion, failure, or interrupted-job
  recovery after restart. A production deployment still needs encrypted temporary storage, an
  explicit retention/deletion policy, and a documented crash, backup, and recovery policy; local
  cleanup is not a durable confidentiality guarantee.
- Derived tender analysis, proposal answers/drafts, provider metadata, calendar-link metadata,
  confirmed corrections, reminders, and attendee addresses persist in the configured database.
  SQLite and the browser-scoped Calendar session are suitable for this local demonstration, not
  tenant isolation in a production service.
- Google access and refresh tokens are encrypted at rest with a key derived from
  `APP_SECRET_KEY`. OAuth state is short-lived and the flow uses PKCE. Client secrets, application
  secrets, AWS credentials, and Groq keys belong only in the ignored local environment—not source
  control or browser code.
- Calendar event data, reminder settings, and attendee addresses are sent to Google when syncing.
- A production deployment needs authenticated users, authorization on every analysis and proposal,
  managed key storage and rotation, database access controls, audit/retention policies, malware
  scanning, HTTPS, and operational monitoring.

Use FastAPI's `/docs` page as the authoritative generated request/response schema for the running
version.
