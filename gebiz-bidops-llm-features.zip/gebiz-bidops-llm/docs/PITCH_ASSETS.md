# Pitch assets

## One-line problem

Tender teams lose control when mandatory obligations, evidence, deadlines, and corrigenda are
spread across documents and spreadsheets, so an apparently ready bid can become unsafe overnight.

## One-line product thesis

GeBIZ BidOps turns tender documents into source-linked preparation work, guides a startup from
plain-English answers to a proposal draft, and propagates validated changes through evidence,
feasibility, and recovery—while deterministic rules and humans retain control of the bid decision.

## SME Control Room architecture

```mermaid
flowchart LR
    H[Human bid team] -->|supplies page/section text| UI[React control room]
    UI --> API[FastAPI API]
    API --> INT[Tender interpretation]
    INT -->|configured and successful| BR[Amazon Bedrock Converse]
    INT -->|offline main fixture| FB[Built-in demo interpretation]
    BR --> VAL[Pydantic schema + provenance validation]
    FB --> VAL
    VAL --> WF[LangGraph corrigendum workflow]
    WF --> RULES[Deterministic assessment and rule services]
    RULES --> DB[(Local SQLite state)]
    DB --> METRICS[Feasibility, gates, coverage, deadline risk]
    METRICS --> UI
    UI -->|review and final approval| H
    H -.->|manual only| G[Official GeBIZ submission]
```

The Control Room keeps React, FastAPI, LangGraph, and SQLite local. Its synthetic main fixture can
use the clearly labelled demo fallback, while an authorized Bedrock or Groq provider can perform
live interpretation.

## Startup Studio architecture

```mermaid
flowchart TD
    U[PDF, DOCX, TXT, or Markdown] --> X[Bounded text extraction]
    X --> A[Grounded Bedrock or Groq analysis]
    A --> P[Guided proposal mentor]
    A --> D[Reviewed deadlines]
    D --> C[Google Calendar or ICS]
```

Startup Studio persists asynchronous analysis and proposal sessions in SQLite. It requires the
selected live provider for analysis and proposal generation; it never substitutes the synthetic
Control Room fallback. Calendar projection and sync are ordinary code, not model actions.

## Corrigendum sequence

```mermaid
sequenceDiagram
    actor User as Bid manager
    participant UI as React UI
    participant API as FastAPI
    participant LLM as Bedrock or demo fallback
    participant V as Pydantic/provenance guard
    participant W as Deterministic workflow
    participant DB as SQLite

    User->>UI: Apply Corrigendum #2
    UI->>API: POST corrigendum
    API->>LLM: Existing R17 + new source text
    LLM-->>V: MODIFIED, R17, minimum_count 3→4
    V->>V: Validate schema and exact source snippet
    V-->>W: Accepted structured change
    W->>DB: Store R17 v2; retain v1
    W->>DB: Mark v1 assessment SUPERSEDED
    W->>W: Re-evaluate evidence and recoverability
    W->>DB: Persist PARTIAL, tasks, metrics, activity
    DB-->>API: RECOVERABLE, 7/8, 84%, MEDIUM
    API-->>UI: Render traceable backend state
    UI-->>User: Review recovery and human checkpoint
```

## Core control flow

```mermaid
flowchart LR
    R[Requirement<br/>stable key + source] --> E[Evidence<br/>validity + ownership]
    E --> A[Assessment<br/>current typed result]
    A --> C[Change<br/>new version + old superseded]
    C --> I[Impact<br/>gate + coverage + deadline]
    I --> RA[Recovery Action<br/>owner + dependency + due time]
    RA --> A
```

Invariant: **Requirement → Evidence → Assessment → Change → Impact → Recovery Action**.

## Responsibility boundaries

| Responsibility | LLM | Deterministic code | Human |
|---|---:|---:|---:|
| Interpret supplied tender prose into typed requirements | Primary, when live provider succeeds | Schema/provenance validation and safe fallback | Confirm source completeness and review |
| Match a corrigendum to a stable requirement and list field changes | Primary, when live provider succeeds | Reject malformed, ambiguous, unsafe, or out-of-scope output | Resolve unclear amendments |
| Version requirements and supersede old assessments | No | Yes | Review history |
| Match evidence and evaluate mandatory gates | No | Yes | Supply/verify authoritative evidence |
| Decide `FEASIBLE`, `RECOVERABLE`, `BLOCKED`, `UNCERTAIN` | No | Yes | Challenge/approve internal conclusion |
| Compute Critical Gates, Submission Coverage, Deadline Risk | No | Yes | Act on drivers |
| Create recovery tasks and dependencies | No | Yes | Own and complete tasks |
| Extract a plain-English Startup Studio analysis | Source-backed draft | Parse files, validate schema/provenance, persist job | Compare with original tender |
| Ask, critique, and draft a proposal | Source-backed draft | Validate/persist revisions and render Markdown | Supply facts, evidence, edit, and approve |
| Extract and sync milestones | Extract source-backed date facts | Validate dates, build ICS, execute OAuth/API sync | Correct/confirm dates and select events |
| Commercial decision, declarations, final approval, submission | No | No automatic action | Sole control |

## Regression benchmark summary

The **GeBIZ-derived deterministic regression benchmark** contains nine cases spanning event
attendance, qualification, required documents, processing windows, participation restrictions,
and source freshness.

| Measure | Current frozen result |
|---|---:|
| Deterministic requirement-result accuracy | 9/9 (100%) |
| Deterministic overall bid-status accuracy | 9/9 (100%) |
| Unsupported cases | 0 |
| Live requirement interpretation | 6/7 known regression; 2/8 historical frozen blind-v1 run |
| Live corrigendum matching | 2/2 on known regression cases |
| Live ambiguity handling | 9/9 known regression; 7/8 historical frozen blind-v1 run |
| Live final operational state | 8/9 known regression; 4/8 historical frozen blind-v1 run |
| Live R17 transition | PASS with `amazon.nova-lite-v1:0` |
| Unsafe-green errors | 0 in known regression and historical frozen blind-v1 run |

These nine cases informed development. The 100% result is a regression claim about deterministic
rules, not unseen model accuracy.

## Current limitations

- Live Bedrock results are mixed: Nova Lite passed the R17 path and both known corrigendum cases,
  while exact requirement interpretation reached 6/7 on known regression and 2/8 on the historical
  frozen blind-v1 run. The blind-v1 set was not rerun after this round's known-regression-driven
  changes; blind-v2 intake is ready but intentionally empty. Native structured output with Claude
  Haiku 4.5 is unavailable because the sandbox
  role lacks required Marketplace subscription actions.
- The Control Room fixtures are synthetic; Startup Studio accepts user-supplied PDF, DOCX, TXT, and
  Markdown files. Live GeBIZ retrieval is not implemented.
- PDF upload is implemented, but OCR is not. Image-only or extremely sparse PDFs need OCR before
  upload, and complex tables or document reading order can be extracted imperfectly.
- No model or system can guarantee extraction completeness; human review and blind evaluation are
  still required.
- SQLite/local single-user execution is suitable for the hackathon, not production multi-user use.
- Guided proposal drafting is implemented, but every claim remains team-reviewed and there is no
  pricing optimization, competitor intelligence, or GeBIZ submission.
- Google Calendar OAuth is a provider connection, not general user authentication. Browser-scoped
  sessions and Calendar reminders are not production identity or guaranteed escalation systems.

## 30-second pitch

“Tender paperwork should not disqualify a promising startup before its product gets a fair look.
GeBIZ BidOps turns an uploaded tender into a source-linked plain-English checklist, mentors the team
from conversational answers to a professional proposal draft, and puts reviewed milestones into
their calendar. Its Control Room also catches when a corrigendum makes yesterday's pass unsafe.
The model drafts; validation and rules control state; people keep the final say.”

## 60-second pitch

“Singapore suppliers do not only need to find tenders—they need to keep a changing bid safe to
submit. Today, mandatory clauses, staff qualifications, evidence, tasks, and corrigenda live in
separate documents and spreadsheets. A high completion percentage can hide one fatal gate.

GeBIZ BidOps gives the team one working record: Requirement, Evidence, Assessment, Change, Impact,
and Recovery Action. In the Control Room story, Bedrock has one narrow job—turn tender wording into
validated structured changes with a document, page, section, and exact snippet. From there, ordinary code versions the
requirement, retires stale assessments, rechecks evidence, applies the four-state feasibility
policy, and calculates coverage and deadline risk.

When Corrigendum #2 raises R17 from three to four CISSP engineers, BidOps retains v1, creates v2,
finds that Engineer D's CV and availability are incomplete, and moves FEASIBLE to RECOVERABLE with
four dependency-aware actions. It also demonstrates BLOCKED and UNCERTAIN outcomes, so it does not
always say yes.

Startup Studio adds the earlier preparation journey: upload a real machine-readable tender, receive
a source-backed plain-English explanation and checklist, answer mentor questions in ordinary
language, generate a grounded proposal draft, and sync only reviewed dates to Calendar. Final
approval and GeBIZ submission remain human decisions.”

## Business value

BidOps reduces amendment-response time, prevents stale passes from surviving a source change, and
focuses scarce bid-team effort on the one obligation or task that controls submission viability.
For an SME, that means fewer avoidable disqualifications, clearer ownership, faster recovery, and a
more defensible internal go/no-go decision—without automating irreversible submission.
