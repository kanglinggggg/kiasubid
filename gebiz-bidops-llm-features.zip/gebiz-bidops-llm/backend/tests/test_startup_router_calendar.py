from datetime import UTC, datetime, timedelta
from http.cookies import SimpleCookie

import pytest
from fastapi import HTTPException, Response
from pydantic import SecretStr
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from starlette.requests import Request

from app.database import Base
from app.models import (
    CalendarConnection,
    CalendarDeadlinePreference,
    CalendarEventSync,
    CalendarOAuthState,
    StartupTenderAnalysis,
)
from app.startup import router as startup_router
from app.startup.calendar import GOOGLE_CALENDAR_SCOPES, CalendarProviderError
from app.startup.calendar_schemas import (
    CalendarSyncItem,
    CalendarSyncRequest,
    CalendarSyncResponse,
    GoogleOAuthAuthorization,
    GoogleTokenSet,
)


def _session_factory(database_path):
    engine = create_engine(f"sqlite:///{database_path.as_posix()}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def _request(cookie_value: str | None = None) -> Request:
    headers = []
    if cookie_value is not None:
        headers.append(
            (
                b"cookie",
                f"{startup_router._CALENDAR_COOKIE}={cookie_value}".encode("ascii"),
            )
        )
    return Request(
        {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": "GET",
            "scheme": "https",
            "path": "/api/startup/calendar/status",
            "raw_path": b"/api/startup/calendar/status",
            "query_string": b"",
            "headers": headers,
            "client": ("testclient", 443),
            "server": ("bidops.example", 443),
        }
    )


def _response_cookie(response: Response) -> str:
    cookies = SimpleCookie()
    cookies.load(response.headers["set-cookie"])
    return cookies[startup_router._CALENDAR_COOKIE].value


@pytest.fixture
def configured_calendar(monkeypatch):
    monkeypatch.setattr(
        startup_router.settings,
        "app_secret_key",
        SecretStr("test-app-secret-that-is-at-least-32-bytes-long"),
    )
    monkeypatch.setattr(
        startup_router.settings,
        "google_client_id",
        "calendar-client.apps.googleusercontent.com",
    )
    monkeypatch.setattr(
        startup_router.settings,
        "google_client_secret",
        SecretStr("calendar-client-secret"),
    )
    monkeypatch.setattr(
        startup_router.settings,
        "google_redirect_uri",
        "https://bidops.example/api/startup/calendar/google/callback",
    )
    monkeypatch.setattr(startup_router.settings, "frontend_url", "https://bidops.example")
    monkeypatch.setattr(startup_router.settings, "calendar_cookie_secure", True)


def _oauth_state(*, state: str, cookie_value: str, verifier: str) -> CalendarOAuthState:
    cipher = startup_router.CalendarTokenCipher.from_settings()
    session_id = startup_router._calendar_session_id(cookie_value)
    assert session_id is not None
    return CalendarOAuthState(
        state=state,
        session_key=session_id,
        code_verifier=cipher.encrypt(verifier),
        return_path="/#startup/milestones",
        expires_at=startup_router._utcnow() + timedelta(minutes=5),
    )


def _analysis(*, filename: str = "tender.pdf") -> StartupTenderAnalysis:
    return StartupTenderAnalysis(
        id="ANALYSIS-CALENDAR",
        filename=filename,
        media_type="application/pdf",
        document_sha256="0" * 64,
        timezone="Asia/Singapore",
        page_count=12,
        character_count=100,
        scanned_pages=[],
        provider_mode="BEDROCK",
        model_id="test.model",
        model_calls=1,
        attempts=1,
        duration_ms=1,
        result_payload={
            "deadlines": [
                {
                    "id": "closing",
                    "kind": "SUBMISSION",
                    "title": "Tender closing",
                    "date_text": "12 September 2026, 5:00 PM SGT",
                    "deadline_at": "2026-09-12T17:00:00+08:00",
                    "all_day": False,
                    "timezone": "Asia/Singapore",
                    "confidence": "HIGH",
                    "needs_review": False,
                    "source": {
                        "page": 12,
                        "section": "Closing date",
                        "snippet": "Tender closes at 5:00 PM SGT.",
                    },
                }
            ]
        },
        warnings=[],
    )


def _connection(*, session_id: str, expires_in: timedelta) -> CalendarConnection:
    cipher = startup_router.CalendarTokenCipher.from_settings()
    return CalendarConnection(
        id="CALENDAR-CONNECTION",
        session_key=session_id,
        provider="GOOGLE",
        encrypted_access_token=cipher.encrypt("access-token"),
        encrypted_refresh_token=cipher.encrypt("refresh-token"),
        token_expires_at=startup_router._utcnow() + expires_in,
        granted_scope=GOOGLE_CALENDAR_SCOPES[0],
        reauthorization_required=False,
    )


def test_authorize_encrypts_pkce_and_never_persists_the_bearer_cookie(
    tmp_path, monkeypatch, configured_calendar
):
    session_factory = _session_factory(tmp_path / "oauth-authorize.db")
    verifier = "V" * 64
    state = "S" * 48
    monkeypatch.setattr(
        startup_router,
        "create_google_authorization",
        lambda **_kwargs: GoogleOAuthAuthorization(
            authorization_url="https://accounts.google.com/o/oauth2/v2/auth?state=" + state,
            state=state,
            code_verifier=SecretStr(verifier),
        ),
    )

    with session_factory() as session:
        response = startup_router.authorize_google_calendar(_request(), session=session)
        cookie_value = _response_cookie(response)
        stored = session.get(CalendarOAuthState, state)

        assert response.status_code == 302
        assert response.headers["cache-control"] == "private, no-store"
        assert "HttpOnly" in response.headers["set-cookie"]
        assert "Secure" in response.headers["set-cookie"]
        assert stored is not None
        assert stored.session_key == startup_router._calendar_session_id(cookie_value)
        assert stored.session_key != cookie_value
        assert verifier not in stored.code_verifier
        assert (
            startup_router.CalendarTokenCipher.from_settings().decrypt(stored.code_verifier)
            == verifier
        )


def test_oauth_denial_requires_the_bound_cookie_and_consumes_state_once(
    tmp_path, configured_calendar
):
    session_factory = _session_factory(tmp_path / "oauth-denial.db")
    victim_cookie = startup_router._new_calendar_session_cookie()
    attacker_cookie = startup_router._new_calendar_session_cookie()
    state = "denial-state"

    with session_factory() as session:
        session.add(_oauth_state(state=state, cookie_value=victim_cookie, verifier="V" * 64))
        session.commit()

        with pytest.raises(HTTPException) as raised:
            startup_router.google_calendar_callback(
                _request(attacker_cookie), state=state, error="access_denied", session=session
            )
        assert raised.value.status_code == 400
        assert session.get(CalendarOAuthState, state) is not None

        response = startup_router.google_calendar_callback(
            _request(victim_cookie), state=state, error="access_denied", session=session
        )
        assert response.status_code == 303
        assert response.headers["location"].endswith(
            "/#startup/milestones?calendar=denied"
        )
        assert session.get(CalendarOAuthState, state) is None


def test_oauth_callback_encrypts_tokens_and_maps_expiry_to_naive_utc(
    tmp_path, monkeypatch, configured_calendar
):
    session_factory = _session_factory(tmp_path / "oauth-callback.db")
    cookie_value = startup_router._new_calendar_session_cookie()
    session_id = startup_router._calendar_session_id(cookie_value)
    assert session_id is not None
    state = "callback-state"
    expires_at = datetime(2026, 9, 9, 18, 0, tzinfo=UTC)
    monkeypatch.setattr(
        startup_router,
        "exchange_google_code",
        lambda code, verifier: GoogleTokenSet(
            access_token=SecretStr("new-access-token"),
            refresh_token=SecretStr("new-refresh-token"),
            expires_at=expires_at,
            scope=GOOGLE_CALENDAR_SCOPES[0],
        ),
    )

    with session_factory() as session:
        session.add(_oauth_state(state=state, cookie_value=cookie_value, verifier="V" * 64))
        session.commit()
        response = startup_router.google_calendar_callback(
            _request(cookie_value), state=state, code="authorization-code", session=session
        )

        connection = session.scalar(
            select(CalendarConnection).where(CalendarConnection.session_key == session_id)
        )
        assert response.headers["location"].endswith(
            "/#startup/milestones?calendar=connected"
        )
        assert connection is not None
        assert connection.token_expires_at == expires_at.replace(tzinfo=None)
        assert connection.token_expires_at.tzinfo is None
        cipher = startup_router.CalendarTokenCipher.from_settings()
        assert cipher.decrypt(connection.encrypted_access_token) == "new-access-token"
        assert cipher.decrypt(connection.encrypted_refresh_token) == "new-refresh-token"
        assert session.get(CalendarOAuthState, state) is None


def test_refresh_failure_only_requires_reauthorization_for_terminal_credentials(
    tmp_path, monkeypatch, configured_calendar
):
    session_factory = _session_factory(tmp_path / "oauth-refresh.db")
    cookie_value = startup_router._new_calendar_session_cookie()
    session_id = startup_router._calendar_session_id(cookie_value)
    assert session_id is not None

    with session_factory() as session:
        connection = _connection(session_id=session_id, expires_in=timedelta(seconds=-1))
        session.add(connection)
        session.commit()
        monkeypatch.setattr(
            startup_router,
            "refresh_google_token",
            lambda _token: (_ for _ in ()).throw(
                CalendarProviderError(
                    "Google OAuth token refresh failed with HTTP 503 (backendError).",
                    status_code=503,
                    code="backendError",
                )
            ),
        )

        with pytest.raises(HTTPException) as transient:
            startup_router._calendar_access_token(connection, session)
        assert transient.value.status_code == 502
        assert connection.reauthorization_required is False

        monkeypatch.setattr(
            startup_router,
            "refresh_google_token",
            lambda _token: (_ for _ in ()).throw(
                CalendarProviderError(
                    "Google OAuth token refresh failed with HTTP 400 (invalid_grant).",
                    status_code=400,
                    code="invalid_grant",
                )
            ),
        )
        with pytest.raises(HTTPException) as terminal:
            startup_router._calendar_access_token(connection, session)
        assert terminal.value.status_code == 401
        assert connection.reauthorization_required is True


def test_calendar_status_exposes_scope_without_cacheable_credentials(
    tmp_path, configured_calendar
):
    session_factory = _session_factory(tmp_path / "calendar-status.db")
    cookie_value = startup_router._new_calendar_session_cookie()
    session_id = startup_router._calendar_session_id(cookie_value)
    assert session_id is not None

    with session_factory() as session:
        session.add(_connection(session_id=session_id, expires_in=timedelta(hours=1)))
        session.commit()
        response = Response()
        payload = startup_router.calendar_status(
            _request(cookie_value), response=response, session=session
        )

        assert payload["provider"] == "GOOGLE"
        assert payload["connected"] is True
        assert payload["scope"] == GOOGLE_CALENDAR_SCOPES[0]
        assert response.headers["cache-control"] == "private, no-store"


def test_ics_download_uses_an_ascii_header_for_a_unicode_tender_name(
    tmp_path, configured_calendar
):
    session_factory = _session_factory(tmp_path / "calendar-ics.db")
    with session_factory() as session:
        session.add(_analysis(filename="采购招标.pdf"))
        session.commit()

        response = startup_router.export_calendar_ics("ANALYSIS-CALENDAR", session=session)

        disposition = response.headers["content-disposition"]
        assert disposition == 'attachment; filename="tender-deadlines.ics"'
        disposition.encode("ascii")
        assert response.headers["cache-control"] == "private, no-store"
        assert response.body.startswith(b"BEGIN:VCALENDAR\r\n")


def test_sync_persists_success_for_only_the_bound_connection(
    tmp_path, monkeypatch, configured_calendar
):
    session_factory = _session_factory(tmp_path / "calendar-sync.db")
    cookie_value = startup_router._new_calendar_session_cookie()
    session_id = startup_router._calendar_session_id(cookie_value)
    assert session_id is not None
    captured_existing = []

    def fake_sync(_deadlines, _payload, **kwargs):
        captured_existing.append(list(kwargs["existing_events"]))
        return CalendarSyncResponse(
            status="COMPLETE",
            calendar_id="primary",
            results=[
                CalendarSyncItem(
                    deadline_id="closing",
                    status="CREATED" if not captured_existing[-1] else "UNCHANGED",
                    event_id="b" + "a" * 39,
                    event_link="https://calendar.google.com/event?eid=closing",
                    payload_hash="1" * 64,
                )
            ],
        )

    monkeypatch.setattr(startup_router, "sync_google_calendar_batch", fake_sync)
    request_payload = CalendarSyncRequest(deadline_ids=["closing"])

    with session_factory() as session:
        session.add_all(
            [
                _analysis(),
                _connection(session_id=session_id, expires_in=timedelta(hours=1)),
            ]
        )
        session.commit()

        first = startup_router.sync_calendar(
            "ANALYSIS-CALENDAR",
            request_payload,
            _request(cookie_value),
            session=session,
        )
        second = startup_router.sync_calendar(
            "ANALYSIS-CALENDAR",
            request_payload,
            _request(cookie_value),
            session=session,
        )

        rows = session.scalars(select(CalendarEventSync)).all()
        assert first.results[0].status == "CREATED"
        assert second.results[0].status == "UNCHANGED"
        assert captured_existing[0] == []
        assert len(captured_existing[1]) == 1
        assert len(rows) == 1
        assert rows[0].connection_id == "CALENDAR-CONNECTION"
        assert rows[0].payload_hash == "1" * 64


def test_corrected_deadline_settings_survive_reload_and_an_omitted_resync(
    tmp_path, monkeypatch, configured_calendar
):
    session_factory = _session_factory(tmp_path / "calendar-preferences.db")
    cookie_value = startup_router._new_calendar_session_cookie()
    session_id = startup_router._calendar_session_id(cookie_value)
    assert session_id is not None
    captured_calls = []

    def fake_sync(_deadlines, sync_request, **kwargs):
        captured_calls.append(
            {
                "request": sync_request.model_dump(mode="json"),
                "settings": {
                    key: value.model_dump(mode="json")
                    for key, value in kwargs["deadline_settings"].items()
                },
            }
        )
        return CalendarSyncResponse(
            status="COMPLETE",
            calendar_id="primary",
            results=[
                CalendarSyncItem(
                    deadline_id="closing",
                    status="CREATED" if len(captured_calls) == 1 else "UNCHANGED",
                    event_id="b" + "c" * 39,
                    event_link="https://calendar.google.com/event?eid=corrected",
                    payload_hash="2" * 64,
                )
            ],
        )

    monkeypatch.setattr(startup_router, "sync_google_calendar_batch", fake_sync)
    corrected_request = CalendarSyncRequest.model_validate(
        {
            "deadline_ids": ["closing"],
            "reminders": [
                {"method": "popup", "minutes": 1440},
                {"method": "email", "minutes": 120},
            ],
            "attendees": ["ops@example.com", "founder@example.com"],
            "deadline_overrides": [
                {
                    "deadline_id": "closing",
                    "deadline_at": "2026-09-12T18:30:00+08:00",
                    "all_day": False,
                    "timezone": "Asia/Singapore",
                    "title": "Corrected tender closing",
                    "confirmed": True,
                }
            ],
        }
    )

    with session_factory() as session:
        session.add_all(
            [
                _analysis(),
                _connection(session_id=session_id, expires_in=timedelta(hours=1)),
            ]
        )
        session.commit()
        startup_router.sync_calendar(
            "ANALYSIS-CALENDAR",
            corrected_request,
            _request(cookie_value),
            session=session,
        )
        preference = session.scalar(select(CalendarDeadlinePreference))
        assert preference is not None
        assert preference.attendees == ["ops@example.com", "founder@example.com"]

    with session_factory() as session:
        state_response = Response()
        state = startup_router.calendar_analysis_state(
            "ANALYSIS-CALENDAR",
            _request(cookie_value),
            state_response,
            session=session,
        )
        assert state_response.headers["cache-control"] == "private, no-store"
        assert state.deadlines[0].override is not None
        assert state.deadlines[0].override.title == "Corrected tender closing"
        assert state.deadlines[0].override.deadline_at.isoformat() == (
            "2026-09-12T18:30:00+08:00"
        )
        assert [row.model_dump() for row in state.deadlines[0].reminders or []] == [
            {"method": "popup", "minutes": 1440},
            {"method": "email", "minutes": 120},
        ]
        assert state.deadlines[0].attendees == [
            "ops@example.com",
            "founder@example.com",
        ]

        # A client that omits fields after reload must retain the prior correction
        # and notification settings instead of silently reverting to defaults.
        startup_router.sync_calendar(
            "ANALYSIS-CALENDAR",
            CalendarSyncRequest.model_validate({"deadline_ids": ["closing"]}),
            _request(cookie_value),
            session=session,
        )

    assert captured_calls[1]["request"]["deadline_overrides"] == [
        {
            "deadline_id": "closing",
            "deadline_at": "2026-09-12T18:30:00+08:00",
            "all_day": False,
            "timezone": "Asia/Singapore",
            "title": "Corrected tender closing",
            "confirmed": True,
            "reminder_minutes": None,
            "reminders": None,
            "attendees": None,
        }
    ]
    assert captured_calls[1]["settings"] == {
        "closing": {
            "reminders": [
                {"method": "popup", "minutes": 1440},
                {"method": "email", "minutes": 120},
            ],
            "attendees": ["ops@example.com", "founder@example.com"],
        }
    }
