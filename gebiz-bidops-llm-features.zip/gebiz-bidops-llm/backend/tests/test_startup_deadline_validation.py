from typing import Any

import pytest
from pydantic import ValidationError

from app.startup.analysis_schemas import Deadline


def _deadline(**changes: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "id": "DEADLINE-001",
        "kind": "SUBMISSION",
        "title": "Tender submission",
        "date_text": "30 September 2026, 5 pm SGT",
        "deadline_at": "2026-09-30T17:00:00+08:00",
        "all_day": False,
        "timezone": "Asia/Singapore",
        "confidence": "HIGH",
        "needs_review": False,
        "source": {
            "page": 1,
            "section": "Closing date",
            "snippet": "Submit by 30 September 2026, 5 pm SGT.",
        },
    }
    payload.update(changes)
    return payload


def test_explicit_date_time_and_timezone_can_be_review_safe() -> None:
    parsed = Deadline.model_validate(_deadline())

    assert parsed.deadline_at is not None
    assert parsed.needs_review is False


def test_colon_time_with_meridiem_is_counted_once() -> None:
    parsed = Deadline.model_validate(
        _deadline(date_text="30 September 2026, 5:00 PM SGT")
    )

    assert parsed.deadline_at is not None
    assert parsed.needs_review is False


@pytest.mark.parametrize(
    "change",
    [
        {"deadline_at": "2026-09-29T17:00:00+08:00"},
        {"deadline_at": "2026-09-30T16:00:00+08:00"},
        {"date_text": "30 September 2026, 5 pm"},
        {
            "date_text": "03/04/2026, 5 pm SGT",
            "deadline_at": "2026-04-03T17:00:00+08:00",
        },
        {"date_text": "30 September 2026 SGT"},
        {"date_text": "30 September 2026, 5 pm SGT", "all_day": True},
    ],
)
def test_unverified_or_mismatched_normalization_must_not_be_review_safe(
    change: dict[str, Any],
) -> None:
    with pytest.raises(ValidationError):
        Deadline.model_validate(_deadline(**change))


def test_ambiguous_date_is_allowed_only_as_a_review_candidate() -> None:
    parsed = Deadline.model_validate(
        _deadline(
            date_text="03/04/2026 at 5 pm",
            deadline_at="2026-04-03T17:00:00+08:00",
            confidence="LOW",
            needs_review=True,
        )
    )

    assert parsed.needs_review is True


@pytest.mark.parametrize(
    "deadline_at",
    ["2026-11-01T01:30:00-04:00", "2026-11-01T01:30:00-05:00"],
)
def test_daylight_saving_fold_requires_review(deadline_at: str) -> None:
    change = {
        "date_text": "November 1, 2026 at 1:30 am America/New_York",
        "deadline_at": deadline_at,
        "timezone": "America/New_York",
    }

    with pytest.raises(ValidationError, match="daylight-saving fold"):
        Deadline.model_validate(_deadline(**change))

    parsed = Deadline.model_validate(
        _deadline(**change, confidence="LOW", needs_review=True)
    )
    assert parsed.needs_review is True


@pytest.mark.parametrize(
    "date_text",
    [
        "Tuesday, 30 September 2026, 5 pm SGT",
        "Tues. 30 September 2026, 5 pm SGT",
    ],
)
def test_mismatched_explicit_weekday_is_rejected(date_text: str) -> None:
    with pytest.raises(ValidationError, match="weekday"):
        Deadline.model_validate(_deadline(date_text=date_text))


@pytest.mark.parametrize("weekday", ["Wednesday", "Wed."])
def test_matching_explicit_weekday_can_be_review_safe(weekday: str) -> None:
    parsed = Deadline.model_validate(
        _deadline(date_text=f"{weekday}, 30 September 2026, 5 pm SGT")
    )

    assert parsed.needs_review is False


def test_multiple_explicit_clock_times_require_review() -> None:
    date_text = "30 September 2026, between 4 pm and 5 pm SGT"
    with pytest.raises(ValidationError, match="multiple source clock times"):
        Deadline.model_validate(_deadline(date_text=date_text))

    parsed = Deadline.model_validate(
        _deadline(date_text=date_text, confidence="LOW", needs_review=True)
    )
    assert parsed.needs_review is True
