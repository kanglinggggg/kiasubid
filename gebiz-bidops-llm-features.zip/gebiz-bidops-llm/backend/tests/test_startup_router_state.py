import hashlib
import os
from datetime import UTC, datetime, timedelta
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.database import Base
from app.models import StartupAnalysisJob, StartupProposalSession, StartupTenderAnalysis
from app.startup.api_schemas import ProposalAnswerSubmit, ProposalSessionCreate
from app.startup.proposal import ProposalInputLimitError
from app.startup.proposal_schemas import MAX_PROPOSAL_ANSWER_CHARACTERS
from app.startup.router import (
    _ProposalRevisionLost,
    _persist_proposal_revision,
    _remove_stale_orphan_uploads,
    _run_analysis_job,
    _safe_filename,
    _same_answer_retry,
    _same_generate_retry,
    start_proposal_session,
    submit_proposal_answer,
)


def _analysis() -> StartupTenderAnalysis:
    return StartupTenderAnalysis(
        id="ANALYSIS-ROUTER-TEST",
        filename="tender.txt",
        media_type="text/plain",
        document_sha256="0" * 64,
        timezone="Asia/Singapore",
        page_count=None,
        character_count=100,
        scanned_pages=[],
        provider_mode="BEDROCK",
        model_id="test.model",
        model_calls=1,
        attempts=1,
        duration_ms=1,
        result_payload={"overview": {"summary": "Test tender"}},
        warnings=[],
    )


def _proposal() -> StartupProposalSession:
    timestamp = datetime.now(UTC).replace(tzinfo=None)
    return StartupProposalSession(
        id="PROPOSAL-ROUTER-TEST",
        analysis_id="ANALYSIS-ROUTER-TEST",
        company_name="Student Startup",
        solution_name="Portal",
        status="IN_PROGRESS",
        revision=0,
        current_index=0,
        questions=[{"id": "Q1"}],
        answers=[],
        last_feedback=None,
        draft=None,
        provider_mode="BEDROCK",
        model_id="test.model",
        created_at=timestamp,
        updated_at=timestamp,
    )


def _session_factory(database_path):
    engine = create_engine(f"sqlite:///{database_path.as_posix()}")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def test_proposal_revision_persistence_uses_atomic_compare_and_swap(tmp_path):
    session_factory = _session_factory(tmp_path / "proposal-state.db")

    with session_factory() as session:
        session.add_all([_analysis(), _proposal()])
        session.commit()

        proposal = session.get(StartupProposalSession, "PROPOSAL-ROUTER-TEST")
        assert proposal is not None
        proposal.answers = [{"question_id": "Q1", "raw_answer": "Winning answer"}]
        proposal.current_index = 1
        proposal.status = "READY"
        proposal.revision = 1
        proposal.updated_at = datetime.now(UTC).replace(tzinfo=None)

        persisted = _persist_proposal_revision(session, proposal, loaded_revision=0)

        assert persisted.revision == 1
        assert persisted.answers[0]["raw_answer"] == "Winning answer"

        stale = session.get(StartupProposalSession, "PROPOSAL-ROUTER-TEST")
        assert stale is not None
        stale.answers = [{"question_id": "Q1", "raw_answer": "Losing answer"}]
        with pytest.raises(_ProposalRevisionLost):
            _persist_proposal_revision(session, stale, loaded_revision=0)

        current = session.get(StartupProposalSession, "PROPOSAL-ROUTER-TEST")
        assert current is not None
        assert current.revision == 1
        assert current.answers[0]["raw_answer"] == "Winning answer"


def test_retry_detection_is_limited_to_the_immediately_prior_transition():
    proposal = _proposal()
    proposal.revision = 3
    proposal.answers = [{"question_id": "Q1", "raw_answer": "Same answer"}]

    assert _same_answer_retry(
        proposal,
        expected_revision=2,
        question_id="Q1",
        raw_answer="Same answer",
    )
    assert not _same_answer_retry(
        proposal,
        expected_revision=1,
        question_id="Q1",
        raw_answer="Same answer",
    )
    assert not _same_answer_retry(
        proposal,
        expected_revision=2,
        question_id="Q1",
        raw_answer="Different answer",
    )

    proposal.status = "GENERATED"
    assert _same_generate_retry(proposal, expected_revision=2)
    assert _same_generate_retry(proposal, expected_revision=3)
    assert not _same_generate_retry(proposal, expected_revision=1)


class _UnexpectedDatabaseAccess:
    def get(self, *_args, **_kwargs):
        raise AssertionError("invalid input must be rejected before database access")


@pytest.mark.parametrize(
    "payload",
    [
        ProposalSessionCreate(
            analysis_id="   ", company_name="Student Startup", solution_name="Portal"
        ),
        ProposalSessionCreate(
            analysis_id="ANALYSIS-1", company_name="   ", solution_name="Portal"
        ),
        ProposalSessionCreate(
            analysis_id="ANALYSIS-1", company_name="Student Startup", solution_name="   "
        ),
    ],
)
def test_start_session_rejects_whitespace_only_fields_before_database_access(
    payload: ProposalSessionCreate,
    monkeypatch,
):
    monkeypatch.setattr("app.startup.router._require_live_model", lambda: None)

    with pytest.raises(HTTPException) as raised:
        start_proposal_session(
            payload,
            session=_UnexpectedDatabaseAccess(),
            builder=object(),
        )

    assert raised.value.status_code == 422


class _StoredAnalysisResult:
    warnings: list[str] = []

    def model_dump(self, *, mode: str):
        assert mode == "json"
        return {
            "overview": {"summary": "A source-grounded test analysis"},
            "deadlines": [],
            "warnings": [],
        }


class _FakeAnalysisService:
    def __init__(self):
        self.calls = 0

    def analyse(self, document, *, timezone: str, progress):
        self.calls += 1
        assert timezone == "Asia/Singapore"
        progress("ANALYSING", 1, 1)
        return SimpleNamespace(
            document=document,
            provider=SimpleNamespace(
                mode="BEDROCK",
                model_id="test.model",
                calls=1,
                attempts=1,
                duration_ms=5,
                input_tokens=10,
                output_tokens=5,
                total_tokens=15,
            ),
            result=_StoredAnalysisResult(),
        )


def test_background_analysis_claims_once_persists_result_and_removes_upload(
    tmp_path, monkeypatch
):
    session_factory = _session_factory(tmp_path / "analysis-job.db")
    upload_directory = tmp_path / "startup_uploads"
    upload_directory.mkdir()
    job_id = "JOB-dddddddddddddddd"
    upload_path = upload_directory / f"{job_id}.upload"
    content = b"Tenderers must submit a working portal before the stated closing date."
    upload_path.write_bytes(content)

    with session_factory() as session:
        session.add(
            StartupAnalysisJob(
                id=job_id,
                status="QUEUED",
                stage="Queued",
                progress=0,
                original_filename="tender.txt",
                media_type="text/plain",
                timezone="Asia/Singapore",
                upload_path=str(upload_path),
                document_sha256=hashlib.sha256(content).hexdigest(),
            )
        )
        session.commit()

    service = _FakeAnalysisService()
    monkeypatch.setattr("app.startup.router.SessionLocal", session_factory)
    monkeypatch.setattr("app.startup.router._UPLOAD_DIRECTORY", upload_directory)

    _run_analysis_job(job_id, service)
    _run_analysis_job(job_id, service)

    with session_factory() as session:
        job = session.get(StartupAnalysisJob, job_id)
        assert job is not None
        assert job.status == "COMPLETED"
        assert job.progress == 100
        assert job.analysis_id is not None
        analysis = session.get(StartupTenderAnalysis, job.analysis_id)
        assert analysis is not None
        assert analysis.result_payload["overview"]["summary"].startswith("A source-grounded")
    assert service.calls == 1
    assert not upload_path.exists()


def test_answer_route_rejects_whitespace_only_answer_before_database_access(monkeypatch):
    monkeypatch.setattr("app.startup.router._require_live_model", lambda: None)
    payload = ProposalAnswerSubmit(question_id="Q1", answer="   ", revision=0)

    with pytest.raises(HTTPException) as raised:
        submit_proposal_answer(
            "PROPOSAL-1",
            payload,
            session=_UnexpectedDatabaseAccess(),
            builder=object(),
        )

    assert raised.value.status_code == 422


def test_answer_schema_enforces_the_shared_conversational_answer_limit():
    with pytest.raises(ValueError, match="at most 4000 characters"):
        ProposalAnswerSubmit(
            question_id="Q1",
            answer="x" * (MAX_PROPOSAL_ANSWER_CHARACTERS + 1),
            revision=0,
        )


def test_answer_route_maps_input_budget_failures_to_actionable_422(monkeypatch):
    proposal = _proposal()
    analysis = _analysis()

    class _LookupSession:
        def get(self, model, identifier):
            if model is StartupProposalSession and identifier == proposal.id:
                return proposal
            if model is StartupTenderAnalysis and identifier == analysis.id:
                return analysis
            return None

    def reject_oversized_session(**_kwargs):
        raise ProposalInputLimitError("Shorten the current answer.")

    monkeypatch.setattr("app.startup.router._require_live_model", lambda: None)
    monkeypatch.setattr(
        "app.startup.router.answer_current_question",
        reject_oversized_session,
    )

    with pytest.raises(HTTPException) as raised:
        submit_proposal_answer(
            proposal.id,
            ProposalAnswerSubmit(question_id="Q1", answer="A short answer", revision=0),
            session=_LookupSession(),
            builder=object(),
        )

    assert raised.value.status_code == 422
    assert raised.value.detail == "Shorten the current answer."


@pytest.mark.parametrize(
    "filename",
    ["../tender.pdf", "folder/tender.pdf", "folder\\tender.pdf", "bad\x00name.pdf"],
)
def test_upload_filename_rejects_paths_and_control_characters(filename: str):
    with pytest.raises(HTTPException) as raised:
        _safe_filename(filename)

    assert raised.value.status_code == 422


def test_restart_cleanup_removes_terminal_and_stale_unreferenced_managed_uploads(
    tmp_path, monkeypatch
):
    upload_directory = tmp_path / "startup_uploads"
    upload_directory.mkdir()
    stale_orphan = upload_directory / "JOB-aaaaaaaaaaaaaaaa.upload"
    recent_orphan = upload_directory / "JOB-bbbbbbbbbbbbbbbb.upload"
    referenced_upload = upload_directory / "JOB-cccccccccccccccc.upload"
    active_upload = upload_directory / "JOB-dddddddddddddddd.upload"
    failed_upload = upload_directory / "JOB-eeeeeeeeeeeeeeee.upload"
    unrelated_file = upload_directory / "notes.upload"
    unmanaged_upload = tmp_path / "JOB-ffffffffffffffff.upload"
    for path in (
        stale_orphan,
        recent_orphan,
        referenced_upload,
        active_upload,
        failed_upload,
        unrelated_file,
        unmanaged_upload,
    ):
        path.write_bytes(b"test")
    old = (datetime.now(UTC) - timedelta(hours=2)).timestamp()
    for path in (stale_orphan, referenced_upload, unrelated_file):
        os.utime(path, (old, old))

    referenced_job = StartupAnalysisJob(
        id="JOB-cccccccccccccccc",
        status="COMPLETED",
        stage="Analysis complete",
        progress=100,
        original_filename="tender.txt",
        media_type="text/plain",
        timezone="Asia/Singapore",
        upload_path=str(referenced_upload),
        document_sha256="0" * 64,
    )
    active_job = StartupAnalysisJob(
        id="JOB-dddddddddddddddd",
        status="ANALYSING",
        stage="Extracting tender facts",
        progress=50,
        original_filename="tender.txt",
        media_type="text/plain",
        timezone="Asia/Singapore",
        upload_path=str(active_upload),
        document_sha256="0" * 64,
    )
    failed_job = StartupAnalysisJob(
        id="JOB-eeeeeeeeeeeeeeee",
        status="FAILED",
        stage="Analysis failed",
        progress=100,
        original_filename="tender.txt",
        media_type="text/plain",
        timezone="Asia/Singapore",
        upload_path=str(failed_upload),
        document_sha256="0" * 64,
    )
    unmanaged_job = StartupAnalysisJob(
        id="JOB-ffffffffffffffff",
        status="FAILED",
        stage="Analysis failed",
        progress=100,
        original_filename="tender.txt",
        media_type="text/plain",
        timezone="Asia/Singapore",
        upload_path=str(unmanaged_upload),
        document_sha256="0" * 64,
    )

    class FakeSession:
        def scalars(self, _statement):
            return SimpleNamespace(
                all=lambda: [referenced_job, active_job, failed_job, unmanaged_job]
            )

    monkeypatch.setattr("app.startup.router._UPLOAD_DIRECTORY", upload_directory)
    _remove_stale_orphan_uploads(FakeSession())

    assert not stale_orphan.exists()
    assert recent_orphan.exists()
    assert not referenced_upload.exists()
    assert active_upload.exists()
    assert not failed_upload.exists()
    assert unrelated_file.exists()
    assert unmanaged_upload.exists()


def test_startup_cleanup_retries_a_terminal_upload_after_background_unlink_failure(
    tmp_path, monkeypatch
):
    session_factory = _session_factory(tmp_path / "analysis-unlink-retry.db")
    upload_directory = tmp_path / "startup_uploads"
    upload_directory.mkdir()
    job_id = "JOB-ffffffffffffffff"
    upload_path = upload_directory / f"{job_id}.upload"
    content = b"Tenderers must submit a working portal before the stated closing date."
    upload_path.write_bytes(content)

    with session_factory() as session:
        session.add(
            StartupAnalysisJob(
                id=job_id,
                status="QUEUED",
                stage="Queued",
                progress=0,
                original_filename="tender.txt",
                media_type="text/plain",
                timezone="Asia/Singapore",
                upload_path=str(upload_path),
                document_sha256=hashlib.sha256(content).hexdigest(),
            )
        )
        session.commit()

    original_unlink = Path.unlink
    failed_once = False

    def fail_first_upload_unlink(path: Path, *args, **kwargs):
        nonlocal failed_once
        if path == upload_path and not failed_once:
            failed_once = True
            raise OSError("simulated transient lock")
        return original_unlink(path, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", fail_first_upload_unlink)
    monkeypatch.setattr("app.startup.router.SessionLocal", session_factory)
    monkeypatch.setattr("app.startup.router._UPLOAD_DIRECTORY", upload_directory)

    _run_analysis_job(job_id, _FakeAnalysisService())
    assert upload_path.exists()

    with session_factory() as session:
        job = session.get(StartupAnalysisJob, job_id)
        assert job is not None
        assert job.status == "COMPLETED"
        _remove_stale_orphan_uploads(session)

    assert not upload_path.exists()
