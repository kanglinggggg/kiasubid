"""External benchmark case support."""
