import json
from types import SimpleNamespace

import pytest
from pydantic import ValidationError

from app.startup.proposal import ProposalBuilder, ProposalInputLimitError, REVIEW_NOTICE
from app.startup.proposal_schemas import (
    MAX_PROPOSAL_ANSWER_CHARACTERS,
    ProposalAnswer,
    ProposalCritique,
    ProposalQuestion,
)


class FakeInvoker:
    def __init__(self, responses: list[dict] | None = None, error: Exception | None = None):
        self.responses = list(responses or [])
        self.error = error
        self.calls: list[dict] = []

    def invoke(self, **kwargs):
        if self.error is not None:
            raise self.error
        prompt = kwargs["prompt"]
        last_error: Exception | None = None
        for attempt, response in enumerate(self.responses, start=1):
            self.calls.append({**kwargs, "prompt": prompt})
            try:
                result = kwargs["output_model"].model_validate(response)
                validator = kwargs.get("validator")
                if validator is not None:
                    validator(result)
                return SimpleNamespace(
                    result=result,
                    model_id="test.model",
                    mode="BEDROCK",
                    attempts=attempt,
                    duration_ms=12.5,
                    input_tokens=100,
                    output_tokens=50,
                    total_tokens=150,
                )
            except (ValidationError, ValueError) as exc:
                last_error = exc
                prompt = kwargs["repair_prompt"](
                    kwargs["prompt"], json.dumps(response), str(exc)
                )
        raise ValueError(f"fake structured output remained invalid: {last_error}")


@pytest.fixture
def context() -> dict:
    return {
        "tender_id": "TENDER-DEMO",
        "title": "Secure citizen portal",
        "requirements": [
            {"id": "REQ-SOLUTION", "plain_english": "Provide a citizen self-service portal."},
            {"id": "REQ-TECH", "plain_english": "Describe scalability and availability."},
            {"id": "REQ-SEC", "plain_english": "Provide a data-breach response plan."},
            {"id": "REQ-DELIVERY", "plain_english": "Deliver in two phases."},
            {"id": "REQ-TEAM", "plain_english": "Name the delivery team and governance."},
        ],
    }


def _question(
    question_id: str,
    section: str,
    context_ref: str,
    question: str = "How will your approach meet this requirement?",
) -> dict:
    return {
        "id": question_id,
        "section": section,
        "question": question,
        "why_it_matters": "The evaluator needs a concrete and credible response.",
        "answer_guidance": ["Describe the approach", "Name evidence the team can provide"],
        "required": True,
        "context_refs": [context_ref],
    }


def _valid_plan() -> dict:
    return {
        "mentor_intro": "I will guide you through the key parts of this tender one step at a time.",
        "questions": [
            _question("Q_SOLUTION", "SOLUTION", "REQ-SOLUTION"),
            _question(
                "Q_TECH",
                "TECHNICAL_ARCHITECTURE",
                "REQ-TECH",
                "How will the architecture support high traffic?",
            ),
            _question("Q_DELIVERY", "DELIVERY", "REQ-DELIVERY"),
            _question(
                "Q_SECURITY",
                "SECURITY_PRIVACY",
                "REQ-SEC",
                "What happens if there is a data breach?",
            ),
            _question("Q_TEAM", "TEAM_GOVERNANCE", "REQ-TEAM"),
        ],
    }


def _critique(**updates) -> dict:
    result = {
        "question_id": "Q_TECH",
        "verdict": "NEEDS_DETAIL",
        "mentor_feedback": "The approach is understandable, but the recovery process needs detail.",
        "strengths": ["It identifies horizontal scaling."],
        "gaps": ["It does not explain recovery testing."],
        "formalized_answer": "The solution scales horizontally across app servers.",
        "answer_quotes": ["scales horizontally"],
        "evidence_needed": ["Architecture diagram"],
        "unsupported_claims": [],
        "context_refs": ["REQ-TECH"],
        "needs_follow_up": True,
        "follow_up_question": "How will you test recovery when a server fails?",
    }
    result.update(updates)
    return result


def _answers() -> list[ProposalAnswer]:
    rows = [
        ("Q_SOLUTION", "SOLUTION", "REQ-SOLUTION", "We offer a simple citizen portal."),
        (
            "Q_TECH",
            "TECHNICAL_ARCHITECTURE",
            "REQ-TECH",
            "The service scales horizontally.",
        ),
        ("Q_DELIVERY", "DELIVERY", "REQ-DELIVERY", "We deliver in two phases."),
        (
            "Q_SECURITY",
            "SECURITY_PRIVACY",
            "REQ-SEC",
            "We isolate affected systems and notify the response lead.",
        ),
        (
            "Q_TEAM",
            "TEAM_GOVERNANCE",
            "REQ-TEAM",
            "A project lead coordinates the delivery team.",
        ),
    ]
    return [
        ProposalAnswer(
            question_id=question_id,
            section=section,
            question="How will your approach meet this requirement?",
            raw_answer=text,
            formalized_answer=text,
            context_refs=[context_ref],
        )
        for question_id, section, context_ref, text in rows
    ]


def _paragraph(text: str, answer_id: str, context_ref: str) -> dict:
    return {
        "text": text,
        "supporting_answer_ids": [answer_id],
        "context_refs": [context_ref],
    }


def _valid_draft() -> dict:
    return {
        "title": "Secure Citizen Portal Proposal",
        "executive_summary": [
            _paragraph(
                "We propose a simple citizen self-service portal.",
                "Q_SOLUTION",
                "REQ-SOLUTION",
            )
        ],
        "sections": [
            {
                "section_key": "SOLUTION",
                "heading": "Proposed Solution",
                "paragraphs": [
                    _paragraph(
                        "The proposed service is a citizen portal.",
                        "Q_SOLUTION",
                        "REQ-SOLUTION",
                    )
                ],
            },
            {
                "section_key": "TECHNICAL_ARCHITECTURE",
                "heading": "Technical Architecture",
                "paragraphs": [
                    _paragraph("The service scales horizontally.", "Q_TECH", "REQ-TECH")
                ],
            },
            {
                "section_key": "DELIVERY",
                "heading": "Delivery Approach",
                "paragraphs": [
                    _paragraph(
                        "Delivery is organised into two phases.",
                        "Q_DELIVERY",
                        "REQ-DELIVERY",
                    )
                ],
            },
            {
                "section_key": "SECURITY_PRIVACY",
                "heading": "Security and Privacy",
                "paragraphs": [
                    _paragraph(
                        "The response process isolates affected systems and notifies the lead.",
                        "Q_SECURITY",
                        "REQ-SEC",
                    )
                ],
            },
            {
                "section_key": "TEAM_GOVERNANCE",
                "heading": "Team and Governance",
                "paragraphs": [
                    _paragraph(
                        "A project lead coordinates the delivery team.",
                        "Q_TEAM",
                        "REQ-TEAM",
                    )
                ],
            },
        ],
        "requirement_coverage": [
            {
                "context_ref": "REQ-SOLUTION",
                "status": "COVERED",
                "section_keys": ["SOLUTION"],
                "explanation": "The proposed portal is described in the solution section.",
            },
            {
                "context_ref": "REQ-DELIVERY",
                "status": "PARTIAL",
                "section_keys": ["DELIVERY"],
                "explanation": "The phases are described, but dates still require review.",
            },
        ],
        "open_items": [
            {
                "text": "Team to confirm the delivery dates before submission.",
                "related_answer_ids": ["Q_DELIVERY"],
                "context_refs": ["REQ-DELIVERY"],
            }
        ],
    }


def test_question_plan_uses_live_invoker_metadata_and_b1_context(context: dict):
    invoker = FakeInvoker([_valid_plan()])
    envelope = ProposalBuilder(invoker=invoker).create_question_plan(context)

    assert envelope.mode == "BEDROCK"
    assert envelope.model_id == "test.model"
    assert envelope.attempts == 1
    assert (
        envelope.result.questions[1].question
        == "How will the architecture support high traffic?"
    )
    assert "B1_CONTEXT_START" in invoker.calls[0]["prompt"]
    assert "Secure citizen portal" in invoker.calls[0]["prompt"]
    assert "untrusted data" in invoker.calls[0]["system"]


def test_unknown_plan_context_reference_is_rejected_and_repaired(context: dict):
    invalid = _valid_plan()
    invalid["questions"][0]["context_refs"] = ["MADE-UP-REQUIREMENT"]
    invoker = FakeInvoker([invalid, _valid_plan()])

    envelope = ProposalBuilder(invoker=invoker).create_question_plan(context)

    assert envelope.attempts == 2
    assert len(invoker.calls) == 2
    assert "VALIDATION_ERROR" in invoker.calls[1]["prompt"]


def test_question_plan_repairs_an_invented_numeric_target(context: dict):
    invalid = _valid_plan()
    invalid["questions"][1]["question"] = "How will you guarantee 99.9% availability?"
    invoker = FakeInvoker([invalid, _valid_plan()])

    envelope = ProposalBuilder(invoker=invoker).create_question_plan(context)

    assert envelope.attempts == 2
    assert "numerical claims" in invoker.calls[1]["prompt"]


def test_critique_preserves_answer_provenance_and_returns_one_follow_up(context: dict):
    invoker = FakeInvoker([_critique()])
    builder = ProposalBuilder(invoker=invoker)
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    envelope = builder.critique_answer(
        context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.result.question_id == "Q_TECH"
    assert envelope.result.answer_quotes == ["scales horizontally"]
    assert envelope.result.needs_follow_up is True
    assert envelope.result.follow_up_question


def test_fabricated_answer_quote_is_rejected(context: dict):
    fabricated_quote = _critique(
        answer_quotes=["guarantees availability"],
    )
    invoker = FakeInvoker([fabricated_quote, _critique()])
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.attempts == 2
    assert "exact contiguous substrings" in invoker.calls[1]["prompt"]


def test_new_numeric_claim_is_rejected(context: dict):
    fabricated_number = _critique(
        formalized_answer="The solution guarantees 99.9% availability.",
        answer_quotes=["scales horizontally"],
    )
    invoker = FakeInvoker([fabricated_number, _critique()])
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.attempts == 2
    assert "numerical claims" in invoker.calls[1]["prompt"]


@pytest.mark.parametrize(
    "invented_claim",
    [
        "The solution operates across five availability zones.",
        "The solution stores 5m records.",
        "The solution provides 24x7 monitoring.",
        "The solution is certified to SOC2.",
        "The solution is certified to ISO27001.",
        "The network requires IPv6.",
        "The service uses Tier4 hosting.",
    ],
)
def test_spelled_and_compact_numeric_claims_are_rejected_and_repaired(
    context: dict,
    invented_claim: str,
):
    invalid = _critique(formalized_answer=invented_claim)
    invoker = FakeInvoker([invalid, _critique()])
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.attempts == 2
    assert "numerical claims" in invoker.calls[1]["prompt"]


def test_numeric_values_present_in_the_answer_are_allowed(context: dict):
    answer = (
        "We support five zones, 5m records, 24x7 monitoring, SOC2, ISO27001, IPv6, "
        "and Tier4 hosting."
    )
    supported = _critique(
        formalized_answer=(
            "The solution supports 5 zones, 5m records, 24 x 7 monitoring, SOC2, "
            "ISO27001, IPv6, and Tier4 hosting."
        ),
        answer_quotes=[
            "five zones",
            "5m records",
            "24x7 monitoring",
            "SOC2",
            "ISO27001",
            "IPv6",
            "Tier4",
        ],
    )
    invoker = FakeInvoker([supported])
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        context,
        question,
        answer,
    )

    assert envelope.attempts == 1


def test_structural_question_identifier_is_not_treated_as_an_invented_claim(context: dict):
    question = ProposalQuestion.model_validate(
        {
            **_valid_plan()["questions"][1],
            "id": "Q2",
        }
    )
    supported = _critique(
        question_id="Q2",
        mentor_feedback="For Q2, the response is clear enough to use.",
        formalized_answer="The solution scales horizontally.",
        answer_quotes=["scales horizontally"],
    )
    invoker = FakeInvoker([supported])

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.attempts == 1


def test_numeric_values_present_in_context_are_allowed(context: dict):
    grounded_context = {
        **context,
        "service_level": {"id": "REQ-SLA", "text": "Provide 99.9% availability."},
    }
    supported = _critique(
        formalized_answer="The tender requests 99.9% availability.",
        answer_quotes=["scales horizontally"],
        context_refs=["REQ-SLA"],
    )
    invoker = FakeInvoker([supported])
    question = ProposalQuestion.model_validate(
        {
            **_valid_plan()["questions"][1],
            "context_refs": ["REQ-SLA"],
        }
    )

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        grounded_context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.attempts == 1


def test_aggregate_answer_budget_is_rejected_before_provider_invocation(context: dict):
    prior_answers = [
        ProposalAnswer(
            question_id=f"P{index}",
            section="SOLUTION",
            question="How will your approach meet this requirement?",
            raw_answer="r" * MAX_PROPOSAL_ANSWER_CHARACTERS,
            formalized_answer="f" * MAX_PROPOSAL_ANSWER_CHARACTERS,
            context_refs=[],
        )
        for index in range(19)
    ]
    invoker = FakeInvoker([_critique()])
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    with pytest.raises(ProposalInputLimitError, match="answer-text budget"):
        ProposalBuilder(invoker=invoker).critique_answer(
            context,
            question,
            "A short current answer.",
            prior_answers,
        )

    assert invoker.calls == []


def test_oversized_dynamic_prompt_is_rejected_before_provider_invocation():
    dense_context = {"overview": {"summary": "x" * 149_000}}
    dense_answers = [
        ProposalAnswer(
            question_id=f"P{index}",
            section=(
                "SOLUTION",
                "TECHNICAL_ARCHITECTURE",
                "DELIVERY",
                "SECURITY_PRIVACY",
                "TEAM_GOVERNANCE",
            )[index % 5],
            question="q" * 1_000,
            raw_answer="r" * 3_000,
            formalized_answer="f" * 3_000,
            context_refs=[],
        )
        for index in range(19)
    ]
    invoker = FakeInvoker([_valid_draft()])

    with pytest.raises(ProposalInputLimitError, match="model-input safety budget"):
        ProposalBuilder(invoker=invoker).generate_draft(dense_context, dense_answers)

    assert invoker.calls == []


def test_critique_feedback_repairs_an_invented_numeric_target(context: dict):
    invalid = _critique(
        mentor_feedback="The answer should promise 99.9% uptime.",
    )
    invoker = FakeInvoker([invalid, _critique()])
    question = ProposalQuestion.model_validate(_valid_plan()["questions"][1])

    envelope = ProposalBuilder(invoker=invoker).critique_answer(
        context,
        question,
        "Our service scales horizontally across app servers.",
    )

    assert envelope.attempts == 2
    assert "numerical claims" in invoker.calls[1]["prompt"]


def test_follow_up_schema_cannot_return_a_hidden_second_question():
    payload = _critique(needs_follow_up=False, follow_up_question="What is the recovery target?")
    with pytest.raises(ValidationError, match="must be null"):
        ProposalCritique.model_validate(payload)


def test_generate_draft_is_grounded_and_markdown_is_server_rendered(context: dict):
    invoker = FakeInvoker([_valid_draft()])
    envelope = ProposalBuilder(invoker=invoker).generate_draft(context, _answers())

    assert envelope.result.review_notice == REVIEW_NOTICE
    assert envelope.result.markdown.startswith("# Secure Citizen Portal Proposal")
    assert "## Security and Privacy" in envelope.result.markdown
    assert "## Open Items for Team Review" in envelope.result.markdown
    assert "AI-generated preparation draft" in envelope.result.markdown
    assert invoker.calls[0]["max_tokens"] == 6000


def test_reduced_b1_context_warning_is_visible_in_draft_and_markdown(context: dict):
    reduced_context = {
        **context,
        "context_notice": "The mentor received a reduced B1 context. Review the full analysis.",
    }
    invoker = FakeInvoker([_valid_draft()])

    envelope = ProposalBuilder(invoker=invoker).generate_draft(
        reduced_context,
        _answers(),
    )

    assert "reduced B1 context" in envelope.result.review_notice
    assert envelope.result.review_notice in envelope.result.markdown


def test_draft_repairs_an_invented_number_in_a_section_heading(context: dict):
    invalid = _valid_draft()
    invalid["sections"][1]["heading"] = "99.9% Availability Guarantee"
    invoker = FakeInvoker([invalid, _valid_draft()])

    envelope = ProposalBuilder(invoker=invoker).generate_draft(context, _answers())

    assert envelope.attempts == 2
    assert "numerical claims" in invoker.calls[1]["prompt"]


def test_ordinary_numbered_section_headings_are_not_numeric_claims(context: dict):
    numbered = _valid_draft()
    for index, section in enumerate(numbered["sections"], start=1):
        section["heading"] = f"{index}. {section['heading']}"
    invoker = FakeInvoker([numbered])

    envelope = ProposalBuilder(invoker=invoker).generate_draft(context, _answers())

    assert envelope.attempts == 1


def test_draft_cannot_cite_unknown_answers_or_context(context: dict):
    invalid = _valid_draft()
    invalid["sections"][0]["paragraphs"][0]["supporting_answer_ids"] = ["Q_UNKNOWN"]
    invalid["sections"][1]["paragraphs"][0]["context_refs"] = ["REQ-INVENTED"]
    invoker = FakeInvoker([invalid, _valid_draft()])

    envelope = ProposalBuilder(invoker=invoker).generate_draft(context, _answers())

    assert envelope.attempts == 2
    assert len(invoker.calls) == 2


def test_generate_draft_requires_all_core_answer_sections(context: dict):
    invoker = FakeInvoker([_valid_draft()])
    with pytest.raises(ValueError, match="missing required proposal sections"):
        ProposalBuilder(invoker=invoker).generate_draft(context, _answers()[:-1])
    assert invoker.calls == []


def test_invalid_context_is_rejected_before_provider_invocation():
    invoker = FakeInvoker([_valid_plan()])
    with pytest.raises(ValueError, match="finite JSON-compatible"):
        ProposalBuilder(invoker=invoker).create_question_plan({"value": float("nan")})
    assert invoker.calls == []


def test_provider_failure_propagates_without_fake_ai_fallback(context: dict):
    error = RuntimeError("provider unavailable")
    with pytest.raises(RuntimeError, match="provider unavailable"):
        ProposalBuilder(invoker=FakeInvoker(error=error)).create_question_plan(context)
