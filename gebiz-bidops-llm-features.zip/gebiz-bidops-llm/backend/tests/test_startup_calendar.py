import base64
import hashlib
import json
from datetime import UTC, datetime
from urllib.parse import parse_qs, urlsplit

import pytest
from pydantic import SecretStr, ValidationError

from app.config import Settings
from app.startup.calendar import (
    GOOGLE_AUTHORIZATION_ENDPOINT,
    GOOGLE_CALENDAR_SCOPES,
    GOOGLE_TOKEN_ENDPOINT,
    CalendarProviderError,
    CalendarTokenCipher,
    CalendarValidationError,
    build_google_event_payload,
    build_ics_calendar,
    create_google_authorization,
    exchange_google_code,
    google_event_payload_hash,
    refresh_google_token,
    stable_google_event_id,
    sync_google_calendar_batch,
    validate_attendees,
    validate_reminder_minutes,
)
from app.startup.calendar_schemas import (
    CalendarDeadline,
    CalendarSyncRequest,
    DeadlineSyncOverride,
    ExistingCalendarEvent,
    ReminderOverride,
)


class FakeResponse:
    def __init__(self, status_code: int, payload: object):
        self.status_code = status_code
        self.payload = payload

    def json(self) -> object:
        return self.payload


class FakeHttpClient:
    def __init__(self, responses: list[FakeResponse]):
        self.responses = list(responses)
        self.calls: list[dict[str, object]] = []

    def _next(self, method: str, url: str, kwargs: dict[str, object]) -> FakeResponse:
        self.calls.append({"method": method, "url": url, **kwargs})
        if not self.responses:
            raise AssertionError("unexpected HTTP request")
        return self.responses.pop(0)

    def post(self, url: str, **kwargs: object) -> FakeResponse:
        return self._next("POST", url, kwargs)

    def request(self, method: str, url: str, **kwargs: object) -> FakeResponse:
        return self._next(method.upper(), url, kwargs)


def _settings() -> Settings:
    return Settings(
        _env_file=None,
        google_client_id="calendar-client.apps.googleusercontent.com",
        google_client_secret=SecretStr("client-secret"),
        google_redirect_uri="https://bidops.example/api/startup/calendar/google/callback",
        app_secret_key=SecretStr("test-app-secret-that-is-at-least-32-bytes-long"),
    )


def _deadline(
    deadline_id: str = "deadline-1",
    *,
    title: str = "Tender submission",
    deadline_at: datetime | None = datetime(2026, 9, 12, 9, 0, tzinfo=UTC),
    needs_review: bool = False,
    all_day: bool = False,
) -> CalendarDeadline:
    return CalendarDeadline(
        id=deadline_id,
        kind="SUBMISSION",
        title=title,
        date_text="12 September 2026, 5:00 PM SGT",
        deadline_at=deadline_at,
        all_day=all_day,
        timezone="Asia/Singapore",
        confidence="HIGH" if not needs_review else "LOW",
        needs_review=needs_review,
        source={
            "document": "ITT.pdf",
            "page": 12,
            "section": "2.1 Closing",
            "snippet": "The tender closes on 12 September 2026, 5:00 PM SGT. SECRET-SNIPPET",
        },
    )


def test_oauth_authorization_uses_exact_google_endpoint_scope_state_and_pkce():
    verifier = "A" * 64
    state = "s" * 48
    result = create_google_authorization(
        app_settings=_settings(), state=state, code_verifier=verifier
    )

    parsed = urlsplit(result.authorization_url)
    parameters = parse_qs(parsed.query)
    expected_challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
    ).decode("ascii").rstrip("=")
    assert f"{parsed.scheme}://{parsed.netloc}{parsed.path}" == GOOGLE_AUTHORIZATION_ENDPOINT
    assert parameters == {
        "access_type": ["offline"],
        "client_id": ["calendar-client.apps.googleusercontent.com"],
        "code_challenge": [expected_challenge],
        "code_challenge_method": ["S256"],
        "include_granted_scopes": ["true"],
        "redirect_uri": ["https://bidops.example/api/startup/calendar/google/callback"],
        "response_type": ["code"],
        "scope": [GOOGLE_CALENDAR_SCOPES[0]],
        "state": [state],
    }
    assert result.code_verifier.get_secret_value() == verifier


def test_code_exchange_and_refresh_use_google_token_endpoint_and_preserve_refresh_token():
    exchange_client = FakeHttpClient(
        [
            FakeResponse(
                200,
                {
                    "access_token": "access-1",
                    "refresh_token": "refresh-1",
                    "expires_in": 3600,
                    "scope": GOOGLE_CALENDAR_SCOPES[0],
                    "token_type": "Bearer",
                },
            )
        ]
    )
    tokens = exchange_google_code(
        "authorization-code",
        "V" * 64,
        app_settings=_settings(),
        client=exchange_client,
    )
    call = exchange_client.calls[0]
    assert call["url"] == GOOGLE_TOKEN_ENDPOINT
    assert call["data"] == {
        "client_id": "calendar-client.apps.googleusercontent.com",
        "client_secret": "client-secret",
        "code": "authorization-code",
        "code_verifier": "V" * 64,
        "grant_type": "authorization_code",
        "redirect_uri": "https://bidops.example/api/startup/calendar/google/callback",
    }
    assert tokens.access_token.get_secret_value() == "access-1"
    assert tokens.refresh_token and tokens.refresh_token.get_secret_value() == "refresh-1"
    assert tokens.expires_at and tokens.expires_at.tzinfo is UTC

    refresh_client = FakeHttpClient(
        [FakeResponse(200, {"access_token": "access-2", "expires_in": 1800})]
    )
    refreshed = refresh_google_token(
        "refresh-1", app_settings=_settings(), client=refresh_client
    )
    assert refreshed.access_token.get_secret_value() == "access-2"
    assert refreshed.refresh_token and refreshed.refresh_token.get_secret_value() == "refresh-1"
    assert refresh_client.calls[0]["data"] == {
        "client_id": "calendar-client.apps.googleusercontent.com",
        "client_secret": "client-secret",
        "grant_type": "refresh_token",
        "refresh_token": "refresh-1",
    }


def test_oauth_provider_errors_expose_only_safe_code_not_provider_description():
    client = FakeHttpClient(
        [
            FakeResponse(
                400,
                {
                    "error": "invalid_grant",
                    "error_description": "authorization-code and secret-token-value are invalid",
                },
            )
        ]
    )
    with pytest.raises(CalendarProviderError) as caught:
        exchange_google_code("bad-code", "V" * 64, app_settings=_settings(), client=client)
    assert caught.value.code == "invalid_grant"
    assert "secret-token-value" not in str(caught.value)


def test_fernet_cipher_is_derived_from_app_secret_and_never_returns_plaintext():
    first = CalendarTokenCipher.from_settings(_settings())
    second = CalendarTokenCipher.from_settings(_settings())
    encrypted = first.encrypt("sensitive-refresh-token")

    assert "sensitive-refresh-token" not in encrypted
    assert encrypted != first.encrypt("sensitive-refresh-token")
    assert second.decrypt(encrypted) == "sensitive-refresh-token"
    with pytest.raises(CalendarValidationError):
        CalendarTokenCipher("a" * 32).decrypt(encrypted)


def test_reminder_and_attendee_validation_enforces_provider_and_injection_limits():
    assert validate_reminder_minutes([10_080, 1_440, 120]) == [10_080, 1_440, 120]
    with pytest.raises(CalendarValidationError):
        validate_reminder_minutes([1, 2, 3, 4, 5, 6])
    with pytest.raises(CalendarValidationError):
        validate_reminder_minutes([40_321])
    with pytest.raises(CalendarValidationError):
        validate_reminder_minutes([120, 120])

    assert validate_attendees(["Bid.Lead+alerts@Example.COM"]) == [
        "Bid.Lead+alerts@example.com"
    ]
    with pytest.raises(CalendarValidationError):
        validate_attendees(["victim@example.com\r\nBCC:attacker@example.com"])
    with pytest.raises(ValidationError):
        CalendarSyncRequest(
            deadline_ids=["d1"], attendees=["lead@example.com", "LEAD@example.com"]
        )


def test_ics_is_rfc5545_shaped_escaped_folded_stable_and_has_five_or_fewer_alarms():
    deadline = _deadline(title="A, B; résumé " + "界" * 40)
    generated = datetime(2026, 9, 1, 1, 2, 3, tzinfo=UTC)
    first = build_ics_calendar(
        [deadline],
        analysis_id="analysis-123",
        reminder_minutes=[10_080, 1_440, 120, 30, 0],
        generated_at=generated,
    )
    second = build_ics_calendar(
        [deadline],
        analysis_id="analysis-123",
        reminder_minutes=[10_080, 1_440, 120, 30, 0],
        generated_at=generated,
    )

    assert first == second
    assert first.endswith("\r\n")
    assert "\n" not in first.replace("\r\n", "")
    assert "SUMMARY:[Submission] A\\, B\\;" in first
    assert first.count("BEGIN:VALARM") == 5
    assert "TRIGGER:-P1W" in first
    assert "TRIGGER:-P1D" in first
    assert "TRIGGER:-PT2H" in first
    assert "DTSTART:20260912T090000Z" in first
    assert "DTEND:20260912T091500Z" in first
    assert "UID:" + "bidops-" in first
    assert any(line.startswith(" ") for line in first.split("\r\n"))
    assert all(len(line.encode("utf-8")) <= 75 for line in first.split("\r\n"))


def test_ics_and_google_payload_refuse_unreviewed_or_unresolved_deadlines():
    unresolved = _deadline(deadline_at=None, needs_review=True)
    with pytest.raises(CalendarValidationError, match="requires human review"):
        build_ics_calendar([unresolved], analysis_id="analysis-1")
    with pytest.raises(CalendarValidationError, match="requires human review"):
        build_google_event_payload(unresolved, analysis_id="analysis-1")


def test_google_payload_is_private_minimal_deterministic_and_uses_valid_times():
    deadline = _deadline(title="R&D <review> Submit")
    payload = build_google_event_payload(
        deadline,
        analysis_id="analysis-1",
        reminders=[
            ReminderOverride(method="email", minutes=1_440),
            ReminderOverride(method="popup", minutes=120),
        ],
        attendees=["lead@example.com"],
    )
    serialized = json.dumps(payload)

    assert payload["id"] == stable_google_event_id("analysis-1", deadline.id)
    assert set(payload["id"]) <= set("abcdefghijklmnopqrstuv0123456789")
    assert payload["summary"] == "[Submission] R&D <review> Submit"
    assert "&amp;" not in serialized
    assert "SECRET-SNIPPET" not in serialized
    assert payload["visibility"] == "private"
    assert payload["transparency"] == "transparent"
    assert payload["start"] == {
        "dateTime": "2026-09-12T17:00:00+08:00",
        "timeZone": "Asia/Singapore",
    }
    assert payload["end"] == {
        "dateTime": "2026-09-12T17:15:00+08:00",
        "timeZone": "Asia/Singapore",
    }
    assert payload["reminders"]["overrides"] == [
        {"method": "email", "minutes": 1_440},
        {"method": "popup", "minutes": 120},
    ]
    assert payload["attendees"] == [{"email": "lead@example.com"}]
    assert google_event_payload_hash(payload) == google_event_payload_hash(payload)


def test_google_all_day_payload_uses_exclusive_end_date():
    payload = build_google_event_payload(
        _deadline(all_day=True), analysis_id="analysis-all-day", reminder_minutes=[]
    )
    assert payload["start"] == {"date": "2026-09-12"}
    assert payload["end"] == {"date": "2026-09-13"}


def test_batch_sync_creates_safe_event_and_skips_unreviewed_deadline():
    ready = _deadline("ready")
    review = _deadline("review", deadline_at=None, needs_review=True)
    client = FakeHttpClient(
        [
            FakeResponse(
                200,
                {
                    "id": stable_google_event_id("analysis-1", "ready"),
                    "htmlLink": "https://calendar.google.com/event?eid=ready",
                },
            )
        ]
    )
    response = sync_google_calendar_batch(
        [ready, review],
        CalendarSyncRequest(deadline_ids=["ready", "review"], reminder_minutes=[120]),
        analysis_id="analysis-1",
        access_token="access-token",
        client=client,
    )

    assert response.status == "PARTIAL"
    assert [item.status for item in response.results] == ["CREATED", "SKIPPED"]
    assert "human review" in (response.results[1].error or "")
    assert len(client.calls) == 1
    assert client.calls[0]["method"] == "POST"
    assert client.calls[0]["url"].endswith("/calendars/primary/events")
    assert client.calls[0]["headers"]["Authorization"] == "Bearer access-token"


def test_confirmed_deadline_override_is_the_only_review_bypass():
    review = _deadline("review", deadline_at=None, needs_review=True)
    corrected_at = datetime(2026, 10, 2, 8, 30, tzinfo=UTC)
    unconfirmed = DeadlineSyncOverride(
        deadline_id="review",
        deadline_at=corrected_at,
        all_day=False,
        timezone="Asia/Singapore",
        confirmed=False,
    )
    rejected = sync_google_calendar_batch(
        [review],
        CalendarSyncRequest(deadline_ids=["review"], deadline_overrides=[unconfirmed]),
        analysis_id="analysis-1",
        access_token="access-token",
        client=FakeHttpClient([]),
    )
    assert rejected.status == "FAILED"
    assert rejected.results[0].status == "SKIPPED"

    confirmed = unconfirmed.model_copy(update={"confirmed": True, "title": "Confirmed closing"})
    client = FakeHttpClient(
        [FakeResponse(200, {"id": stable_google_event_id("analysis-1", "review")})]
    )
    accepted = sync_google_calendar_batch(
        [review],
        CalendarSyncRequest(deadline_ids=["review"], deadline_overrides=[confirmed]),
        analysis_id="analysis-1",
        access_token="access-token",
        client=client,
    )
    assert accepted.status == "COMPLETE"
    assert accepted.results[0].status == "CREATED"
    assert client.calls[0]["json"]["summary"].endswith("Confirmed closing")


def test_deadline_corrections_require_rfc3339_offset_and_valid_iana_timezone():
    with pytest.raises(ValidationError, match="UTC offset"):
        DeadlineSyncOverride(
            deadline_id="review",
            deadline_at=datetime(2026, 10, 2, 8, 30),
            timezone="Asia/Singapore",
            confirmed=True,
        )
    with pytest.raises(ValidationError, match="IANA"):
        DeadlineSyncOverride(
            deadline_id="review",
            deadline_at=datetime(2026, 10, 2, 8, 30, tzinfo=UTC),
            timezone="Singapore-ish",
            confirmed=True,
        )


def test_default_sync_request_adds_tiered_email_escalations_within_provider_limit():
    reminders = CalendarSyncRequest(deadline_ids=["ready"]).effective_reminders()

    assert [(item.method, item.minutes) for item in reminders] == [
        ("popup", 10_080),
        ("popup", 1_440),
        ("popup", 120),
        ("email", 10_080),
        ("email", 1_440),
    ]


def test_sync_request_accepts_every_deadline_allowed_by_analysis_contract():
    deadline_ids = [f"DEADLINE-{index:03d}" for index in range(1, 251)]
    overrides = [
        DeadlineSyncOverride(deadline_id=deadline_id, confirmed=False)
        for deadline_id in deadline_ids
    ]

    parsed = CalendarSyncRequest(
        deadline_ids=deadline_ids,
        deadline_overrides=overrides,
    )

    assert len(parsed.deadline_ids) == 250
    assert len(parsed.deadline_overrides) == 250
    with pytest.raises(ValidationError):
        CalendarSyncRequest(deadline_ids=[*deadline_ids, "DEADLINE-251"])


def test_batch_sync_skips_network_when_persisted_payload_hash_is_unchanged():
    deadline = _deadline("stable")
    request = CalendarSyncRequest(deadline_ids=["stable"], reminder_minutes=[120])
    payload = build_google_event_payload(
        deadline,
        analysis_id="analysis-1",
        reminders=request.effective_reminders(),
    )
    existing = ExistingCalendarEvent(
        deadline_id="stable",
        event_id=payload["id"],
        payload_hash=google_event_payload_hash(payload),
        event_link="https://calendar.google.com/event?eid=stable",
    )
    client = FakeHttpClient([])
    response = sync_google_calendar_batch(
        [deadline],
        request,
        analysis_id="analysis-1",
        access_token="access-token",
        existing_events=[existing],
        client=client,
    )
    assert response.status == "COMPLETE"
    assert response.results[0].status == "UNCHANGED"
    assert response.results[0].event_link == existing.event_link
    assert client.calls == []


def test_batch_update_explicitly_removes_prior_attendees_and_notifies_them():
    deadline = _deadline("remove-guests")
    old_payload = build_google_event_payload(
        deadline,
        analysis_id="analysis-1",
        attendees=["old-guest@example.com"],
    )
    existing = ExistingCalendarEvent(
        deadline_id=deadline.id,
        event_id=old_payload["id"],
        payload_hash=google_event_payload_hash(old_payload),
    )
    client = FakeHttpClient(
        [FakeResponse(200, {"id": old_payload["id"], "attendees": []})]
    )

    response = sync_google_calendar_batch(
        [deadline],
        CalendarSyncRequest(deadline_ids=[deadline.id], attendees=[]),
        analysis_id="analysis-1",
        access_token="access-token",
        existing_events=[existing],
        client=client,
    )

    assert response.results[0].status == "UPDATED"
    assert client.calls[0]["method"] == "PATCH"
    assert client.calls[0]["json"]["attendees"] == []
    assert client.calls[0]["params"] == {"sendUpdates": "all"}


def test_deterministic_id_recovers_a_retry_after_remote_insert_and_local_commit_failure():
    deadline = _deadline("crash-retry")
    event_id = stable_google_event_id("analysis-1", deadline.id)
    expected_private = {
        "bidopsAnalysisId": "analysis-1",
        "bidopsDeadlineId": deadline.id,
        "bidopsSchemaVersion": "1",
    }
    client = FakeHttpClient(
        [
            FakeResponse(409, {"error": {"status": "ALREADY_EXISTS"}}),
            FakeResponse(
                200,
                {
                    "id": event_id,
                    "extendedProperties": {"private": expected_private},
                },
            ),
            FakeResponse(
                200,
                {
                    "id": event_id,
                    "htmlLink": "https://calendar.google.com/event?eid=recovered",
                },
            ),
        ]
    )
    response = sync_google_calendar_batch(
        [deadline],
        CalendarSyncRequest(deadline_ids=[deadline.id]),
        analysis_id="analysis-1",
        access_token="access-token",
        client=client,
    )
    assert response.status == "COMPLETE"
    assert response.results[0].status == "UPDATED"
    assert [call["method"] for call in client.calls] == ["POST", "GET", "PATCH"]


def test_deterministic_id_collision_does_not_overwrite_an_unowned_event():
    deadline = _deadline("collision")
    client = FakeHttpClient(
        [
            FakeResponse(409, {"error": {"status": "ALREADY_EXISTS"}}),
            FakeResponse(
                200,
                {
                    "id": stable_google_event_id("analysis-1", deadline.id),
                    "extendedProperties": {
                        "private": {
                            "bidopsAnalysisId": "someone-else",
                            "bidopsDeadlineId": "someone-else",
                        }
                    },
                },
            ),
        ]
    )
    response = sync_google_calendar_batch(
        [deadline],
        CalendarSyncRequest(deadline_ids=[deadline.id]),
        analysis_id="analysis-1",
        access_token="access-token",
        client=client,
    )
    assert response.status == "FAILED"
    assert response.results[0].status == "FAILED"
    assert response.results[0].error == "The deterministic Google event ID is already in use."
    assert len(client.calls) == 2
