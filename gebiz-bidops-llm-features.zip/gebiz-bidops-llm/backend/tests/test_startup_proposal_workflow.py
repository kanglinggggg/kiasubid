import json
from types import SimpleNamespace

import pytest

from app.models import StartupProposalSession, StartupTenderAnalysis
from app.startup.proposal_schemas import ProposalCritique, ProposalQuestion
from app.startup.proposal_workflow import (
    ProposalWorkflowConflict,
    answer_current_question,
    create_proposal_session,
    generate_proposal_draft,
    proposal_context,
)


def _analysis(result_payload: dict | None = None) -> StartupTenderAnalysis:
    return StartupTenderAnalysis(
        id="ANALYSIS-TEST",
        filename="tender.txt",
        result_payload=result_payload
        or {
            "overview": {"summary": "A software tender", "buyer_goal": "Launch a portal"},
            "product_features": [{"id": "REQ-PORTAL", "title": "Citizen portal"}],
        },
    )


def _question(
    question_id: str = "Q-SOLUTION",
    section: str = "SOLUTION",
) -> ProposalQuestion:
    return ProposalQuestion.model_validate(
        {
            "id": question_id,
            "section": section,
            "question": "How will your team meet this requirement?",
            "why_it_matters": "The evaluator needs a concrete response.",
            "answer_guidance": ["State the approach and available evidence."],
            "required": True,
            "context_refs": [],
        }
    )


def _critique(question_id: str, *, follow_up: bool = False) -> ProposalCritique:
    return ProposalCritique(
        question_id=question_id,
        verdict="NEEDS_DETAIL" if follow_up else "STRONG",
        mentor_feedback="The response is clear enough to use in the working draft.",
        strengths=["The approach is stated clearly."],
        gaps=["Add one verifiable implementation detail."] if follow_up else [],
        formalized_answer="The supplier will use the approach described by the team.",
        answer_quotes=["answer"],
        evidence_needed=[],
        unsupported_claims=[],
        context_refs=[],
        needs_follow_up=follow_up,
        follow_up_question=(
            "Which evidence can the team provide for this approach?" if follow_up else None
        ),
    )


class _DraftResult:
    def model_dump(self, *, mode: str) -> dict:
        assert mode == "json"
        return {"title": "Generated proposal", "review_notice": "Human review required."}


class FakeBuilder:
    def __init__(
        self,
        *,
        questions: list[ProposalQuestion] | None = None,
        critiques: list[ProposalCritique] | None = None,
    ):
        self.questions = questions or []
        self.critiques = list(critiques or [])
        self.plan_calls = 0
        self.critique_calls = 0
        self.draft_calls = 0

    def create_question_plan(self, context: dict) -> SimpleNamespace:
        assert context["supplier"]["company_name"]
        self.plan_calls += 1
        return SimpleNamespace(
            result=SimpleNamespace(questions=self.questions),
            mode="BEDROCK",
            model_id="test.model",
        )

    def critique_answer(self, context, question, raw_answer, prior_answers) -> SimpleNamespace:
        assert context["supplier"]["solution_name"]
        assert question.id
        assert raw_answer.strip()
        assert len(prior_answers) == self.critique_calls
        result = self.critiques[self.critique_calls]
        self.critique_calls += 1
        return SimpleNamespace(result=result, mode="BEDROCK", model_id="test.model")

    def generate_draft(self, context, answers) -> SimpleNamespace:
        assert context["supplier"]["company_name"]
        assert answers
        self.draft_calls += 1
        return SimpleNamespace(result=_DraftResult(), mode="BEDROCK", model_id="test.model")


def _session(
    questions: list[ProposalQuestion],
    *,
    status: str = "IN_PROGRESS",
    revision: int = 0,
    current_index: int = 0,
) -> StartupProposalSession:
    return StartupProposalSession(
        id="PROPOSAL-TEST",
        analysis_id="ANALYSIS-TEST",
        company_name="Student Startup Pte. Ltd.",
        solution_name="Citizen Portal",
        status=status,
        revision=revision,
        current_index=current_index,
        questions=[question.model_dump(mode="json") for question in questions],
        answers=[],
        last_feedback=None,
        draft=None,
        provider_mode="BEDROCK",
        model_id="test.model",
    )


def test_proposal_context_enforces_a_global_model_input_budget():
    long_text = "x" * 4_000
    dense_items = [
        {"id": f"ITEM-{index}", "title": long_text, "plain_english": long_text}
        for index in range(100)
    ]
    context = proposal_context(
        _analysis(
            {
                "overview": {"summary": long_text, "buyer_goal": long_text},
                "product_features": dense_items,
                "eligibility_requirements": dense_items,
                "risks": dense_items,
            }
        )
    )
    encoded = json.dumps(context, ensure_ascii=False, separators=(",", ":"))

    assert len(encoded) <= 145_000
    assert context["product_features_total"] == 100
    assert len(context["product_features"]) <= 30
    assert len(context["product_features"][0]["title"]) <= 1_500
    assert "context_notice" in context


def test_proposal_context_discloses_count_truncation_even_when_payload_is_small():
    compact_items = [
        {"id": f"FEATURE-{index}", "title": f"Feature {index}"}
        for index in range(81)
    ]

    context = proposal_context(_analysis({"product_features": compact_items}))

    assert len(context["product_features"]) == 80
    assert context["product_features_total"] == 81
    assert "reduced B1 context" in context["context_notice"]


def test_proposal_context_keeps_checklist_ids_but_excludes_citation_payloads():
    context = proposal_context(
        _analysis(
            {
                "overview": {"summary": "Tender summary", "buyer_goal": "Buyer goal"},
                "startup_checklist": [
                    {
                        "id": "CHECKLIST-001",
                        "title": "Prepare architecture response",
                        "supporting_fact_ids": ["FACT-0000000000000001"],
                        "sources": [
                            {
                                "page": 17,
                                "section": "4.3",
                                "snippet": "Tenderers shall describe the proposed architecture.",
                            }
                        ],
                    }
                ],
            }
        )
    )

    checklist = context["startup_checklist"][0]
    assert checklist["id"] == "CHECKLIST-001"
    assert checklist["supporting_fact_ids"] == ["FACT-0000000000000001"]
    assert "sources" not in checklist


def test_follow_up_is_inserted_once_and_cannot_recursively_expand():
    base = _question()
    builder = FakeBuilder(
        critiques=[
            _critique(base.id, follow_up=True),
            _critique(f"{base.id}-followup", follow_up=True),
        ]
    )
    session = _session([base])
    analysis = _analysis()

    answer_current_question(
        proposal_session=session,
        analysis=analysis,
        question_id=base.id,
        raw_answer="First answer",
        expected_revision=0,
        builder=builder,
    )

    assert len(session.questions) == 2
    assert session.questions[1]["id"] == f"{base.id}-followup"
    assert session.status == "IN_PROGRESS"

    answer_current_question(
        proposal_session=session,
        analysis=analysis,
        question_id=f"{base.id}-followup",
        raw_answer="Follow-up answer",
        expected_revision=1,
        builder=builder,
    )

    assert len(session.questions) == 2
    assert len(session.answers) == 2
    assert session.current_index == 2
    assert session.status == "READY"


def test_answer_retry_is_idempotent_but_other_stale_writes_are_rejected():
    question = _question()
    builder = FakeBuilder(critiques=[_critique(question.id)])
    session = _session([question])
    analysis = _analysis()

    answer_current_question(
        proposal_session=session,
        analysis=analysis,
        question_id=question.id,
        raw_answer="  Same answer  ",
        expected_revision=0,
        builder=builder,
    )
    answer_current_question(
        proposal_session=session,
        analysis=analysis,
        question_id=question.id,
        raw_answer="Same answer",
        expected_revision=0,
        builder=builder,
    )

    assert builder.critique_calls == 1
    assert len(session.answers) == 1
    assert session.revision == 1

    with pytest.raises(ProposalWorkflowConflict, match="changed in another request"):
        answer_current_question(
            proposal_session=session,
            analysis=analysis,
            question_id=question.id,
            raw_answer="Different stale answer",
            expected_revision=0,
            builder=builder,
        )


def test_wrong_question_is_rejected_without_calling_the_model():
    question = _question()
    builder = FakeBuilder(critiques=[_critique(question.id)])
    session = _session([question])

    with pytest.raises(ProposalWorkflowConflict, match="not the current question"):
        answer_current_question(
            proposal_session=session,
            analysis=_analysis(),
            question_id="Q-WRONG",
            raw_answer="Some answer",
            expected_revision=0,
            builder=builder,
        )
    assert builder.critique_calls == 0


def test_session_becomes_ready_only_after_every_question_is_answered():
    first = _question("Q-FIRST", "SOLUTION")
    second = _question("Q-SECOND", "DELIVERY")
    builder = FakeBuilder(critiques=[_critique(first.id), _critique(second.id)])
    session = _session([first, second])
    analysis = _analysis()

    answer_current_question(
        proposal_session=session,
        analysis=analysis,
        question_id=first.id,
        raw_answer="First answer",
        expected_revision=0,
        builder=builder,
    )
    assert session.status == "IN_PROGRESS"

    answer_current_question(
        proposal_session=session,
        analysis=analysis,
        question_id=second.id,
        raw_answer="Second answer",
        expected_revision=1,
        builder=builder,
    )
    assert session.status == "READY"
    assert session.current_index == 2


def test_create_session_records_live_plan_metadata():
    questions = [_question()]
    builder = FakeBuilder(questions=questions)

    session = create_proposal_session(
        analysis=_analysis(),
        company_name="Student Startup Pte. Ltd.",
        solution_name="Citizen Portal",
        builder=builder,
        session_id="PROPOSAL-NEW",
    )

    assert session.id == "PROPOSAL-NEW"
    assert session.questions == [questions[0].model_dump(mode="json")]
    assert session.status == "IN_PROGRESS"
    assert session.revision == 0
    assert session.provider_mode == "BEDROCK"
    assert builder.plan_calls == 1


def test_draft_generation_is_rejected_until_session_is_ready():
    question = _question()
    builder = FakeBuilder()
    session = _session([question])

    with pytest.raises(ProposalWorkflowConflict, match="remaining 1 proposal question"):
        generate_proposal_draft(
            proposal_session=session,
            analysis=_analysis(),
            expected_revision=0,
            builder=builder,
        )
    assert builder.draft_calls == 0


def test_generated_draft_retry_is_idempotent_for_current_and_previous_revision():
    question = _question()
    builder = FakeBuilder()
    session = _session([question], status="READY", revision=5, current_index=1)
    session.answers = [
        {
            "question_id": question.id,
            "section": question.section,
            "question": question.question,
            "raw_answer": "A complete answer",
            "formalized_answer": "A complete formalized answer",
            "context_refs": [],
        }
    ]

    generate_proposal_draft(
        proposal_session=session,
        analysis=_analysis(),
        expected_revision=5,
        builder=builder,
    )
    assert session.status == "GENERATED"
    assert session.revision == 6
    assert session.draft == {
        "title": "Generated proposal",
        "review_notice": "Human review required.",
    }
    assert builder.draft_calls == 1

    generate_proposal_draft(
        proposal_session=session,
        analysis=_analysis(),
        expected_revision=5,
        builder=builder,
    )
    generate_proposal_draft(
        proposal_session=session,
        analysis=_analysis(),
        expected_revision=6,
        builder=builder,
    )
    assert builder.draft_calls == 1

    with pytest.raises(ProposalWorkflowConflict, match="Reload it before generating"):
        generate_proposal_draft(
            proposal_session=session,
            analysis=_analysis(),
            expected_revision=4,
            builder=builder,
        )
