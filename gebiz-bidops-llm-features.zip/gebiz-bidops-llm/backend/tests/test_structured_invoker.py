import json
from typing import Any

import pytest
from pydantic import BaseModel, ConfigDict, Field

from app.config import Settings
from app.llm.provider import InvocationMetrics, ModelUnavailable
from app.llm.structured import (
    StructuredInvocationUnavailable,
    StructuredInvoker,
    StructuredValidationFailure,
)


class ExampleOutput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    title: str
    score: int = Field(ge=0, le=100)


class FakeJsonClient:
    model_id = "test.model"
    mode = "TEST"

    def __init__(
        self,
        responses: list[str | Exception],
        metrics: list[InvocationMetrics] | None = None,
    ) -> None:
        self.responses = responses
        self.metrics = metrics or []
        self.calls: list[dict[str, Any]] = []
        self.last_invocation: InvocationMetrics | None = None

    def generate_json(self, **kwargs: Any) -> str:
        index = len(self.calls)
        self.calls.append(kwargs)
        if index < len(self.metrics):
            self.last_invocation = self.metrics[index]
        response = self.responses[index]
        if isinstance(response, Exception):
            raise response
        return response


def repair(original: str, invalid: str, error: str) -> str:
    return f"REPAIR::{original}::{invalid}::{error}"


def test_validates_output_and_uses_model_schema_by_default():
    fake = FakeJsonClient(['{"title": "Architecture", "score": 92}'])

    invocation = StructuredInvoker(client=fake).invoke(
        system="Return JSON.",
        prompt="Review this answer.",
        schema_name="proposal_critique",
        output_model=ExampleOutput,
        repair_prompt=repair,
        max_tokens=4096,
    )

    assert invocation.result == ExampleOutput(title="Architecture", score=92)
    assert invocation.model_id == "test.model"
    assert invocation.mode == "TEST"
    assert invocation.attempts == 1
    assert fake.calls[0]["schema"] == ExampleOutput.model_json_schema()
    assert fake.calls[0]["schema_name"] == "proposal_critique"
    assert fake.calls[0]["max_tokens"] == 4096


def test_repairs_invalid_output_and_aggregates_all_attempt_metrics():
    fake = FakeJsonClient(
        ['{"title": "First", "score": 120}', '{"title": "Fixed", "score": 88}'],
        metrics=[
            InvocationMetrics(10.5, input_tokens=20, output_tokens=5, total_tokens=25),
            InvocationMetrics(12.25, input_tokens=24, output_tokens=6, total_tokens=30),
        ],
    )
    repairs: list[tuple[str, str, str]] = []

    def record_repair(original: str, invalid: str, error: str) -> str:
        repairs.append((original, invalid, error))
        return "Correct the previous response."

    invocation = StructuredInvoker(client=fake).invoke(
        system="Return JSON.",
        prompt="Original request",
        schema_name="proposal_critique",
        output_model=ExampleOutput,
        repair_prompt=record_repair,
        max_retries=1,
    )

    assert invocation.result.score == 88
    assert invocation.attempts == 2
    assert invocation.duration_ms == 22.75
    assert invocation.input_tokens == 44
    assert invocation.output_tokens == 11
    assert invocation.total_tokens == 55
    assert repairs[0][0] == "Original request"
    assert repairs[0][1] == '{"title": "First", "score": 120}'
    assert "less than or equal to 100" in repairs[0][2]
    assert fake.calls[1]["prompt"] == "Correct the previous response."


def test_supports_normalization_and_additional_domain_validation():
    fake = FakeJsonClient(
        [
            json.dumps({"title": "architecture", "score": 80}),
            json.dumps({"title": "Security", "score": 80}),
        ]
    )

    def normalize(payload: dict[str, Any]) -> dict[str, Any]:
        return {**payload, "title": str(payload["title"]).title()}

    def require_security(result: ExampleOutput) -> None:
        if result.title != "Security":
            raise ValueError("title must identify the Security section")

    invocation = StructuredInvoker(client=fake).invoke(
        system="Return JSON.",
        prompt="Review a security response.",
        schema_name="proposal_critique",
        output_model=ExampleOutput,
        repair_prompt=repair,
        normalizer=normalize,
        validator=require_security,
        max_retries=1,
    )

    assert invocation.result.title == "Security"
    assert invocation.attempts == 2


@pytest.mark.parametrize(
    ("client", "expected_message"),
    [
        (FakeJsonClient([ModelUnavailable("provider offline")]), "provider offline"),
        (None, "BEDROCK_MODEL_ID is not configured"),
    ],
)
def test_provider_unavailability_raises_without_retry_or_fallback(
    client: FakeJsonClient | None,
    expected_message: str,
):
    app_settings = Settings(llm_provider="bedrock", bedrock_model_id=None)
    invoker = StructuredInvoker(client=client, app_settings=app_settings)

    with pytest.raises(StructuredInvocationUnavailable, match=expected_message):
        invoker.invoke(
            system="Return JSON.",
            prompt="Review this answer.",
            schema_name="proposal_critique",
            output_model=ExampleOutput,
            repair_prompt=repair,
            max_retries=3,
        )

    if client is not None:
        assert len(client.calls) == 1


def test_exhausted_validation_retries_raise_typed_failure():
    fake = FakeJsonClient(["not json", "[]"])
    invoker = StructuredInvoker(client=fake)

    with pytest.raises(StructuredValidationFailure) as raised:
        invoker.invoke(
            system="Return JSON.",
            prompt="Review this answer.",
            schema_name="proposal_critique",
            output_model=ExampleOutput,
            repair_prompt=repair,
            max_retries=1,
        )

    assert raised.value.attempts == 2
    assert "model output must be a JSON object" in raised.value.last_error
    assert len(fake.calls) == 2


def test_negative_retry_count_is_rejected_before_provider_call():
    fake = FakeJsonClient(['{"title": "Unused", "score": 1}'])

    with pytest.raises(ValueError, match="max_retries cannot be negative"):
        StructuredInvoker(client=fake).invoke(
            system="Return JSON.",
            prompt="Review this answer.",
            schema_name="proposal_critique",
            output_model=ExampleOutput,
            repair_prompt=repair,
            max_retries=-1,
        )

    assert fake.calls == []
