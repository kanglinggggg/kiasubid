from datetime import UTC, datetime
from typing import Any

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utc_now() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


class Company(Base):
    __tablename__ = "companies"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    uen: Mapped[str] = mapped_column(String, nullable=False)
    industry: Mapped[str] = mapped_column(String, nullable=False)
    employee_count: Mapped[int] = mapped_column(Integer, nullable=False)
    annual_revenue: Mapped[str] = mapped_column(String, nullable=False)


class Tender(Base):
    __tablename__ = "tenders"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    company_id: Mapped[str] = mapped_column(ForeignKey("companies.id"), nullable=False)
    title: Mapped[str] = mapped_column(String, nullable=False)
    agency: Mapped[str] = mapped_column(String, nullable=False)
    reference_number: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    closing_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    source_type: Mapped[str] = mapped_column(String, default="SYNTHETIC_DEMO")
    operational_status: Mapped[str] = mapped_column(String, default="FEASIBLE")
    previous_operational_status: Mapped[str | None] = mapped_column(String, nullable=True)
    submission_coverage: Mapped[float] = mapped_column(Float, default=0)
    deadline_risk: Mapped[str] = mapped_column(String, default="LOW")
    human_action_required: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)

    company: Mapped[Company] = relationship()
    documents: Mapped[list["TenderDocument"]] = relationship(cascade="all, delete-orphan")
    requirements: Mapped[list["Requirement"]] = relationship(cascade="all, delete-orphan")
    tasks: Mapped[list["Task"]] = relationship(cascade="all, delete-orphan")


class TenderDocument(Base):
    __tablename__ = "tender_documents"
    __table_args__ = (UniqueConstraint("tender_id", "filename", "version"),)

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tender_id: Mapped[str] = mapped_column(ForeignKey("tenders.id"), nullable=False)
    filename: Mapped[str] = mapped_column(String, nullable=False)
    document_type: Mapped[str] = mapped_column(String, nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1)
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    text_content_reference: Mapped[str | None] = mapped_column(String, nullable=True)


class Requirement(Base):
    __tablename__ = "requirements"
    __table_args__ = (UniqueConstraint("tender_id", "stable_key", "version"),)

    id: Mapped[str] = mapped_column(String, primary_key=True)
    stable_key: Mapped[str] = mapped_column(String, nullable=False)
    tender_id: Mapped[str] = mapped_column(ForeignKey("tenders.id"), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    requirement_type: Mapped[str] = mapped_column(String, nullable=False)
    gate_type: Mapped[str] = mapped_column(String, nullable=False)
    deadline: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    source_document_id: Mapped[str] = mapped_column(
        ForeignKey("tender_documents.id"), nullable=False
    )
    source_page: Mapped[int] = mapped_column(Integer, nullable=False)
    source_section: Mapped[str] = mapped_column(String, nullable=False)
    source_snippet: Mapped[str] = mapped_column(Text, nullable=False)
    supersedes_requirement_id: Mapped[str | None] = mapped_column(
        ForeignKey("requirements.id"), nullable=True
    )
    rule_config: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)

    source_document: Mapped[TenderDocument] = relationship()
    assessments: Mapped[list["Assessment"]] = relationship(cascade="all, delete-orphan")


class Employee(Base):
    __tablename__ = "employees"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    company_id: Mapped[str] = mapped_column(ForeignKey("companies.id"), nullable=False)
    name: Mapped[str] = mapped_column(String, nullable=False)
    role: Mapped[str] = mapped_column(String, nullable=False)
    employment_status: Mapped[str] = mapped_column(String, default="ACTIVE")
    availability_status: Mapped[str] = mapped_column(String, default="UNKNOWN")
    experience_years: Mapped[int] = mapped_column(Integer, nullable=False)


class Evidence(Base):
    __tablename__ = "evidence"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    company_id: Mapped[str] = mapped_column(ForeignKey("companies.id"), nullable=False)
    type: Mapped[str] = mapped_column(String, nullable=False)
    title: Mapped[str] = mapped_column(String, nullable=False)
    subject_type: Mapped[str] = mapped_column(String, nullable=False)
    subject_id: Mapped[str] = mapped_column(String, nullable=False)
    source_file: Mapped[str | None] = mapped_column(String, nullable=True)
    details: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    valid_from: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    valid_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    verification_status: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)


class Assessment(Base):
    __tablename__ = "assessments"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    requirement_id: Mapped[str] = mapped_column(ForeignKey("requirements.id"), nullable=False)
    requirement_version: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False)
    evidence_ids: Mapped[list[str]] = mapped_column(JSON, default=list)
    reason_summary: Mapped[str] = mapped_column(Text, nullable=False)
    assessed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    assessment_method: Mapped[str] = mapped_column(String, default="RULE")


class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tender_id: Mapped[str] = mapped_column(ForeignKey("tenders.id"), nullable=False)
    requirement_id: Mapped[str | None] = mapped_column(ForeignKey("requirements.id"), nullable=True)
    title: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    owner: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False)
    priority: Mapped[str] = mapped_column(String, nullable=False)
    due_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    latest_safe_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    estimated_duration_hours: Mapped[float] = mapped_column(Float, nullable=False)
    recovery_path: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class TaskDependency(Base):
    __tablename__ = "task_dependencies"

    task_id: Mapped[str] = mapped_column(ForeignKey("tasks.id"), primary_key=True)
    depends_on_task_id: Mapped[str] = mapped_column(ForeignKey("tasks.id"), primary_key=True)


class ChangeEvent(Base):
    __tablename__ = "change_events"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tender_id: Mapped[str] = mapped_column(ForeignKey("tenders.id"), nullable=False)
    source_document_id: Mapped[str] = mapped_column(
        ForeignKey("tender_documents.id"), nullable=False
    )
    event_type: Mapped[str] = mapped_column(String, nullable=False)
    detected_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    affected_requirement_ids: Mapped[list[str]] = mapped_column(JSON, default=list)


class ActivityEvent(Base):
    __tablename__ = "activity_events"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tender_id: Mapped[str] = mapped_column(ForeignKey("tenders.id"), nullable=False)
    event_type: Mapped[str] = mapped_column(String, nullable=False)
    actor: Mapped[str] = mapped_column(String, default="system")
    entity_id: Mapped[str | None] = mapped_column(String, nullable=True)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    timestamp: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


class HumanApproval(Base):
    __tablename__ = "human_approvals"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    tender_id: Mapped[str] = mapped_column(ForeignKey("tenders.id"), nullable=False)
    approved_by: Mapped[str] = mapped_column(String, nullable=False)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    approved_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


class StartupAnalysisJob(Base):
    """Durable status for an uploaded-document analysis dispatched in the background."""

    __tablename__ = "startup_analysis_jobs"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    status: Mapped[str] = mapped_column(String, nullable=False, default="QUEUED")
    stage: Mapped[str] = mapped_column(String, nullable=False, default="Queued")
    progress: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    original_filename: Mapped[str] = mapped_column(String, nullable=False)
    media_type: Mapped[str] = mapped_column(String, nullable=False)
    timezone: Mapped[str] = mapped_column(String, nullable=False, default="Asia/Singapore")
    upload_path: Mapped[str] = mapped_column(Text, nullable=False)
    document_sha256: Mapped[str] = mapped_column(String, nullable=False)
    analysis_id: Mapped[str | None] = mapped_column(
        ForeignKey("startup_tender_analyses.id"), nullable=True
    )
    error_code: Mapped[str | None] = mapped_column(String, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class StartupTenderAnalysis(Base):
    """Source-backed B1/B3 result. Raw uploaded documents are not retained."""

    __tablename__ = "startup_tender_analyses"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    filename: Mapped[str] = mapped_column(String, nullable=False)
    media_type: Mapped[str] = mapped_column(String, nullable=False)
    document_sha256: Mapped[str] = mapped_column(String, nullable=False, index=True)
    timezone: Mapped[str] = mapped_column(String, nullable=False)
    page_count: Mapped[int | None] = mapped_column(Integer, nullable=True)
    character_count: Mapped[int] = mapped_column(Integer, nullable=False)
    scanned_pages: Mapped[list[int]] = mapped_column(JSON, default=list)
    provider_mode: Mapped[str] = mapped_column(String, nullable=False)
    model_id: Mapped[str] = mapped_column(String, nullable=False)
    model_calls: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    duration_ms: Mapped[float] = mapped_column(Float, nullable=False, default=0)
    input_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    output_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    total_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    result_payload: Mapped[dict[str, Any]] = mapped_column(JSON, nullable=False)
    warnings: Mapped[list[str]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


class StartupProposalSession(Base):
    """Server-controlled B2 wizard state; user claims remain separate from AI prose."""

    __tablename__ = "startup_proposal_sessions"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    analysis_id: Mapped[str] = mapped_column(
        ForeignKey("startup_tender_analyses.id"), nullable=False, index=True
    )
    company_name: Mapped[str] = mapped_column(String, nullable=False)
    solution_name: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False, default="IN_PROGRESS")
    revision: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    current_index: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    questions: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    answers: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list)
    last_feedback: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    draft: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    provider_mode: Mapped[str] = mapped_column(String, nullable=False)
    model_id: Mapped[str] = mapped_column(String, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)


class CalendarOAuthState(Base):
    """One-time OAuth state and PKCE verifier bound to an opaque browser session."""

    __tablename__ = "calendar_oauth_states"

    state: Mapped[str] = mapped_column(String, primary_key=True)
    session_key: Mapped[str] = mapped_column(String, nullable=False, index=True)
    code_verifier: Mapped[str] = mapped_column(Text, nullable=False)
    return_path: Mapped[str] = mapped_column(String, nullable=False, default="/?mode=startup")
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


class CalendarConnection(Base):
    """Encrypted Google tokens scoped to one opaque browser session."""

    __tablename__ = "calendar_connections"

    id: Mapped[str] = mapped_column(String, primary_key=True)
    session_key: Mapped[str] = mapped_column(String, nullable=False, unique=True, index=True)
    provider: Mapped[str] = mapped_column(String, nullable=False, default="GOOGLE")
    encrypted_access_token: Mapped[str] = mapped_column(Text, nullable=False)
    encrypted_refresh_token: Mapped[str | None] = mapped_column(Text, nullable=True)
    token_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    granted_scope: Mapped[str] = mapped_column(Text, nullable=False)
    account_email: Mapped[str | None] = mapped_column(String, nullable=True)
    reauthorization_required: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)


class CalendarEventSync(Base):
    """Idempotent link between one extracted deadline and a Google Calendar event."""

    __tablename__ = "calendar_event_syncs"
    __table_args__ = (
        UniqueConstraint("connection_id", "calendar_id", "analysis_id", "deadline_id"),
    )

    id: Mapped[str] = mapped_column(String, primary_key=True)
    connection_id: Mapped[str] = mapped_column(
        ForeignKey("calendar_connections.id"), nullable=False, index=True
    )
    analysis_id: Mapped[str] = mapped_column(
        ForeignKey("startup_tender_analyses.id"), nullable=False, index=True
    )
    deadline_id: Mapped[str] = mapped_column(String, nullable=False)
    calendar_id: Mapped[str] = mapped_column(String, nullable=False)
    provider_event_id: Mapped[str] = mapped_column(String, nullable=False)
    provider_event_link: Mapped[str | None] = mapped_column(Text, nullable=True)
    payload_hash: Mapped[str] = mapped_column(String, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    last_synced_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


class CalendarDeadlinePreference(Base):
    """Durable, user-confirmed calendar inputs for one extracted deadline.

    This intentionally lives in a separate table from ``CalendarEventSync``. The
    application uses ``create_all`` rather than a migration runner, so a new table
    is safe for existing SQLite installations while adding columns to the event
    link table would not be.
    """

    __tablename__ = "calendar_deadline_preferences"
    __table_args__ = (
        UniqueConstraint("connection_id", "calendar_id", "analysis_id", "deadline_id"),
    )

    id: Mapped[str] = mapped_column(String, primary_key=True)
    connection_id: Mapped[str] = mapped_column(
        ForeignKey("calendar_connections.id"), nullable=False, index=True
    )
    analysis_id: Mapped[str] = mapped_column(
        ForeignKey("startup_tender_analyses.id"), nullable=False, index=True
    )
    deadline_id: Mapped[str] = mapped_column(String, nullable=False)
    calendar_id: Mapped[str] = mapped_column(String, nullable=False)
    # NULL means the user has never supplied that setting. Empty JSON arrays are
    # deliberate removals and must survive a reload.
    confirmed_override: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    reminder_rules: Mapped[list[dict[str, Any]] | None] = mapped_column(JSON, nullable=True)
    attendees: Mapped[list[str] | None] = mapped_column(JSON, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
