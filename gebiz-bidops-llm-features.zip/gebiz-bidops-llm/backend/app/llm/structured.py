"""Reusable, no-fallback invocation of structured language-model outputs."""

import json
from collections.abc import Callable
from dataclasses import dataclass
from time import perf_counter
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ValidationError

from app.config import Settings, settings
from app.llm.provider import JsonModelClient, ModelUnavailable, get_model_client

OutputModel = TypeVar("OutputModel", bound=BaseModel)
PayloadNormalizer = Callable[[dict[str, Any]], dict[str, Any]]
OutputValidator = Callable[[OutputModel], None]
RepairPrompt = Callable[[str, str, str], str]


class StructuredInvocationError(ValueError):
    """Base error for a structured invocation that did not produce a valid result."""


class StructuredInvocationUnavailable(StructuredInvocationError):
    """The selected provider could not execute; no fallback result was produced."""


class StructuredValidationFailure(StructuredInvocationError):
    """The provider repeatedly returned output that failed local validation."""

    def __init__(self, *, attempts: int, last_error: str):
        self.attempts = attempts
        self.last_error = last_error
        super().__init__(
            f"Model output failed validation after {attempts} "
            f"attempt{'s' if attempts != 1 else ''}: {last_error}"
        )


@dataclass(frozen=True)
class StructuredInvocation(Generic[OutputModel]):
    """A validated model result plus aggregate metrics for all attempts."""

    result: OutputModel
    model_id: str
    mode: str
    attempts: int
    duration_ms: float
    input_tokens: int | None = None
    output_tokens: int | None = None
    total_tokens: int | None = None


def _json_object(raw: str) -> dict[str, Any]:
    """Decode one JSON object, tolerating common markdown wrappers."""
    candidate = raw.strip()
    if candidate.startswith("```"):
        lines = candidate.splitlines()
        if len(lines) >= 2 and lines[-1].strip() == "```":
            candidate = "\n".join(lines[1:-1]).strip()
    if not candidate.startswith("{"):
        start = candidate.find("{")
        end = candidate.rfind("}")
        if start >= 0 and end > start:
            candidate = candidate[start : end + 1]
    value = json.loads(candidate)
    if not isinstance(value, dict):
        raise ValueError("model output must be a JSON object")
    return value


class StructuredInvoker:
    """Invoke the configured JSON model and validate output without any fallback.

    Provider availability failures stop immediately. JSON decoding, Pydantic validation,
    optional normalization, and optional domain validation failures are repaired up to the
    configured retry count by calling the supplied ``repair_prompt`` function.
    """

    def __init__(
        self,
        client: JsonModelClient | None = None,
        app_settings: Settings = settings,
    ) -> None:
        self._client = client
        self._settings = app_settings

    def _configured_client(self) -> JsonModelClient:
        if self._client is not None:
            return self._client
        return get_model_client(self._settings)

    def invoke(
        self,
        *,
        system: str,
        prompt: str,
        schema_name: str,
        output_model: type[OutputModel],
        repair_prompt: RepairPrompt,
        schema: dict[str, Any] | None = None,
        normalizer: PayloadNormalizer | None = None,
        validator: OutputValidator[OutputModel] | None = None,
        max_retries: int | None = None,
        max_tokens: int | None = None,
    ) -> StructuredInvocation[OutputModel]:
        """Return a locally validated result or raise; this method never falls back."""
        retry_count = self._settings.llm_max_retries if max_retries is None else max_retries
        if retry_count < 0:
            raise ValueError("max_retries cannot be negative")

        try:
            client = self._configured_client()
        except ModelUnavailable as exc:
            raise StructuredInvocationUnavailable(str(exc)) from exc

        output_schema = schema if schema is not None else output_model.model_json_schema()
        current_prompt = prompt
        last_error = ""
        duration_ms = 0.0
        token_totals = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
        token_observed = {key: False for key in token_totals}
        total_attempts = retry_count + 1

        for attempt in range(1, total_attempts + 1):
            started = perf_counter()
            try:
                raw_output = client.generate_json(
                    system=system,
                    prompt=current_prompt,
                    schema=output_schema,
                    schema_name=schema_name,
                    max_tokens=max_tokens,
                )
            except ModelUnavailable as exc:
                raise StructuredInvocationUnavailable(str(exc)) from exc

            measured_duration = round((perf_counter() - started) * 1000, 2)
            invocation = getattr(client, "last_invocation", None)
            duration_ms += getattr(invocation, "duration_ms", measured_duration)
            for field in token_totals:
                value = getattr(invocation, field, None)
                if isinstance(value, int) and not isinstance(value, bool):
                    token_totals[field] += value
                    token_observed[field] = True

            try:
                payload = _json_object(raw_output)
                if normalizer is not None:
                    payload = normalizer(payload)
                    if not isinstance(payload, dict):
                        raise ValueError("normalizer must return a JSON object")
                result = output_model.model_validate(payload)
                if validator is not None:
                    validator(result)
                return StructuredInvocation(
                    result=result,
                    model_id=client.model_id,
                    mode=client.mode,
                    attempts=attempt,
                    duration_ms=round(duration_ms, 2),
                    input_tokens=(
                        token_totals["input_tokens"]
                        if token_observed["input_tokens"]
                        else None
                    ),
                    output_tokens=(
                        token_totals["output_tokens"]
                        if token_observed["output_tokens"]
                        else None
                    ),
                    total_tokens=(
                        token_totals["total_tokens"]
                        if token_observed["total_tokens"]
                        else None
                    ),
                )
            except (json.JSONDecodeError, ValidationError, TypeError, ValueError) as exc:
                last_error = str(exc)
                if attempt < total_attempts:
                    current_prompt = repair_prompt(prompt, raw_output, last_error)

        raise StructuredValidationFailure(attempts=total_attempts, last_error=last_error)
