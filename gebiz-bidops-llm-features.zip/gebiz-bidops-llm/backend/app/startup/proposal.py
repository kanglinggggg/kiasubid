import json
import re
from collections.abc import Mapping, Sequence
from typing import Any, Protocol

from app.config import Settings, settings
from app.llm.provider import JsonModelClient
from app.startup.proposal_prompts import (
    PROPOSAL_SYSTEM_PROMPT,
    critique_prompt,
    draft_prompt,
    proposal_repair_prompt,
    question_plan_prompt,
)
from app.startup.proposal_schemas import (
    CORE_QUESTION_SECTIONS,
    MAX_PROPOSAL_ANSWER_CHARACTERS,
    MAX_PROPOSAL_PROMPT_CHARACTERS,
    MAX_PROPOSAL_SESSION_ANSWERS,
    MAX_PROPOSAL_TOTAL_ANSWER_CHARACTERS,
    ProposalAnswer,
    ProposalCritique,
    ProposalCritiqueEnvelope,
    ProposalDraft,
    ProposalDraftContent,
    ProposalDraftEnvelope,
    ProposalQuestion,
    ProposalQuestionPlan,
    ProposalQuestionPlanEnvelope,
)

MAX_CONTEXT_JSON_CHARS = 150_000
REVIEW_NOTICE = (
    "AI-generated preparation draft. The supplier must verify every claim, requirement, price, "
    "date, and commitment before submission."
)
_REFERENCE_KEYS = frozenset({"id", "key", "stable_key", "requirement_id", "requirement_key"})
_PLAIN_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])\d[\d,]*(?:\.\d+)?(?:\s*%)?(?![A-Za-z0-9_])"
)
_COMPACT_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])\d[\d,]*(?:\.\d+)?[A-Za-z]{1,8}(?![A-Za-z0-9_])"
)
_PREFIXED_ALPHANUMERIC_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])[A-Za-z][A-Za-z_.-]{0,15}\d[A-Za-z0-9_.-]{0,15}"
    r"(?![A-Za-z0-9_])"
)
_MULTIPLICATIVE_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])\d[\d,]*(?:\.\d+)?\s*[x×]\s*"
    r"\d[\d,]*(?:\.\d+)?(?![A-Za-z0-9_])",
    re.IGNORECASE,
)
_NUMBER_WORD_VALUES = {
    "zero": "0",
    "one": "1",
    "two": "2",
    "three": "3",
    "four": "4",
    "five": "5",
    "six": "6",
    "seven": "7",
    "eight": "8",
    "nine": "9",
    "ten": "10",
    "eleven": "11",
    "twelve": "12",
    "thirteen": "13",
    "fourteen": "14",
    "fifteen": "15",
    "sixteen": "16",
    "seventeen": "17",
    "eighteen": "18",
    "nineteen": "19",
    "twenty": "20",
    "thirty": "30",
    "forty": "40",
    "fifty": "50",
    "sixty": "60",
    "seventy": "70",
    "eighty": "80",
    "ninety": "90",
}
_NUMBER_SCALES = {
    "hundred": 100,
    "thousand": 1_000,
    "million": 1_000_000,
    "billion": 1_000_000_000,
}
_NUMBER_WORD_TOKEN = "|".join(
    sorted([*_NUMBER_WORD_VALUES, *_NUMBER_SCALES], key=len, reverse=True)
)
_NUMBER_WORD_PATTERN = re.compile(
    rf"(?<![A-Za-z])(?:{_NUMBER_WORD_TOKEN})(?:[ -]+(?:{_NUMBER_WORD_TOKEN}))*(?![A-Za-z])",
    re.IGNORECASE,
)
_LIST_NUMBER_PREFIX = re.compile(r"(?m)^[ \t]*(?:\(\d{1,3}\)|\d{1,3}[.)])[ \t]+")
_SECTION_NUMBER_PREFIX = re.compile(
    r"(?im)^[ \t]*(?:section|clause|part|chapter)[ \t]+\d{1,3}(?:\.\d{1,3})*"
)


class ProposalGroundingError(ValueError):
    """A model result refers to facts or identifiers outside its supplied context."""


class ProposalInputLimitError(ValueError):
    """The next B2 request would exceed the bounded provider-input contract."""


class _InvocationResult(Protocol):
    result: Any
    model_id: str
    mode: str
    attempts: int
    duration_ms: float
    input_tokens: int | None
    output_tokens: int | None
    total_tokens: int | None


class _StructuredInvoker(Protocol):
    def invoke(self, **kwargs: Any) -> _InvocationResult: ...


def _validated_context(context: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(context, Mapping):
        raise TypeError("B1 context must be a mapping")
    try:
        encoded = json.dumps(
            dict(context),
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        )
        decoded = json.loads(encoded)
    except (TypeError, ValueError) as exc:
        raise ValueError("B1 context must contain only finite JSON-compatible values") from exc
    if not decoded:
        raise ValueError("B1 context cannot be empty")
    if len(encoded) > MAX_CONTEXT_JSON_CHARS:
        raise ValueError(
            f"B1 context exceeds the {MAX_CONTEXT_JSON_CHARS:,}-character safety limit"
        )
    return decoded


def _checked_prompt(prompt: str) -> str:
    if len(prompt) > MAX_PROPOSAL_PROMPT_CHARACTERS:
        raise ProposalInputLimitError(
            "This proposal session is too large for the model-input safety budget. "
            "Shorten the current answer, or start a new session using shorter answers."
        )
    return prompt


def _bounded_proposal_repair_prompt(
    original_prompt: str,
    invalid_output: str,
    validation_error: str,
) -> str:
    return _checked_prompt(
        proposal_repair_prompt(original_prompt, invalid_output, validation_error)
    )


def _assert_answer_budget(
    answers: Sequence[ProposalAnswer],
    *,
    reserved_raw_characters: int = 0,
    reserved_formalized_characters: int = 0,
) -> None:
    has_reserved_answer = bool(reserved_raw_characters or reserved_formalized_characters)
    if len(answers) > MAX_PROPOSAL_SESSION_ANSWERS or (
        len(answers) == MAX_PROPOSAL_SESSION_ANSWERS and has_reserved_answer
    ):
        raise ProposalInputLimitError(
            "This proposal session has reached its answer limit. Start a new mentor session."
        )
    total = sum(len(item.raw_answer) + len(item.formalized_answer) for item in answers)
    total += reserved_raw_characters + reserved_formalized_characters
    if total > MAX_PROPOSAL_TOTAL_ANSWER_CHARACTERS:
        raise ProposalInputLimitError(
            "This proposal session has reached its answer-text budget. "
            "Shorten the current answer, or start a new session using shorter answers."
        )


def _context_reference_ids(context: Mapping[str, Any]) -> set[str]:
    references: set[str] = set()

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in _REFERENCE_KEYS and isinstance(item, (str, int)) and not isinstance(
                    item, bool
                ):
                    candidate = str(item).strip()
                    if candidate:
                        references.add(candidate)
                walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    walk(context)
    return references


def _assert_known_references(
    references: Sequence[str], allowed: set[str], location: str
) -> None:
    unknown = sorted(set(references) - allowed)
    if unknown:
        raise ProposalGroundingError(
            f"{location} contains unknown B1 context references: {', '.join(unknown)}"
        )


def _normalized_number_token(value: str) -> str:
    return re.sub(r"\s+", "", value.replace(",", "")).casefold().replace("×", "x")


def _number_word_value(value: str) -> str:
    tokens = value.casefold().replace("-", " ").split()
    total = 0
    current = 0
    for token in tokens:
        if token in _NUMBER_WORD_VALUES:
            current += int(_NUMBER_WORD_VALUES[token])
        elif token == "hundred":
            current = max(current, 1) * _NUMBER_SCALES[token]
        else:
            total += max(current, 1) * _NUMBER_SCALES[token]
            current = 0
    return str(total + current)


def _claim_text(value: str) -> str:
    """Remove structural numbering while preserving numbers used as factual prose."""
    without_list_markers = _LIST_NUMBER_PREFIX.sub("", value)
    return _SECTION_NUMBER_PREFIX.sub("", without_list_markers)


def _number_claims(text: str) -> dict[str, str]:
    """Return canonical numeric claims mapped to a representative source spelling."""
    candidate = _claim_text(text)
    claims: dict[str, str] = {}
    occupied: list[tuple[int, int]] = []

    for pattern in (
        _MULTIPLICATIVE_NUMBER_PATTERN,
        _COMPACT_NUMBER_PATTERN,
        _PREFIXED_ALPHANUMERIC_NUMBER_PATTERN,
    ):
        for match in pattern.finditer(candidate):
            canonical = _normalized_number_token(match.group())
            claims.setdefault(canonical, match.group().strip())
            occupied.append(match.span())

    occupied.sort()
    occupied_index = 0
    for match in _PLAIN_NUMBER_PATTERN.finditer(candidate):
        while (
            occupied_index < len(occupied)
            and occupied[occupied_index][1] <= match.start()
        ):
            occupied_index += 1
        if (
            occupied_index < len(occupied)
            and occupied[occupied_index][0] < match.end()
        ):
            continue
        canonical = _normalized_number_token(match.group())
        claims.setdefault(canonical, match.group().strip())
    for match in _NUMBER_WORD_PATTERN.finditer(candidate):
        canonical = _number_word_value(match.group())
        claims.setdefault(canonical, match.group().strip())
    return claims


def _source_numbers(text: str) -> set[str]:
    return set(_number_claims(text))


def _assert_no_new_numbers(output_texts: Sequence[str], source_text: str) -> None:
    allowed = _source_numbers(source_text)
    introduced: dict[str, str] = {}
    for text in output_texts:
        for normalized, token in _number_claims(text).items():
            if normalized not in allowed:
                introduced.setdefault(normalized, token)
    if introduced:
        raise ProposalGroundingError(
            "model introduced numerical claims absent from the supplied material: "
            + ", ".join(sorted(introduced.values(), key=str.casefold))
        )


def _metadata(invocation: _InvocationResult) -> dict[str, Any]:
    return {
        "mode": invocation.mode,
        "model_id": invocation.model_id,
        "attempts": invocation.attempts,
        "duration_ms": invocation.duration_ms,
        "input_tokens": invocation.input_tokens,
        "output_tokens": invocation.output_tokens,
        "total_tokens": invocation.total_tokens,
    }


def _render_markdown(
    content: ProposalDraftContent,
    review_notice: str = REVIEW_NOTICE,
) -> str:
    lines = [f"# {content.title}", "", f"> {review_notice}", "", "## Executive Summary", ""]
    for paragraph in content.executive_summary:
        lines.extend([paragraph.text, ""])
    for section in content.sections:
        lines.extend([f"## {section.heading}", ""])
        for paragraph in section.paragraphs:
            lines.extend([paragraph.text, ""])
    if content.open_items:
        lines.extend(["## Open Items for Team Review", ""])
        for item in content.open_items:
            lines.append(f"- {item.text}")
        lines.append("")
    if content.requirement_coverage:
        lines.extend(["## Requirement Coverage", ""])
        for item in content.requirement_coverage:
            lines.append(f"- **{item.context_ref} — {item.status}:** {item.explanation}")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


class ProposalBuilder:
    """Validated LLM workflows for planning, coaching, and drafting a proposal.

    This service has no deterministic content fallback. Provider and validation errors propagate to
    the caller, which can return an honest unavailable/retry response without labelling templates
    as AI output.
    """

    def __init__(
        self,
        client: JsonModelClient | None = None,
        app_settings: Settings = settings,
        *,
        invoker: _StructuredInvoker | None = None,
    ):
        if client is not None and invoker is not None:
            raise ValueError("Supply either client or invoker, not both")
        if invoker is None:
            # Imported lazily so this module stays easy to compose while the shared structured
            # invocation layer evolves independently.
            from app.llm.structured import StructuredInvoker

            invoker = StructuredInvoker(client=client, app_settings=app_settings)
        self._invoker = invoker

    def create_question_plan(
        self, context: Mapping[str, Any]
    ) -> ProposalQuestionPlanEnvelope:
        trusted_context = _validated_context(context)
        allowed_refs = _context_reference_ids(trusted_context)

        def validate(result: ProposalQuestionPlan) -> None:
            output_texts: list[str] = []
            for index, question in enumerate(result.questions):
                if question.id.casefold().endswith("-followup"):
                    raise ProposalGroundingError(
                        "question ids ending in -followup are reserved by the server"
                    )
                _assert_known_references(
                    question.context_refs,
                    allowed_refs,
                    f"questions.{index}.context_refs",
                )
                output_texts.extend(
                    [question.question, question.why_it_matters, *question.answer_guidance]
                )
            _assert_no_new_numbers(
                output_texts,
                json.dumps(trusted_context, ensure_ascii=False)
                + "\n"
                + "\n".join(question.id for question in result.questions),
            )

        invocation = self._invoker.invoke(
            system=PROPOSAL_SYSTEM_PROMPT,
            prompt=_checked_prompt(question_plan_prompt(trusted_context)),
            schema_name="startup_proposal_question_plan",
            output_model=ProposalQuestionPlan,
            repair_prompt=_bounded_proposal_repair_prompt,
            validator=validate,
            max_tokens=3000,
        )
        return ProposalQuestionPlanEnvelope(
            **_metadata(invocation),
            result=invocation.result,
        )

    def critique_answer(
        self,
        context: Mapping[str, Any],
        question: ProposalQuestion | Mapping[str, Any],
        answer: str,
        prior_answers: Sequence[ProposalAnswer | Mapping[str, Any]] = (),
    ) -> ProposalCritiqueEnvelope:
        trusted_context = _validated_context(context)
        parsed_question = ProposalQuestion.model_validate(question)
        if not isinstance(answer, str):
            raise TypeError("answer must be a string")
        clean_answer = answer.strip()
        if len(clean_answer) < 2:
            raise ValueError("answer must contain at least two characters")
        if len(clean_answer) > MAX_PROPOSAL_ANSWER_CHARACTERS:
            raise ValueError(
                f"answer exceeds the {MAX_PROPOSAL_ANSWER_CHARACTERS:,}-character limit"
            )
        parsed_answers = [ProposalAnswer.model_validate(item) for item in prior_answers]
        prior_ids = [item.question_id for item in parsed_answers]
        if len(prior_ids) != len(set(prior_ids)):
            raise ValueError("prior_answers cannot contain duplicate question ids")
        if parsed_question.id in prior_ids:
            raise ValueError("prior_answers cannot already contain the current question")
        _assert_answer_budget(
            parsed_answers,
            reserved_raw_characters=len(clean_answer),
            reserved_formalized_characters=MAX_PROPOSAL_ANSWER_CHARACTERS,
        )

        allowed_refs = _context_reference_ids(trusted_context)
        _assert_known_references(
            parsed_question.context_refs, allowed_refs, "question.context_refs"
        )
        for index, item in enumerate(parsed_answers):
            _assert_known_references(
                item.context_refs, allowed_refs, f"prior_answers.{index}.context_refs"
            )
        longest_allowed_refs = sorted(
            allowed_refs,
            key=lambda item: len(json.dumps(item, ensure_ascii=False)),
            reverse=True,
        )[:50]
        maximum_size_answer = ProposalAnswer(
            question_id=parsed_question.id,
            section=parsed_question.section,
            question=parsed_question.question,
            raw_answer=clean_answer,
            formalized_answer="\0" * MAX_PROPOSAL_ANSWER_CHARACTERS,
            context_refs=longest_allowed_refs,
        )
        _checked_prompt(
            draft_prompt(trusted_context, [*parsed_answers, maximum_size_answer])
        )
        source_text = (
            json.dumps(trusted_context, ensure_ascii=False)
            + "\n"
            + clean_answer
            + "\n"
            + "\n".join([parsed_question.id, *prior_ids])
        )

        def validate(result: ProposalCritique) -> None:
            if result.question_id != parsed_question.id:
                raise ProposalGroundingError("critique question_id does not match the input")
            for quote in result.answer_quotes:
                if quote not in clean_answer:
                    raise ProposalGroundingError(
                        "answer_quotes must be exact contiguous substrings of the current answer"
                    )
            _assert_known_references(
                result.context_refs, allowed_refs, "critique.context_refs"
            )
            _assert_no_new_numbers(
                [
                    result.mentor_feedback,
                    *result.strengths,
                    *result.gaps,
                    result.formalized_answer,
                    *result.evidence_needed,
                    *result.unsupported_claims,
                    *([result.follow_up_question] if result.follow_up_question else []),
                ],
                source_text,
            )

        prompt = _checked_prompt(
            critique_prompt(
                trusted_context,
                parsed_question,
                clean_answer,
                parsed_answers,
            )
        )
        invocation = self._invoker.invoke(
            system=PROPOSAL_SYSTEM_PROMPT,
            prompt=prompt,
            schema_name="startup_proposal_answer_critique",
            output_model=ProposalCritique,
            repair_prompt=_bounded_proposal_repair_prompt,
            validator=validate,
            max_tokens=3000,
        )
        return ProposalCritiqueEnvelope(
            **_metadata(invocation),
            result=invocation.result,
        )

    def generate_draft(
        self,
        context: Mapping[str, Any],
        answers: Sequence[ProposalAnswer | Mapping[str, Any]],
    ) -> ProposalDraftEnvelope:
        trusted_context = _validated_context(context)
        parsed_answers = [ProposalAnswer.model_validate(item) for item in answers]
        if not parsed_answers:
            raise ValueError("at least one validated proposal answer is required")
        _assert_answer_budget(parsed_answers)
        answer_ids = [item.question_id for item in parsed_answers]
        if len(answer_ids) != len(set(answer_ids)):
            raise ValueError("answers cannot contain duplicate question ids")
        answered_core = {item.section for item in parsed_answers}
        missing_core = CORE_QUESTION_SECTIONS - answered_core
        if missing_core:
            raise ValueError(
                "answers are missing required proposal sections: "
                + ", ".join(sorted(missing_core))
            )

        allowed_answer_ids = set(answer_ids)
        allowed_context_refs = _context_reference_ids(trusted_context)
        for index, item in enumerate(parsed_answers):
            _assert_known_references(
                item.context_refs,
                allowed_context_refs,
                f"answers.{index}.context_refs",
            )
        source_text = (
            json.dumps(trusted_context, ensure_ascii=False)
            + "\n"
            + "\n".join(
                f"{item.question_id}\n{item.raw_answer}\n{item.formalized_answer}"
                for item in parsed_answers
            )
        )

        def validate(result: ProposalDraftContent) -> None:
            used_answer_ids: set[str] = set()
            output_texts = [result.title, *(section.heading for section in result.sections)]
            paragraphs = [
                *result.executive_summary,
                *(paragraph for section in result.sections for paragraph in section.paragraphs),
            ]
            for index, paragraph in enumerate(paragraphs):
                unknown_answers = set(paragraph.supporting_answer_ids) - allowed_answer_ids
                if unknown_answers:
                    raise ProposalGroundingError(
                        f"paragraph {index} cites unknown answers: "
                        + ", ".join(sorted(unknown_answers))
                    )
                _assert_known_references(
                    paragraph.context_refs,
                    allowed_context_refs,
                    f"paragraphs.{index}.context_refs",
                )
                used_answer_ids.update(paragraph.supporting_answer_ids)
                output_texts.append(paragraph.text)
            for index, item in enumerate(result.open_items):
                unknown_answers = set(item.related_answer_ids) - allowed_answer_ids
                if unknown_answers:
                    raise ProposalGroundingError(
                        f"open_items.{index} cites unknown answers: "
                        + ", ".join(sorted(unknown_answers))
                    )
                _assert_known_references(
                    item.context_refs,
                    allowed_context_refs,
                    f"open_items.{index}.context_refs",
                )
                used_answer_ids.update(item.related_answer_ids)
                output_texts.append(item.text)
            for index, item in enumerate(result.requirement_coverage):
                _assert_known_references(
                    [item.context_ref],
                    allowed_context_refs,
                    f"requirement_coverage.{index}.context_ref",
                )
                output_texts.append(item.explanation)
            unused_answers = allowed_answer_ids - used_answer_ids
            if unused_answers:
                raise ProposalGroundingError(
                    "draft ignores supplied answers: " + ", ".join(sorted(unused_answers))
                )
            _assert_no_new_numbers(output_texts, source_text)

        prompt = _checked_prompt(draft_prompt(trusted_context, parsed_answers))
        invocation = self._invoker.invoke(
            system=PROPOSAL_SYSTEM_PROMPT,
            prompt=prompt,
            schema_name="startup_tender_proposal_draft",
            output_model=ProposalDraftContent,
            repair_prompt=_bounded_proposal_repair_prompt,
            validator=validate,
            max_tokens=6000,
        )
        content = invocation.result
        review_notice = REVIEW_NOTICE
        context_notice = trusted_context.get("context_notice")
        if isinstance(context_notice, str) and context_notice.strip():
            review_notice = f"{REVIEW_NOTICE} {context_notice.strip()}"[:500]
        draft = ProposalDraft(
            **content.model_dump(),
            review_notice=review_notice,
            markdown=_render_markdown(content, review_notice),
        )
        return ProposalDraftEnvelope(
            **_metadata(invocation),
            result=draft,
        )
