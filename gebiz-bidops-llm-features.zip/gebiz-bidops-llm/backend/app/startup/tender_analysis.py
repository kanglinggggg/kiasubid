"""Source-grounded map/reduce analysis of full tender documents."""

import hashlib
import json
import re
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from app.config import Settings, settings
from app.llm.provider import JsonModelClient
from app.llm.structured import StructuredInvocation, StructuredInvoker
from app.startup.analysis_prompts import (
    ANALYSIS_SYSTEM_PROMPT,
    analysis_repair_prompt,
    chunk_analysis_prompt,
    synthesis_prompt,
)
from app.startup.analysis_schemas import (
    AnalysisOverview,
    AnalysisResult,
    ChunkFact,
    ChunkFactSet,
    Deadline,
    DeliveryPhase,
    DocumentChunk,
    DocumentMetrics,
    EligibilityRequirement,
    ExtractedBlock,
    ExtractedDocument,
    GlossaryTerm,
    GroundedAnalysisDraft,
    GroundedFact,
    PaymentMilestone,
    ProductFeature,
    ProviderMetrics,
    Risk,
    SourceCitation,
    StartupChecklistItem,
    TenderAnalysisEnvelope,
    _deadline_shape_is_safe,
    _valid_timezone,
)
from app.startup.document_ingestion import DocumentIngestor, chunk_document

ProgressCallback = Callable[[str, int, int], None]

_MODEL_DIRECTIVE_PATTERN = re.compile(
    r"\b(?:system\s+instruction|instruction\s+to\s+(?:ai|model|assistant)|"
    r"ignore\s+(?:all\s+|any\s+|the\s+)?(?:previous|prior|system|developer)\s+instructions?|"
    r"reveal\s+(?:the\s+)?(?:system\s+)?prompt|call\s+(?:a\s+)?tool)\b",
    re.IGNORECASE,
)
_PLAIN_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])(?:S|US)?[$£€]?[+-]?\d[\d,]*(?:\.\d+)?(?:\s*%)?"
    r"(?![A-Za-z0-9_])",
    re.IGNORECASE,
)
_COMPACT_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])(?:S|US)?[$£€]?[+-]?\d[\d,]*(?:\.\d+)?"
    r"[A-Za-z]{1,12}(?![A-Za-z0-9_])",
    re.IGNORECASE,
)
_PREFIXED_COMPACT_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])[A-Za-z]{1,12}\d[\d,.]*(?:[A-Za-z]{0,8})"
    r"(?![A-Za-z0-9_])",
    re.IGNORECASE,
)
_MULTIPLICATIVE_NUMBER_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_])\d[\d,]*(?:\.\d+)?\s*[x×]\s*"
    r"\d[\d,]*(?:\.\d+)?(?![A-Za-z0-9_])",
    re.IGNORECASE,
)
_NUMBER_WORD_VALUES = {
    "zero": 0,
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "nine": 9,
    "ten": 10,
    "eleven": 11,
    "twelve": 12,
    "thirteen": 13,
    "fourteen": 14,
    "fifteen": 15,
    "sixteen": 16,
    "seventeen": 17,
    "eighteen": 18,
    "nineteen": 19,
    "twenty": 20,
    "thirty": 30,
    "forty": 40,
    "fifty": 50,
    "sixty": 60,
    "seventy": 70,
    "eighty": 80,
    "ninety": 90,
}
_NUMBER_SCALES = {
    "hundred": 100,
    "thousand": 1_000,
    "million": 1_000_000,
    "billion": 1_000_000_000,
}
_NUMBER_WORD_TOKEN = "|".join(
    sorted([*_NUMBER_WORD_VALUES, *_NUMBER_SCALES], key=len, reverse=True)
)
_NUMBER_WORD_PATTERN = re.compile(
    rf"(?<![A-Za-z])(?:{_NUMBER_WORD_TOKEN})"
    rf"(?:[ -]+(?:{_NUMBER_WORD_TOKEN}))*(?![A-Za-z])",
    re.IGNORECASE,
)
_LIST_NUMBER_PREFIX = re.compile(r"(?m)^[ \t]*(?:\(\d{1,3}\)|\d{1,3}[.)])[ \t]+")
_HEADING_NUMBER_PREFIX = re.compile(
    r"(?m)^[ \t]*\d{1,3}(?:\.\d{1,3})+[.)]?[ \t]+"
)
_STRUCTURAL_REFERENCE_PATTERN = re.compile(
    r"\b(?:section|clause|part|chapter|paragraph|schedule|annex|appendix|page)\s*"
    r"\d{1,4}(?:\.\d{1,4})*[A-Za-z]?\b",
    re.IGNORECASE,
)
_KIND_SUPPORT: dict[str, set[str]] = {
    "product_features": {"PRODUCT_FEATURE"},
    "delivery_phases": {"DELIVERY_PHASE"},
    "payment_milestones": {"PAYMENT"},
    "deadlines": {"DEADLINE"},
    "eligibility_requirements": {"ELIGIBILITY"},
    "risks": {"RISK"},
    "glossary": {"JARGON"},
}
_PUBLIC_LIST_LIMIT = 250
_CHECKLIST_LIMIT = 500
_WARNINGS_LIMIT = 250


@dataclass
class _MetricAccumulator:
    mode: str | None = None
    model_id: str | None = None
    calls: int = 0
    attempts: int = 0
    duration_ms: float = 0.0
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    saw_input_tokens: bool = False
    saw_output_tokens: bool = False
    saw_total_tokens: bool = False

    def add(self, invocation: StructuredInvocation[Any]) -> None:
        if self.mode is not None and (
            self.mode != invocation.mode or self.model_id != invocation.model_id
        ):
            raise ValueError("One document analysis cannot mix model providers")
        self.mode = invocation.mode
        self.model_id = invocation.model_id
        self.calls += 1
        self.attempts += invocation.attempts
        self.duration_ms += invocation.duration_ms
        for field in ("input_tokens", "output_tokens", "total_tokens"):
            value = getattr(invocation, field)
            if value is not None:
                setattr(self, field, getattr(self, field) + value)
                setattr(self, f"saw_{field}", True)

    def result(self) -> ProviderMetrics:
        if self.mode is None or self.model_id is None or self.calls == 0:
            raise ValueError("No live model invocation completed")
        return ProviderMetrics(
            mode=self.mode,
            model_id=self.model_id,
            calls=self.calls,
            attempts=self.attempts,
            duration_ms=round(self.duration_ms, 2),
            input_tokens=self.input_tokens if self.saw_input_tokens else None,
            output_tokens=self.output_tokens if self.saw_output_tokens else None,
            total_tokens=self.total_tokens if self.saw_total_tokens else None,
        )


def _notify(callback: ProgressCallback | None, stage: str, completed: int, total: int) -> None:
    if callback is not None:
        callback(stage, completed, total)


def _normalized_number_token(value: str) -> str:
    return re.sub(r"\s+", "", value.replace(",", "")).casefold().replace("×", "x")


def _number_word_value(value: str) -> str:
    tokens = value.casefold().replace("-", " ").split()
    total = 0
    current = 0
    for token in tokens:
        if token in _NUMBER_WORD_VALUES:
            current += _NUMBER_WORD_VALUES[token]
        elif token == "hundred":
            current = max(current, 1) * _NUMBER_SCALES[token]
        else:
            total += max(current, 1) * _NUMBER_SCALES[token]
            current = 0
    return str(total + current)


def _claim_text(value: str) -> str:
    """Remove numbering that identifies document structure, rather than a commitment."""
    value = _STRUCTURAL_REFERENCE_PATTERN.sub("", value)
    value = _LIST_NUMBER_PREFIX.sub("", value)
    return _HEADING_NUMBER_PREFIX.sub("", value)


def _number_claims(text: str) -> dict[str, str]:
    """Return normalized numeric claims and one representative source spelling."""
    candidate = _claim_text(text)
    claims: dict[str, str] = {}
    occupied: list[tuple[int, int]] = []
    for pattern in (
        _MULTIPLICATIVE_NUMBER_PATTERN,
        _COMPACT_NUMBER_PATTERN,
        _PREFIXED_COMPACT_NUMBER_PATTERN,
    ):
        for match in pattern.finditer(candidate):
            canonical = _normalized_number_token(match.group())
            claims.setdefault(canonical, match.group().strip())
            occupied.append(match.span())

    occupied.sort()
    occupied_index = 0
    for match in _PLAIN_NUMBER_PATTERN.finditer(candidate):
        while occupied_index < len(occupied) and occupied[occupied_index][1] <= match.start():
            occupied_index += 1
        if occupied_index < len(occupied) and occupied[occupied_index][0] < match.end():
            continue
        canonical = _normalized_number_token(match.group())
        claims.setdefault(canonical, match.group().strip())
    for match in _NUMBER_WORD_PATTERN.finditer(candidate):
        canonical = _number_word_value(match.group())
        claims.setdefault(canonical, match.group().strip())
    return claims


def _assert_no_new_numeric_claims(
    output_texts: Sequence[str], source_snippets: Sequence[str], *, location: str
) -> None:
    allowed: set[str] = set()
    for snippet in source_snippets:
        allowed.update(_number_claims(snippet))
    introduced: dict[str, str] = {}
    for text in output_texts:
        for normalized, token in _number_claims(text).items():
            if normalized not in allowed:
                introduced.setdefault(normalized, token)
    if introduced:
        values = ", ".join(sorted(introduced.values(), key=str.casefold))
        raise ValueError(
            f"{location} introduced numeric claims absent from its cited exact source "
            f"snippet(s): {values}"
        )


def _fact_numeric_texts(fact: ChunkFact) -> list[str]:
    values: list[str | int | None] = [
        fact.title,
        fact.plain_english,
        *fact.details,
        fact.sequence,
        fact.timing,
        fact.date_text,
        fact.amount,
        fact.trigger,
        fact.mitigation,
        fact.term,
    ]
    return [str(value) for value in values if value is not None]


def _draft_numeric_texts(value: Any) -> list[str]:
    payload = value.model_dump(
        mode="python",
        exclude={"supporting_fact_ids", "deadline_at", "due_at"},
    )
    values: list[str] = []

    def collect(item: Any) -> None:
        if isinstance(item, str):
            values.append(item)
        elif isinstance(item, (int, float)) and not isinstance(item, bool):
            values.append(str(item))
        elif isinstance(item, dict):
            for nested in item.values():
                collect(nested)
        elif isinstance(item, list):
            for nested in item:
                collect(nested)

    collect(payload)
    return values


def _validate_material_due_at(fact: ChunkFact, *, index: int) -> None:
    if fact.deadline_at is None or fact.kind == "DEADLINE":
        return
    if fact.kind not in {"DELIVERY_PHASE", "PAYMENT"}:
        raise ValueError(f"facts.{index}.deadline_at is not valid for a {fact.kind} fact")
    if not fact.timezone:
        raise ValueError(
            f"facts.{index}.deadline_at requires an explicit source timezone and timezone field"
        )
    timezone = _valid_timezone(fact.timezone)
    try:
        _deadline_shape_is_safe(
            date_text=fact.source.snippet,
            deadline_at=fact.deadline_at,
            all_day=False,
            timezone=timezone,
            confidence="HIGH",
            needs_review=False,
        )
    except ValueError as exc:
        raise ValueError(
            f"facts.{index}.deadline_at must match one unambiguous date, weekday, clock "
            "time, and timezone in its source snippet"
        ) from exc


def _validate_chunk_facts(chunk: DocumentChunk, result: ChunkFactSet) -> None:
    blocks = {block.block_id: block for block in chunk.blocks}
    for index, fact in enumerate(result.facts):
        block = blocks.get(fact.source.block_id)
        if block is None:
            raise ValueError(f"facts.{index}.source.block_id is not in this chunk")
        if fact.source.page != block.page:
            raise ValueError(f"facts.{index}.source.page does not match its source block")
        if fact.source.section != block.section:
            raise ValueError(f"facts.{index}.source.section does not match its source block")
        if fact.source.snippet not in block.text:
            raise ValueError(f"facts.{index}.source.snippet must be an exact source substring")
        if _MODEL_DIRECTIVE_PATTERN.search(fact.source.snippet):
            raise ValueError(f"facts.{index} attempts to operationalize model-directed text")
        _assert_no_new_numeric_claims(
            _fact_numeric_texts(fact),
            [fact.source.snippet],
            location=f"facts.{index}",
        )
        _validate_material_due_at(fact, index=index)
        if fact.kind == "DEADLINE" and (
            not fact.date_text or fact.date_text not in fact.source.snippet
        ):
            raise ValueError(
                f"facts.{index}.date_text must be an exact substring of its source snippet"
            )


def _fact_id(document: ExtractedDocument, block: ExtractedBlock, fact: ChunkFact) -> str:
    semantic_payload = json.dumps(
        fact.model_dump(mode="json", exclude={"source"}),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    identity = "\x1f".join(
        [
            document.sha256,
            block.block_id,
            fact.kind,
            fact.source.snippet,
            semantic_payload,
        ]
    ).encode()
    return f"FACT-{hashlib.sha256(identity).hexdigest()[:16].upper()}"


def _ground_chunk_facts(
    document: ExtractedDocument, chunk: DocumentChunk, result: ChunkFactSet
) -> list[GroundedFact]:
    blocks = {block.block_id: block for block in chunk.blocks}
    grounded: list[GroundedFact] = []
    for fact in result.facts:
        block = blocks[fact.source.block_id]
        grounded.append(
            GroundedFact(
                fact_id=_fact_id(document, block, fact),
                kind=fact.kind,
                title=fact.title,
                plain_english=fact.plain_english,
                obligation_level=fact.obligation_level,
                details=fact.details,
                sequence=fact.sequence,
                timing=fact.timing,
                date_text=fact.date_text,
                deadline_at=fact.deadline_at,
                deadline_kind=fact.deadline_kind,
                all_day=fact.all_day,
                timezone=fact.timezone,
                confidence=fact.confidence,
                needs_review=fact.needs_review,
                amount=fact.amount,
                trigger=fact.trigger,
                mitigation=fact.mitigation,
                term=fact.term,
                source=SourceCitation(
                    page=block.page,
                    section=block.section or block.locator,
                    snippet=fact.source.snippet,
                ),
            )
        )
    return grounded


def _dedupe_facts(facts: Iterable[GroundedFact]) -> list[GroundedFact]:
    unique: dict[str, GroundedFact] = {}
    for fact in facts:
        unique.setdefault(fact.fact_id, fact)
    return list(unique.values())


def _batch_facts(facts: list[GroundedFact], max_characters: int) -> list[list[GroundedFact]]:
    batches: list[list[GroundedFact]] = []
    current: list[GroundedFact] = []
    current_size = 0
    for fact in facts:
        fact_size = len(json.dumps(fact.model_dump(mode="json"), ensure_ascii=False))
        if current and (current_size + fact_size > max_characters or len(current) >= 80):
            batches.append(current)
            current = []
            current_size = 0
        current.append(fact)
        current_size += fact_size
    if current:
        batches.append(current)
    return batches


def _support_ids(value: Any) -> list[str]:
    return list(getattr(value, "supporting_fact_ids"))


def _support_key(value: Any) -> tuple[str, ...]:
    return tuple(sorted(set(_support_ids(value))))


def _scalar_identity(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    return value


def _validate_supported_scalar(
    *,
    location: str,
    actual: Any,
    cited: Sequence[GroundedFact],
    fact_field: str,
    allow_missing_trigger_label: bool = False,
) -> None:
    supported = [getattr(fact, fact_field) for fact in cited]
    non_null = [value for value in supported if value is not None]
    if non_null:
        allowed = {_scalar_identity(value) for value in non_null}
        if _scalar_identity(actual) not in allowed:
            raise ValueError(
                f"{location} must exactly match the same field in at least one cited fact"
            )
        return
    if allow_missing_trigger_label and actual == "Not stated in the supplied text":
        return
    if actual is not None:
        raise ValueError(f"{location} must be null because no cited fact supplies it")


def _validate_draft(
    draft: GroundedAnalysisDraft, facts: dict[str, GroundedFact]
) -> None:
    allowed_ids = set(facts)

    def validate_ids(label: str, items: Iterable[Any], kinds: set[str] | None = None) -> None:
        for index, item in enumerate(items):
            ids = _support_ids(item)
            unknown = set(ids) - allowed_ids
            if unknown:
                raise ValueError(f"{label}.{index} cites unknown fact ids: {sorted(unknown)}")
            if kinds is not None and any(facts[fact_id].kind not in kinds for fact_id in ids):
                raise ValueError(f"every {label}.{index} citation must match its fact kind")

    overview_ids = draft.overview.supporting_fact_ids
    if not overview_ids:
        raise ValueError("overview must cite at least one fact")
    if set(overview_ids) - allowed_ids:
        raise ValueError("overview cites an unknown fact id")
    if any(
        value is not None
        for value in (
            draft.overview.tender_title,
            draft.overview.agency,
            draft.overview.reference_number,
        )
    ) and not any(facts[fact_id].kind == "OVERVIEW" for fact_id in overview_ids):
        raise ValueError("overview metadata must cite an OVERVIEW fact")

    for field, kinds in _KIND_SUPPORT.items():
        validate_ids(field, getattr(draft, field), kinds)
    validate_ids("startup_checklist", draft.startup_checklist)
    validate_ids("clarification_questions", draft.clarification_questions)

    for field, kinds in _KIND_SUPPORT.items():
        expected = {
            fact_id for fact_id, fact in facts.items() if fact.kind in kinds
        }
        represented = {
            fact_id
            for item in getattr(draft, field)
            for fact_id in _support_ids(item)
        }
        missing = expected - represented
        if missing:
            raise ValueError(
                f"{field} omits validated {next(iter(kinds))} facts: {sorted(missing)}"
            )
    expected_actions = {
        fact_id for fact_id, fact in facts.items() if fact.kind == "ACTION"
    }
    represented_actions = {
        fact_id
        for item in draft.startup_checklist
        for fact_id in _support_ids(item)
        if facts[fact_id].kind == "ACTION"
    }
    missing_actions = expected_actions - represented_actions
    if missing_actions:
        raise ValueError(
            f"startup_checklist omits validated ACTION facts: {sorted(missing_actions)}"
        )

    _assert_no_new_numeric_claims(
        _draft_numeric_texts(draft.overview),
        [facts[fact_id].source.snippet for fact_id in overview_ids],
        location="overview",
    )
    grounded_fields = [
        "product_features",
        "delivery_phases",
        "payment_milestones",
        "deadlines",
        "eligibility_requirements",
        "startup_checklist",
        "risks",
        "clarification_questions",
        "glossary",
    ]
    for field in grounded_fields:
        for index, item in enumerate(getattr(draft, field)):
            _assert_no_new_numeric_claims(
                _draft_numeric_texts(item),
                [facts[fact_id].source.snippet for fact_id in _support_ids(item)],
                location=f"{field}.{index}",
            )

    for index, phase in enumerate(draft.delivery_phases):
        cited = [facts[fact_id] for fact_id in phase.supporting_fact_ids]
        for draft_field, fact_field in (
            ("sequence", "sequence"),
            ("timing", "timing"),
            ("due_at", "deadline_at"),
            ("timezone", "timezone"),
        ):
            _validate_supported_scalar(
                location=f"delivery_phases.{index}.{draft_field}",
                actual=getattr(phase, draft_field),
                cited=cited,
                fact_field=fact_field,
            )

    for index, payment in enumerate(draft.payment_milestones):
        cited = [facts[fact_id] for fact_id in payment.supporting_fact_ids]
        for draft_field, fact_field in (
            ("amount", "amount"),
            ("trigger", "trigger"),
            ("timing", "timing"),
            ("due_at", "deadline_at"),
            ("timezone", "timezone"),
        ):
            _validate_supported_scalar(
                location=f"payment_milestones.{index}.{draft_field}",
                actual=getattr(payment, draft_field),
                cited=cited,
                fact_field=fact_field,
                allow_missing_trigger_label=draft_field == "trigger",
            )

    for index, checklist_item in enumerate(draft.startup_checklist):
        cited = [facts[fact_id] for fact_id in checklist_item.supporting_fact_ids]
        _validate_supported_scalar(
            location=f"startup_checklist.{index}.due_at",
            actual=checklist_item.due_at,
            cited=cited,
            fact_field="deadline_at",
        )

    for index, deadline in enumerate(draft.deadlines):
        cited = [facts[fact_id] for fact_id in deadline.supporting_fact_ids]
        expected_values = {
            (
                fact.deadline_kind,
                fact.date_text,
                fact.deadline_at,
                fact.all_day,
                fact.timezone,
                fact.confidence,
                fact.needs_review,
            )
            for fact in cited
        }
        actual = (
            deadline.kind,
            deadline.date_text,
            deadline.deadline_at,
            deadline.all_day,
            deadline.timezone,
            deadline.confidence,
            deadline.needs_review,
        )
        if expected_values != {actual}:
            raise ValueError(
                f"deadlines.{index} fields must exactly match its cited DEADLINE facts"
            )


def _source(item: Any, facts: dict[str, GroundedFact]) -> SourceCitation:
    return facts[_support_ids(item)[0]].source


def _sources(item: Any, facts: dict[str, GroundedFact]) -> list[SourceCitation]:
    result: list[SourceCitation] = []
    seen: set[tuple[int | None, str | None, str]] = set()
    for fact_id in dict.fromkeys(_support_ids(item)):
        source = facts[fact_id].source
        identity = (source.page, source.section, source.snippet)
        if identity not in seen:
            seen.add(identity)
            result.append(source)
    return result


def _unique_strings(values: Iterable[str], *, limit: int | None = 250) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        clean = " ".join(value.split())
        key = clean.casefold()
        if clean and key not in seen:
            seen.add(key)
            result.append(clean)
            if limit is not None and len(result) >= limit:
                break
    return result


def _dedupe_models(values: Iterable[Any], key: Callable[[Any], object]) -> list[Any]:
    result: list[Any] = []
    seen: set[object] = set()
    for value in values:
        identity = key(value)
        if identity not in seen:
            seen.add(identity)
            result.append(value)
    return result


def _cap_public_list(
    values: list[Any],
    *,
    field_name: str,
    limit: int,
    truncation_warnings: list[str],
) -> list[Any]:
    """Keep the first unique results and report every public-contract truncation."""
    if len(values) <= limit:
        return values
    truncation_warnings.append(
        f"The {field_name} list was truncated from {len(values)} to {limit} entries "
        "to fit the analysis response limit."
    )
    return values[:limit]


def _finalize_warnings(
    values: Iterable[str], *, required: Iterable[str] = ()
) -> list[str]:
    """Cap warnings while reserving room for required and self-truncation notices."""
    unique = _unique_strings(values, limit=None)
    if len(unique) <= _WARNINGS_LIMIT:
        return unique

    notice = (
        f"The warnings list contained {len(unique)} unique entries; it was truncated "
        f"to {_WARNINGS_LIMIT - 1} entries plus this notice "
        f"({_WARNINGS_LIMIT} total)."
    )
    notice_key = notice.casefold()
    retained: list[str] = []
    retained_keys: set[str] = set()
    for value in [*_unique_strings(required, limit=None), *unique]:
        key = value.casefold()
        if key == notice_key or key in retained_keys:
            continue
        retained.append(value)
        retained_keys.add(key)
        if len(retained) >= _WARNINGS_LIMIT - 1:
            break
    return [*retained, notice]


def _consistent_metadata(
    drafts: list[GroundedAnalysisDraft], field: str, warnings: list[str]
) -> str | None:
    values = _unique_strings(
        value
        for draft in drafts
        if (value := getattr(draft.overview, field)) is not None
    )
    if len(values) > 1:
        warnings.append(
            f"The document contains multiple possible {field.replace('_', ' ')} values; "
            "review them."
        )
    return values[0] if values else None


def _combine_text(values: Iterable[str], *, maximum: int) -> str:
    combined = " ".join(_unique_strings(values))
    if len(combined) <= maximum:
        return combined
    return combined[: maximum - 1].rstrip() + "…"


def _empty_analysis(document: ExtractedDocument, warnings: list[str]) -> AnalysisResult:
    no_facts_warning = (
        "The live model found no source-grounded tender facts in the supplied document."
    )
    warnings.append(no_facts_warning)
    return AnalysisResult(
        overview=AnalysisOverview(
            tender_title=None,
            agency=None,
            reference_number=None,
            summary="No explicit tender requirements could be extracted from the supplied text.",
            buyer_goal="The buyer's goal was not stated clearly enough to extract.",
        ),
        warnings=_finalize_warnings(warnings, required=[no_facts_warning]),
        human_review_required=True,
    )


def _assemble_result(
    document: ExtractedDocument,
    facts: list[GroundedFact],
    drafts: list[GroundedAnalysisDraft],
    pipeline_warnings: list[str],
) -> AnalysisResult:
    del document  # document warnings have already been copied into pipeline_warnings
    fact_lookup = {fact.fact_id: fact for fact in facts}
    warnings = list(pipeline_warnings)
    truncation_warnings: list[str] = []
    for draft in drafts:
        warnings.extend(draft.warnings)

    overview = AnalysisOverview(
        tender_title=_consistent_metadata(drafts, "tender_title", warnings),
        agency=_consistent_metadata(drafts, "agency", warnings),
        reference_number=_consistent_metadata(drafts, "reference_number", warnings),
        summary=_combine_text((draft.overview.summary for draft in drafts), maximum=8_000),
        buyer_goal=_combine_text((draft.overview.buyer_goal for draft in drafts), maximum=4_000),
    )

    draft_features = [item for draft in drafts for item in draft.product_features]
    unique_features = _cap_public_list(
        _dedupe_models(
            draft_features,
            lambda value: (value.title.casefold(), _support_key(value)),
        ),
        field_name="product_features",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    product_features = [
        ProductFeature(
            id=f"FEATURE-{index:03d}",
            title=item.title,
            plain_english=item.plain_english,
            obligation_level=item.obligation_level,
            acceptance_criteria=item.acceptance_criteria,
            source=_source(item, fact_lookup),
            sources=_sources(item, fact_lookup),
        )
        for index, item in enumerate(unique_features, 1)
    ]

    draft_phases = [item for draft in drafts for item in draft.delivery_phases]
    unique_phases = _cap_public_list(
        _dedupe_models(
            draft_phases,
            lambda value: (value.sequence, value.name.casefold(), _support_key(value)),
        ),
        field_name="delivery_phases",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    delivery_phases = [
        DeliveryPhase(
            id=f"PHASE-{index:03d}",
            sequence=item.sequence,
            name=item.name,
            deliverables=item.deliverables,
            timing=item.timing,
            due_at=item.due_at,
            timezone=item.timezone,
            source=_source(item, fact_lookup),
            sources=_sources(item, fact_lookup),
        )
        for index, item in enumerate(unique_phases, 1)
    ]

    draft_payments = [item for draft in drafts for item in draft.payment_milestones]
    unique_payments = _cap_public_list(
        _dedupe_models(
            draft_payments,
            lambda value: (
                value.milestone.casefold(),
                value.trigger.casefold(),
                _support_key(value),
            ),
        ),
        field_name="payment_milestones",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    payment_milestones = [
        PaymentMilestone(
            id=f"PAYMENT-{index:03d}",
            milestone=item.milestone,
            trigger=item.trigger,
            amount=item.amount,
            timing=item.timing,
            due_at=item.due_at,
            timezone=item.timezone,
            source=_source(item, fact_lookup),
            sources=_sources(item, fact_lookup),
        )
        for index, item in enumerate(unique_payments, 1)
    ]

    draft_deadlines = [item for draft in drafts for item in draft.deadlines]
    unique_deadlines = _cap_public_list(
        _dedupe_models(
            draft_deadlines,
            lambda value: (
                value.kind,
                value.title.casefold(),
                value.date_text.casefold(),
                _support_key(value),
            ),
        ),
        field_name="deadlines",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    deadlines = [
        Deadline(
            id=f"DEADLINE-{index:03d}",
            kind=fact_lookup[item.supporting_fact_ids[0]].deadline_kind,
            title=item.title,
            date_text=fact_lookup[item.supporting_fact_ids[0]].date_text,
            deadline_at=fact_lookup[item.supporting_fact_ids[0]].deadline_at,
            all_day=fact_lookup[item.supporting_fact_ids[0]].all_day,
            timezone=fact_lookup[item.supporting_fact_ids[0]].timezone,
            confidence=fact_lookup[item.supporting_fact_ids[0]].confidence,
            needs_review=fact_lookup[item.supporting_fact_ids[0]].needs_review,
            source=_source(item, fact_lookup),
        )
        for index, item in enumerate(unique_deadlines, 1)
    ]

    draft_eligibility = [item for draft in drafts for item in draft.eligibility_requirements]
    unique_eligibility = _cap_public_list(
        _dedupe_models(
            draft_eligibility,
            lambda value: (value.title.casefold(), _support_key(value)),
        ),
        field_name="eligibility_requirements",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    eligibility_requirements = [
        EligibilityRequirement(
            id=f"ELIGIBILITY-{index:03d}",
            title=item.title,
            plain_english=item.plain_english,
            obligation_level=item.obligation_level,
            source=_source(item, fact_lookup),
            sources=_sources(item, fact_lookup),
        )
        for index, item in enumerate(unique_eligibility, 1)
    ]

    draft_checklist = [item for draft in drafts for item in draft.startup_checklist]
    unique_checklist = _cap_public_list(
        _dedupe_models(
            draft_checklist,
            lambda value: (value.title.casefold(), _support_key(value)),
        ),
        field_name="startup_checklist",
        limit=_CHECKLIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    startup_checklist = [
        StartupChecklistItem(
            id=f"CHECKLIST-{index:03d}",
            title=item.title,
            description=item.description,
            category=item.category,
            priority=item.priority,
            due_at=item.due_at,
            supporting_fact_ids=list(dict.fromkeys(item.supporting_fact_ids)),
            sources=_sources(item, fact_lookup),
        )
        for index, item in enumerate(unique_checklist, 1)
    ]

    draft_risks = [item for draft in drafts for item in draft.risks]
    unique_risks = _cap_public_list(
        _dedupe_models(
            draft_risks,
            lambda value: (value.title.casefold(), _support_key(value)),
        ),
        field_name="risks",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    risks = [
        Risk(
            id=f"RISK-{index:03d}",
            title=item.title,
            plain_english=item.plain_english,
            mitigation=item.mitigation,
            source=_source(item, fact_lookup),
            sources=_sources(item, fact_lookup),
        )
        for index, item in enumerate(unique_risks, 1)
    ]

    draft_glossary = [item for draft in drafts for item in draft.glossary]
    unique_glossary = _cap_public_list(
        _dedupe_models(
            draft_glossary,
            lambda value: (value.term.casefold(), _support_key(value)),
        ),
        field_name="glossary",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )
    glossary = [
        GlossaryTerm(
            term=item.term,
            plain_english=item.plain_english,
            source=_source(item, fact_lookup),
            sources=_sources(item, fact_lookup),
        )
        for item in unique_glossary
    ]

    clarification_questions = _cap_public_list(
        _unique_strings(
            (
                item.question
                for draft in drafts
                for item in draft.clarification_questions
            ),
            limit=None,
        ),
        field_name="clarification_questions",
        limit=_PUBLIC_LIST_LIMIT,
        truncation_warnings=truncation_warnings,
    )

    for values, warning in (
        (product_features, "No explicit product features were identified."),
        (delivery_phases, "No explicit delivery phases were identified."),
        (payment_milestones, "No explicit payment milestones were identified."),
    ):
        if not values:
            warnings.append(warning)
    warnings.extend(truncation_warnings)
    human_review_warning = "Human review is required before relying on this tender analysis."
    warnings.append(human_review_warning)

    return AnalysisResult(
        overview=overview,
        product_features=product_features,
        delivery_phases=delivery_phases,
        payment_milestones=payment_milestones,
        deadlines=deadlines,
        eligibility_requirements=eligibility_requirements,
        startup_checklist=startup_checklist,
        risks=risks,
        clarification_questions=clarification_questions,
        glossary=glossary,
        warnings=_finalize_warnings(
            warnings,
            required=[*truncation_warnings, human_review_warning],
        ),
        human_review_required=True,
    )


class TenderAnalysisService:
    """Run live-model analysis; provider or validation failures are never replaced by demo data."""

    def __init__(
        self,
        client: JsonModelClient | None = None,
        app_settings: Settings = settings,
        *,
        invoker: StructuredInvoker | None = None,
        ingestor: DocumentIngestor | None = None,
    ) -> None:
        if client is not None and invoker is not None:
            raise ValueError("Pass either client or invoker, not both")
        self._settings = app_settings
        self._invoker = invoker or StructuredInvoker(client=client, app_settings=app_settings)
        self._ingestor = ingestor or DocumentIngestor(app_settings)

    def analyze(
        self,
        *,
        filename: str,
        content: bytes,
        progress: ProgressCallback | None = None,
    ) -> TenderAnalysisEnvelope:
        _notify(progress, "EXTRACTING", 0, 1)
        document = self._ingestor.ingest(filename=filename, content=content)
        _notify(progress, "EXTRACTING", 1, 1)
        timezone = str(getattr(self._settings, "startup_timezone", "Asia/Singapore"))
        return self.analyse(document, timezone=timezone, progress=progress)

    def analyse(
        self,
        document: ExtractedDocument,
        *,
        timezone: str,
        progress: ProgressCallback | None = None,
    ) -> TenderAnalysisEnvelope:
        timezone = timezone.strip()
        if not timezone or len(timezone) > 100:
            raise ValueError("timezone must be a non-empty IANA timezone name")
        try:
            ZoneInfo(timezone)
        except (ValueError, ZoneInfoNotFoundError) as exc:
            raise ValueError("timezone must be a valid IANA timezone name") from exc
        chunk_size = int(
            getattr(self._settings, "startup_analysis_chunk_characters", 28_000)
        )
        chunks = chunk_document(document, max_characters=chunk_size)
        metrics = _MetricAccumulator()
        grounded_facts: list[GroundedFact] = []
        pipeline_warnings = list(document.warnings)
        map_tokens = min(
            4_000, int(getattr(self._settings, "llm_max_output_tokens", 6_000))
        )

        for index, chunk in enumerate(chunks, 1):
            _notify(progress, "ANALYSING", index - 1, len(chunks))
            invocation = self._invoker.invoke(
                system=ANALYSIS_SYSTEM_PROMPT,
                prompt=chunk_analysis_prompt(document, chunk, timezone=timezone),
                schema_name="startup_tender_chunk_facts",
                output_model=ChunkFactSet,
                repair_prompt=analysis_repair_prompt,
                validator=lambda result, current=chunk: _validate_chunk_facts(
                    current, result
                ),
                max_tokens=map_tokens,
            )
            metrics.add(invocation)
            grounded_facts.extend(_ground_chunk_facts(document, chunk, invocation.result))
            pipeline_warnings.extend(invocation.result.warnings)
            _notify(progress, "ANALYSING", index, len(chunks))

        facts = _dedupe_facts(grounded_facts)
        if not facts:
            result = _empty_analysis(document, pipeline_warnings)
        else:
            reduce_character_limit = max(12_000, min(chunk_size * 2, 60_000))
            batches = _batch_facts(facts, reduce_character_limit)
            drafts: list[GroundedAnalysisDraft] = []
            _notify(progress, "SYNTHESISING", 0, len(batches))
            max_tokens = int(getattr(self._settings, "llm_max_output_tokens", 6_000))
            for index, batch in enumerate(batches, 1):
                fact_lookup = {fact.fact_id: fact for fact in batch}
                invocation = self._invoker.invoke(
                    system=ANALYSIS_SYSTEM_PROMPT,
                    prompt=synthesis_prompt(document, batch, timezone=timezone),
                    schema_name="startup_tender_analysis",
                    output_model=GroundedAnalysisDraft,
                    repair_prompt=analysis_repair_prompt,
                    validator=lambda draft, current=fact_lookup: _validate_draft(
                        draft, current
                    ),
                    max_tokens=max_tokens,
                )
                metrics.add(invocation)
                drafts.append(invocation.result)
                _notify(progress, "SYNTHESISING", index, len(batches))
            result = _assemble_result(document, facts, drafts, pipeline_warnings)

        return TenderAnalysisEnvelope(
            result=result,
            document=DocumentMetrics(
                filename=document.filename,
                media_type=document.media_type,
                sha256=document.sha256,
                page_count=document.page_count,
                pages_with_text=document.pages_with_text,
                scanned_pages=document.scanned_pages,
                block_count=len(document.blocks),
                character_count=document.character_count,
                chunks_total=len(chunks),
                chunks_analysed=len(chunks),
            ),
            provider=metrics.result(),
        )

    def analyze_document(
        self,
        document: ExtractedDocument,
        *,
        timezone: str | None = None,
        progress: ProgressCallback | None = None,
    ) -> TenderAnalysisEnvelope:
        """US-spelling compatibility wrapper for non-router callers."""
        effective_timezone = timezone or str(
            getattr(self._settings, "startup_timezone", "Asia/Singapore")
        )
        return self.analyse(document, timezone=effective_timezone, progress=progress)
