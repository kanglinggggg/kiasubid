"""HTTP routes and persistence orchestration for the Startup Studio."""

import base64
import hashlib
import hmac
import logging
import re
import secrets
import unicodedata
from copy import deepcopy
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Annotated, NoReturn
from urllib.parse import urlencode
from uuid import uuid4
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from fastapi.responses import RedirectResponse
from pydantic import ValidationError
from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from app.config import PROJECT_ROOT, settings
from app.database import SessionLocal, get_session
from app.llm.structured import (
    StructuredInvocationUnavailable,
    StructuredValidationFailure,
)
from app.models import (
    CalendarConnection,
    CalendarDeadlinePreference,
    CalendarEventSync,
    CalendarOAuthState,
    StartupAnalysisJob,
    StartupProposalSession,
    StartupTenderAnalysis,
)
from app.startup.api_schemas import (
    AnalysisJobResponse,
    CalendarStatusResponse,
    ProposalAnswerSubmit,
    ProposalGenerateRequest,
    ProposalSessionCreate,
    ProposalSessionResponse,
)
from app.startup.calendar import (
    GOOGLE_CALENDAR_SCOPES,
    CalendarConfigurationError,
    CalendarProviderError,
    CalendarTokenCipher,
    CalendarValidationError,
    build_ics_calendar,
    create_google_authorization,
    exchange_google_code,
    refresh_google_token,
    sync_google_calendar_batch,
)
from app.startup.calendar_schemas import (
    CalendarAnalysisStateResponse,
    CalendarDeadlineSettings,
    CalendarSyncRequest,
    CalendarSyncResponse,
    DeadlineSyncOverride,
    ExistingCalendarEvent,
    ReminderOverride,
)
from app.startup.document_ingestion import DocumentIngestionError, DocumentIngestor
from app.startup.persistence import (
    analysis_job_payload,
    proposal_session_payload,
    tender_analysis_payload,
)
from app.startup.proposal import ProposalBuilder, ProposalInputLimitError
from app.startup.proposal_workflow import (
    ProposalWorkflowConflict,
    answer_current_question,
    create_proposal_session,
    generate_proposal_draft,
)
from app.startup.tender_analysis import TenderAnalysisService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/startup", tags=["startup-studio"])

_UPLOAD_DIRECTORY = PROJECT_ROOT / "data" / "startup_uploads"
_SUPPORTED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md", ".markdown"}
_CALENDAR_COOKIE = "bidops_calendar_session"
_CALENDAR_COOKIE_MAX_AGE = 30 * 24 * 60 * 60
_OAUTH_STATE_LIFETIME = timedelta(minutes=10)
_ORPHAN_UPLOAD_MINIMUM_AGE = timedelta(hours=1)
_MANAGED_UPLOAD_NAME = re.compile(r"^JOB-[0-9a-f]{16}\.upload$")


def get_tender_analysis_service() -> TenderAnalysisService:
    return TenderAnalysisService()


def get_proposal_builder() -> ProposalBuilder:
    return ProposalBuilder()


def _utcnow() -> datetime:
    return datetime.now(UTC).replace(tzinfo=None)


def _aware_utc(value: datetime) -> datetime:
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _safe_filename(value: str) -> str:
    if "/" in value or "\\" in value:
        raise HTTPException(status_code=422, detail="The upload filename is invalid.")
    if any(unicodedata.category(character).startswith("C") for character in value):
        raise HTTPException(status_code=422, detail="The upload filename is invalid.")
    clean = value.strip().strip(".")
    if not clean or len(clean) > 255:
        raise HTTPException(status_code=422, detail="The upload filename is invalid.")
    if Path(clean).suffix.casefold() not in _SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail="Supported file types are PDF, DOCX, TXT, and Markdown.",
        )
    return clean


def _valid_timezone(value: str) -> str:
    candidate = value.strip()
    if not candidate or len(candidate) > 100:
        raise HTTPException(status_code=422, detail="Use a valid IANA time-zone name.")
    try:
        ZoneInfo(candidate)
    except (ValueError, ZoneInfoNotFoundError) as exc:
        raise HTTPException(status_code=422, detail="Use a valid IANA time-zone name.") from exc
    return candidate


def _require_live_model() -> None:
    if not settings.interpretation_configured:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "Startup Studio requires a configured Bedrock or Groq model. "
                "Set the selected provider's model and credentials, then retry."
            ),
        )


def _raise_model_http_error(exc: Exception) -> NoReturn:
    if isinstance(exc, StructuredInvocationUnavailable):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="The configured language-model provider is unavailable. No fallback was used.",
        ) from exc
    if isinstance(exc, StructuredValidationFailure):
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=(
                "The language model did not return a source-grounded response that passed "
                "validation. No fallback was used; please retry."
            ),
        ) from exc
    raise exc


class _ProposalRevisionLost(RuntimeError):
    """A concurrent request persisted a newer proposal revision first."""


def _persist_proposal_revision(
    session: Session,
    proposal: StartupProposalSession,
    *,
    loaded_revision: int,
) -> StartupProposalSession:
    """Persist a workflow mutation with an atomic optimistic revision check.

    The model call happens before this function, so holding a database write lock while waiting on
    a provider would be unnecessarily disruptive. A compare-and-swap update prevents a second
    request that loaded the same revision from silently overwriting the first result.
    """
    if proposal.revision == loaded_revision:
        if session.is_modified(proposal, include_collections=True):
            raise RuntimeError("A proposal workflow mutation did not advance its revision.")
        return proposal
    if proposal.revision != loaded_revision + 1:
        raise RuntimeError("A proposal workflow transition must advance exactly one revision.")

    proposal_id = proposal.id
    values = {
        "status": proposal.status,
        "revision": proposal.revision,
        "current_index": proposal.current_index,
        "questions": deepcopy(proposal.questions),
        "answers": deepcopy(proposal.answers),
        "last_feedback": deepcopy(proposal.last_feedback),
        "draft": deepcopy(proposal.draft),
        "provider_mode": proposal.provider_mode,
        "model_id": proposal.model_id,
        "updated_at": proposal.updated_at,
    }
    session.expunge(proposal)
    result = session.execute(
        update(StartupProposalSession)
        .where(
            StartupProposalSession.id == proposal_id,
            StartupProposalSession.revision == loaded_revision,
        )
        .values(**values)
        .execution_options(synchronize_session=False)
    )
    if result.rowcount != 1:
        session.rollback()
        raise _ProposalRevisionLost
    session.commit()
    persisted = session.get(StartupProposalSession, proposal_id)
    if persisted is None:
        raise RuntimeError("The proposal session disappeared while its revision was persisted.")
    return persisted


def _same_answer_retry(
    proposal: StartupProposalSession,
    *,
    expected_revision: int,
    question_id: str,
    raw_answer: str,
) -> bool:
    previous = proposal.answers[-1] if proposal.answers else None
    return bool(
        expected_revision == proposal.revision - 1
        and isinstance(previous, dict)
        and previous.get("question_id") == question_id
        and previous.get("raw_answer") == raw_answer
    )


def _same_generate_retry(
    proposal: StartupProposalSession, *, expected_revision: int
) -> bool:
    return proposal.status == "GENERATED" and expected_revision in {
        proposal.revision,
        proposal.revision - 1,
    }


def _job_progress(job: StartupAnalysisJob, stage: str, completed: int, total: int) -> None:
    if stage == "EXTRACTING":
        job.status = "EXTRACTING"
        job.stage = "Extracting machine-readable text"
        job.progress = 10 + round(15 * completed / max(total, 1))
    elif stage == "ANALYSING":
        job.status = "ANALYSING"
        job.stage = "Extracting source-grounded tender facts"
        job.progress = 25 + round(50 * completed / max(total, 1))
    else:
        job.status = "ANALYSING"
        job.stage = "Synthesising the plain-English brief"
        job.progress = 75 + round(20 * completed / max(total, 1))
    job.updated_at = _utcnow()


def _trusted_upload_path(job: StartupAnalysisJob) -> Path:
    root = _UPLOAD_DIRECTORY.resolve()
    candidate = Path(job.upload_path).resolve()
    if candidate.parent != root or candidate.name != f"{job.id}.upload":
        raise ValueError("The stored upload path is outside the managed upload directory.")
    return candidate


def _remove_stale_orphan_uploads(session: Session) -> None:
    """Retry terminal-job cleanup, then remove old unreferenced managed uploads."""
    if not _UPLOAD_DIRECTORY.is_dir():
        return
    root = _UPLOAD_DIRECTORY.resolve()
    referenced: set[Path] = set()
    for job in session.scalars(select(StartupAnalysisJob)).all():
        try:
            upload_path = _trusted_upload_path(job)
        except ValueError:
            logger.warning("Analysis job %s contains an invalid managed upload path", job.id)
            continue
        if job.status in {"COMPLETED", "FAILED"}:
            try:
                upload_path.unlink(missing_ok=True)
            except OSError:
                logger.warning("Could not remove terminal-job upload for job %s", job.id)
                referenced.add(upload_path)
            continue
        referenced.add(upload_path)

    cutoff = datetime.now(UTC) - _ORPHAN_UPLOAD_MINIMUM_AGE
    try:
        candidates = list(_UPLOAD_DIRECTORY.iterdir())
    except OSError:
        logger.warning("Could not inspect the managed startup upload directory")
        return
    for candidate in candidates:
        if candidate.is_symlink() or not candidate.is_file():
            continue
        if not _MANAGED_UPLOAD_NAME.fullmatch(candidate.name):
            continue
        resolved = candidate.resolve()
        if resolved.parent != root or resolved in referenced:
            continue
        try:
            modified_at = datetime.fromtimestamp(candidate.stat().st_mtime, UTC)
            if modified_at > cutoff:
                continue
            candidate.unlink()
        except OSError:
            logger.warning("Could not remove stale orphan upload %s", candidate.name)


def _run_analysis_job(job_id: str, service: TenderAnalysisService) -> None:
    """Execute a queued analysis in FastAPI's background-task thread pool."""
    with SessionLocal() as session:
        job = session.get(StartupAnalysisJob, job_id)
        if job is None:
            return
        try:
            claimed = session.execute(
                update(StartupAnalysisJob)
                .where(
                    StartupAnalysisJob.id == job_id,
                    StartupAnalysisJob.status == "QUEUED",
                )
                .values(
                    status="EXTRACTING",
                    stage="Extracting machine-readable text",
                    progress=10,
                    updated_at=_utcnow(),
                )
                .execution_options(synchronize_session=False)
            )
            session.commit()
        except Exception:
            logger.exception("Could not claim startup analysis job %s", job_id)
            session.rollback()
            _fail_job(
                session,
                job_id,
                code="JOB_CLAIM_FAILED",
                message="The analysis job could not be started. Retry the upload.",
            )
            return
        if claimed.rowcount != 1:
            return
        session.expire_all()
        job = session.get(StartupAnalysisJob, job_id)
        if job is None:
            return
        upload_path: Path | None = None
        try:
            upload_path = _trusted_upload_path(job)
            maximum = settings.startup_upload_max_bytes
            if upload_path.stat().st_size > maximum:
                raise DocumentIngestionError(
                    "UPLOAD_TOO_LARGE",
                    f"The upload exceeds the {maximum:,}-byte limit.",
                )
            content = upload_path.read_bytes()
            document = DocumentIngestor().ingest(filename=job.original_filename, content=content)
            if document.sha256 != job.document_sha256:
                raise DocumentIngestionError(
                    "UPLOAD_INTEGRITY_FAILED",
                    "The staged upload changed before analysis and was rejected.",
                )
            job.media_type = document.media_type
            _job_progress(job, "EXTRACTING", 1, 1)
            session.commit()

            def report(stage: str, completed: int, total: int) -> None:
                _job_progress(job, stage, completed, total)
                session.commit()

            envelope = service.analyse(document, timezone=job.timezone, progress=report)
            analysis_id = f"ANALYSIS-{uuid4().hex[:16]}"
            analysis = StartupTenderAnalysis(
                id=analysis_id,
                filename=envelope.document.filename,
                media_type=envelope.document.media_type,
                document_sha256=envelope.document.sha256,
                timezone=job.timezone,
                page_count=envelope.document.page_count,
                character_count=envelope.document.character_count,
                scanned_pages=envelope.document.scanned_pages,
                provider_mode=envelope.provider.mode,
                model_id=envelope.provider.model_id,
                model_calls=envelope.provider.calls,
                attempts=envelope.provider.attempts,
                duration_ms=envelope.provider.duration_ms,
                input_tokens=envelope.provider.input_tokens,
                output_tokens=envelope.provider.output_tokens,
                total_tokens=envelope.provider.total_tokens,
                result_payload=envelope.result.model_dump(mode="json"),
                warnings=envelope.result.warnings,
            )
            session.add(analysis)
            session.flush()
            job.analysis_id = analysis_id
            job.status = "COMPLETED"
            job.stage = "Analysis complete"
            job.progress = 100
            job.completed_at = _utcnow()
            job.updated_at = job.completed_at
            session.commit()
        except DocumentIngestionError as exc:
            session.rollback()
            failed_job = session.get(StartupAnalysisJob, job_id)
            if failed_job is not None:
                failed_job.status = "FAILED"
                failed_job.stage = "Document extraction failed"
                failed_job.progress = 100
                failed_job.error_code = exc.code
                failed_job.error_message = str(exc)
                failed_job.completed_at = _utcnow()
                failed_job.updated_at = failed_job.completed_at
                session.commit()
        except StructuredInvocationUnavailable:
            logger.exception("Startup analysis provider unavailable for job %s", job_id)
            session.rollback()
            _fail_job(
                session,
                job_id,
                code="MODEL_UNAVAILABLE",
                message=(
                    "The configured language-model provider was unavailable. "
                    "No fallback analysis was used."
                ),
            )
        except StructuredValidationFailure:
            logger.exception("Startup analysis failed grounding validation for job %s", job_id)
            session.rollback()
            _fail_job(
                session,
                job_id,
                code="MODEL_VALIDATION_FAILED",
                message=(
                    "The model response did not pass source-grounding validation. "
                    "No fallback analysis was used; retry the analysis."
                ),
            )
        except Exception:
            logger.exception("Unexpected startup analysis failure for job %s", job_id)
            session.rollback()
            _fail_job(
                session,
                job_id,
                code="ANALYSIS_FAILED",
                message="The tender analysis failed unexpectedly. Retry the upload.",
            )
        finally:
            try:
                if upload_path is not None:
                    upload_path.unlink(missing_ok=True)
            except OSError:
                logger.warning("Could not remove temporary upload for job %s", job_id)


def _fail_job(session: Session, job_id: str, *, code: str, message: str) -> None:
    job = session.get(StartupAnalysisJob, job_id)
    if job is None:
        return
    job.status = "FAILED"
    job.stage = "Analysis failed"
    job.progress = 100
    job.error_code = code
    job.error_message = message
    job.completed_at = _utcnow()
    job.updated_at = job.completed_at
    session.commit()


def recover_interrupted_analysis_jobs() -> None:
    """Mark jobs interrupted by a process restart as failed and remove temporary uploads."""
    with SessionLocal() as session:
        jobs = session.scalars(
            select(StartupAnalysisJob).where(
                StartupAnalysisJob.status.in_(["QUEUED", "EXTRACTING", "ANALYSING"])
            )
        ).all()
        for job in jobs:
            try:
                _trusted_upload_path(job).unlink(missing_ok=True)
            except (OSError, ValueError):
                logger.warning("Could not remove interrupted upload for job %s", job.id)
            job.status = "FAILED"
            job.stage = "Interrupted by server restart"
            job.progress = 100
            job.error_code = "SERVER_RESTARTED"
            job.error_message = "The server restarted during analysis. Upload the document again."
            job.completed_at = _utcnow()
            job.updated_at = job.completed_at
        if jobs:
            session.commit()
        _remove_stale_orphan_uploads(session)


@router.post(
    "/analysis-jobs",
    response_model=AnalysisJobResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def create_analysis_job(
    request: Request,
    background_tasks: BackgroundTasks,
    filename: Annotated[str, Query(min_length=1, max_length=255)],
    timezone: Annotated[str, Query(min_length=1, max_length=100)] = settings.startup_timezone,
    session: Session = Depends(get_session),
    service: TenderAnalysisService = Depends(get_tender_analysis_service),
) -> dict:
    _require_live_model()
    clean_filename = _safe_filename(filename)
    clean_timezone = _valid_timezone(timezone)
    maximum = settings.startup_upload_max_bytes
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            declared_size = int(content_length)
        except ValueError as exc:
            raise HTTPException(
                status_code=400, detail="Content-Length must be an integer."
            ) from exc
        if declared_size > maximum:
            raise HTTPException(
                status_code=413, detail=f"Uploads are limited to {maximum:,} bytes."
            )

    job_id = f"JOB-{uuid4().hex[:16]}"
    _UPLOAD_DIRECTORY.mkdir(parents=True, exist_ok=True)
    upload_path = _UPLOAD_DIRECTORY / f"{job_id}.upload"
    digest = hashlib.sha256()
    size = 0
    try:
        with upload_path.open("xb") as destination:
            async for chunk in request.stream():
                if not chunk:
                    continue
                size += len(chunk)
                if size > maximum:
                    raise HTTPException(
                        status_code=413,
                        detail=f"Uploads are limited to {maximum:,} bytes.",
                    )
                digest.update(chunk)
                destination.write(chunk)
    except Exception:
        upload_path.unlink(missing_ok=True)
        raise
    if size == 0:
        upload_path.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail="The uploaded document is empty.")

    media_type = (request.headers.get("content-type") or "application/octet-stream")[:255]
    job = StartupAnalysisJob(
        id=job_id,
        status="QUEUED",
        stage="Queued for source-grounded analysis",
        progress=0,
        original_filename=clean_filename,
        media_type=media_type,
        timezone=clean_timezone,
        upload_path=str(upload_path),
        document_sha256=digest.hexdigest(),
    )
    try:
        session.add(job)
        session.commit()
    except Exception:
        session.rollback()
        upload_path.unlink(missing_ok=True)
        raise
    background_tasks.add_task(_run_analysis_job, job_id, service)
    return analysis_job_payload(job)


@router.get("/analysis-jobs/{job_id}", response_model=AnalysisJobResponse)
def get_analysis_job(job_id: str, session: Session = Depends(get_session)) -> dict:
    job = session.get(StartupAnalysisJob, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Analysis job not found.")
    return analysis_job_payload(job)


@router.get("/analyses/{analysis_id}")
def get_analysis(analysis_id: str, session: Session = Depends(get_session)) -> dict:
    analysis = session.get(StartupTenderAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Tender analysis not found.")
    return tender_analysis_payload(analysis)


@router.post("/proposal-sessions", response_model=ProposalSessionResponse)
def start_proposal_session(
    payload: ProposalSessionCreate,
    session: Session = Depends(get_session),
    builder: ProposalBuilder = Depends(get_proposal_builder),
) -> dict:
    analysis_id = payload.analysis_id.strip()
    company_name = payload.company_name.strip()
    solution_name = payload.solution_name.strip()
    if not analysis_id:
        raise HTTPException(status_code=422, detail="Tender analysis id cannot be blank.")
    if len(company_name) < 2:
        raise HTTPException(
            status_code=422, detail="Company name must contain at least two characters."
        )
    if len(solution_name) < 2:
        raise HTTPException(
            status_code=422, detail="Solution name must contain at least two characters."
        )
    _require_live_model()
    analysis = session.get(StartupTenderAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Tender analysis not found.")
    try:
        proposal = create_proposal_session(
            analysis=analysis,
            company_name=company_name,
            solution_name=solution_name,
            builder=builder,
            session_id=f"PROPOSAL-{uuid4().hex[:16]}",
        )
    except ProposalInputLimitError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except (StructuredInvocationUnavailable, StructuredValidationFailure) as exc:
        _raise_model_http_error(exc)
    session.add(proposal)
    session.commit()
    return proposal_session_payload(proposal)


@router.get("/proposal-sessions/{proposal_id}", response_model=ProposalSessionResponse)
def get_proposal_session(
    proposal_id: str, session: Session = Depends(get_session)
) -> dict:
    proposal = session.get(StartupProposalSession, proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="Proposal session not found.")
    return proposal_session_payload(proposal)


@router.post(
    "/proposal-sessions/{proposal_id}/answers",
    response_model=ProposalSessionResponse,
)
def submit_proposal_answer(
    proposal_id: str,
    payload: ProposalAnswerSubmit,
    session: Session = Depends(get_session),
    builder: ProposalBuilder = Depends(get_proposal_builder),
) -> dict:
    question_id = payload.question_id.strip()
    raw_answer = payload.answer.strip()
    if not question_id:
        raise HTTPException(status_code=422, detail="Question id cannot be blank.")
    if len(raw_answer) < 2:
        raise HTTPException(
            status_code=422, detail="Answer must contain at least two characters."
        )
    _require_live_model()
    proposal = session.get(StartupProposalSession, proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="Proposal session not found.")
    analysis = session.get(StartupTenderAnalysis, proposal.analysis_id)
    if analysis is None:
        raise HTTPException(status_code=409, detail="The source tender analysis is unavailable.")
    loaded_revision = proposal.revision
    try:
        answer_current_question(
            proposal_session=proposal,
            analysis=analysis,
            question_id=question_id,
            raw_answer=raw_answer,
            expected_revision=payload.revision,
            builder=builder,
        )
    except ProposalWorkflowConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ProposalInputLimitError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except (StructuredInvocationUnavailable, StructuredValidationFailure) as exc:
        _raise_model_http_error(exc)
    try:
        proposal = _persist_proposal_revision(
            session, proposal, loaded_revision=loaded_revision
        )
    except _ProposalRevisionLost as exc:
        current = session.get(StartupProposalSession, proposal_id)
        if current is not None and _same_answer_retry(
            current,
            expected_revision=payload.revision,
            question_id=question_id,
            raw_answer=raw_answer,
        ):
            return proposal_session_payload(current)
        raise HTTPException(
            status_code=409,
            detail="This proposal session changed in another request. Reload it before continuing.",
        ) from exc
    return proposal_session_payload(proposal)


@router.post(
    "/proposal-sessions/{proposal_id}/generate",
    response_model=ProposalSessionResponse,
)
def generate_proposal(
    proposal_id: str,
    payload: ProposalGenerateRequest,
    session: Session = Depends(get_session),
    builder: ProposalBuilder = Depends(get_proposal_builder),
) -> dict:
    _require_live_model()
    proposal = session.get(StartupProposalSession, proposal_id)
    if proposal is None:
        raise HTTPException(status_code=404, detail="Proposal session not found.")
    analysis = session.get(StartupTenderAnalysis, proposal.analysis_id)
    if analysis is None:
        raise HTTPException(status_code=409, detail="The source tender analysis is unavailable.")
    loaded_revision = proposal.revision
    try:
        generate_proposal_draft(
            proposal_session=proposal,
            analysis=analysis,
            expected_revision=payload.revision,
            builder=builder,
        )
    except ProposalWorkflowConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ProposalInputLimitError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except (StructuredInvocationUnavailable, StructuredValidationFailure) as exc:
        _raise_model_http_error(exc)
    try:
        proposal = _persist_proposal_revision(
            session, proposal, loaded_revision=loaded_revision
        )
    except _ProposalRevisionLost as exc:
        current = session.get(StartupProposalSession, proposal_id)
        if current is not None and _same_generate_retry(
            current, expected_revision=payload.revision
        ):
            return proposal_session_payload(current)
        raise HTTPException(
            status_code=409,
            detail="This proposal session changed in another request. Reload it before generating.",
        ) from exc
    return proposal_session_payload(proposal)


def _calendar_connection(request: Request, session: Session) -> CalendarConnection | None:
    session_id = _calendar_session_id(request.cookies.get(_CALENDAR_COOKIE))
    if session_id is None:
        return None
    return session.scalar(
        select(CalendarConnection).where(
            CalendarConnection.session_key == session_id,
            CalendarConnection.provider == "GOOGLE",
        )
    )


def _calendar_cookie_signature(raw_token: str) -> str | None:
    if settings.app_secret_key is None:
        return None
    secret = settings.app_secret_key.get_secret_value().encode("utf-8")
    digest = hmac.new(
        secret,
        b"gebiz-bidops/calendar-session-cookie/v1\x00" + raw_token.encode("ascii"),
        hashlib.sha256,
    ).digest()
    return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def _raw_calendar_session_token(value: str | None) -> str | None:
    if not value or len(value) != 87 or value.count(".") != 1:
        return None
    raw_token, supplied_signature = value.split(".", 1)
    if (
        len(raw_token) != 43
        or len(supplied_signature) != 43
        or not all(
            character.isascii() and (character.isalnum() or character in "-_")
            for character in raw_token + supplied_signature
        )
    ):
        return None
    expected_signature = _calendar_cookie_signature(raw_token)
    if expected_signature is None or not secrets.compare_digest(
        supplied_signature, expected_signature
    ):
        return None
    return raw_token


def _new_calendar_session_cookie() -> str:
    raw_token = secrets.token_urlsafe(32)
    signature = _calendar_cookie_signature(raw_token)
    if signature is None:
        raise CalendarConfigurationError("APP_SECRET_KEY is not configured.")
    return f"{raw_token}.{signature}"


def _calendar_session_id(cookie_value: str | None) -> str | None:
    raw_token = _raw_calendar_session_token(cookie_value)
    if raw_token is None:
        return None
    return hashlib.sha256(
        b"gebiz-bidops/calendar-session-id/v1\x00" + raw_token.encode("ascii")
    ).hexdigest()


def _calendar_scope_is_valid(connection: CalendarConnection) -> bool:
    return set(GOOGLE_CALENDAR_SCOPES).issubset(
        set((connection.granted_scope or "").split())
    )


def _calendar_connection_needs_reauthorization(connection: CalendarConnection) -> bool:
    expires_without_refresh = bool(
        connection.token_expires_at is not None
        and _aware_utc(connection.token_expires_at) <= datetime.now(UTC) + timedelta(minutes=1)
        and not connection.encrypted_refresh_token
    )
    return bool(
        connection.reauthorization_required
        or not _calendar_scope_is_valid(connection)
        or expires_without_refresh
    )


@router.get("/calendar/status", response_model=CalendarStatusResponse)
def calendar_status(
    request: Request,
    response: Response,
    session: Session = Depends(get_session),
) -> dict:
    configured = settings.google_calendar_configured
    connection = _calendar_connection(request, session) if configured else None
    reauthorization_required = bool(
        connection and _calendar_connection_needs_reauthorization(connection)
    )
    connected = bool(connection and not reauthorization_required)
    if not configured:
        message = "Google Calendar sync is not configured; .ics export remains available."
    elif connected:
        message = "Google Calendar is connected for this browser session."
    elif reauthorization_required:
        message = "Google Calendar authorization expired. Reconnect to continue syncing."
    else:
        message = "Connect Google Calendar to create or update deadline events."
    response.headers["Cache-Control"] = "private, no-store"
    return {
        "configured": configured,
        "connected": connected,
        "provider": "GOOGLE",
        "account_email": connection.account_email if connection else None,
        "reauthorization_required": reauthorization_required,
        "scope": connection.granted_scope if connection else None,
        "ics_available": True,
        "message": message,
    }


@router.get("/calendar/google/authorize")
def authorize_google_calendar(
    request: Request,
    force_consent: bool = False,
    session: Session = Depends(get_session),
) -> Response:
    if not settings.google_calendar_configured:
        raise HTTPException(status_code=503, detail="Google Calendar OAuth is not configured.")
    try:
        cookie_value = request.cookies.get(_CALENDAR_COOKIE)
        session_id = _calendar_session_id(cookie_value)
        if session_id is None:
            cookie_value = _new_calendar_session_cookie()
            session_id = _calendar_session_id(cookie_value)
        if session_id is None:  # Defensive: a freshly signed token must validate.
            raise CalendarConfigurationError("The calendar session could not be created.")
        authorization = create_google_authorization(force_consent=force_consent)
        cipher = CalendarTokenCipher.from_settings()
    except (CalendarConfigurationError, CalendarValidationError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    now = _utcnow()
    session.execute(delete(CalendarOAuthState).where(CalendarOAuthState.expires_at < now))
    session.execute(
        delete(CalendarOAuthState).where(CalendarOAuthState.session_key == session_id)
    )
    session.add(
        CalendarOAuthState(
            state=authorization.state,
            session_key=session_id,
            code_verifier=cipher.encrypt(authorization.code_verifier),
            return_path="/#startup/milestones",
            expires_at=now + _OAUTH_STATE_LIFETIME,
        )
    )
    session.commit()
    response = RedirectResponse(authorization.authorization_url, status_code=302)
    response.headers["Cache-Control"] = "private, no-store"
    response.set_cookie(
        _CALENDAR_COOKIE,
        cookie_value,
        max_age=_CALENDAR_COOKIE_MAX_AGE,
        httponly=True,
        secure=settings.calendar_cookie_secure,
        samesite="lax",
        path="/api/startup",
    )
    return response


def _calendar_callback_redirect(outcome: str) -> RedirectResponse:
    query = urlencode({"calendar": outcome})
    target = f"{settings.frontend_url.rstrip('/')}/#startup/milestones?{query}"
    return RedirectResponse(target, status_code=303, headers={"Cache-Control": "no-store"})


@router.get("/calendar/google/callback")
def google_calendar_callback(
    request: Request,
    state: Annotated[str | None, Query(max_length=512)] = None,
    code: Annotated[str | None, Query(max_length=4096)] = None,
    error: Annotated[str | None, Query(max_length=200)] = None,
    session: Session = Depends(get_session),
) -> Response:
    if not state:
        raise HTTPException(status_code=400, detail="The Google OAuth callback is incomplete.")
    oauth_state = session.get(CalendarOAuthState, state)
    session_id = _calendar_session_id(request.cookies.get(_CALENDAR_COOKIE))
    now = _utcnow()
    if oauth_state is None:
        raise HTTPException(status_code=400, detail="The Google OAuth state is invalid or expired.")
    if oauth_state.expires_at <= now:
        session.delete(oauth_state)
        session.commit()
        raise HTTPException(status_code=400, detail="The Google OAuth state is invalid or expired.")
    if (
        session_id is None
        or not secrets.compare_digest(oauth_state.session_key, session_id)
    ):
        # A request from another browser must not be able to consume a valid flow.
        raise HTTPException(status_code=400, detail="The Google OAuth state is invalid or expired.")

    encrypted_verifier = oauth_state.code_verifier
    consumed = session.execute(
        delete(CalendarOAuthState)
        .where(
            CalendarOAuthState.state == state,
            CalendarOAuthState.session_key == session_id,
            CalendarOAuthState.expires_at > now,
        )
        .execution_options(synchronize_session=False)
    )
    if consumed.rowcount != 1:
        session.rollback()
        raise HTTPException(status_code=400, detail="The Google OAuth state is invalid or expired.")
    session.commit()
    if error:
        return _calendar_callback_redirect("denied")
    if not code:
        raise HTTPException(status_code=400, detail="The Google OAuth callback is incomplete.")
    try:
        cipher = CalendarTokenCipher.from_settings()
        verifier = cipher.decrypt(encrypted_verifier)
        tokens = exchange_google_code(code, verifier)
    except (CalendarConfigurationError, CalendarValidationError, CalendarProviderError):
        logger.exception("Google OAuth callback failed")
        return _calendar_callback_redirect("error")

    granted_scopes = set(tokens.scope.split())
    if not set(GOOGLE_CALENDAR_SCOPES).issubset(granted_scopes):
        logger.warning("Google OAuth callback omitted the required calendar.events scope")
        return _calendar_callback_redirect("scope-error")

    connection = session.scalar(
        select(CalendarConnection).where(
            CalendarConnection.session_key == session_id,
            CalendarConnection.provider == "GOOGLE",
        )
    )
    encrypted_refresh = (
        cipher.encrypt(tokens.refresh_token) if tokens.refresh_token is not None else None
    )
    if connection is None:
        connection = CalendarConnection(
            id=f"CAL-{uuid4().hex[:16]}",
            session_key=session_id,
            provider="GOOGLE",
            encrypted_access_token=cipher.encrypt(tokens.access_token),
            encrypted_refresh_token=encrypted_refresh,
            token_expires_at=(
                tokens.expires_at.astimezone(UTC).replace(tzinfo=None)
                if tokens.expires_at
                else None
            ),
            granted_scope=tokens.scope,
            reauthorization_required=False,
        )
        session.add(connection)
    else:
        connection.encrypted_access_token = cipher.encrypt(tokens.access_token)
        if encrypted_refresh is not None:
            connection.encrypted_refresh_token = encrypted_refresh
        connection.token_expires_at = (
            tokens.expires_at.astimezone(UTC).replace(tzinfo=None)
            if tokens.expires_at
            else None
        )
        connection.granted_scope = tokens.scope
        connection.reauthorization_required = False
        connection.updated_at = _utcnow()
    session.commit()
    return _calendar_callback_redirect("connected")


def _calendar_access_token(connection: CalendarConnection, session: Session) -> str:
    def require_reauthorization(exc: Exception) -> NoReturn:
        connection.reauthorization_required = True
        connection.updated_at = _utcnow()
        session.commit()
        raise HTTPException(
            status_code=401,
            detail="Google Calendar authorization expired. Reconnect and retry.",
        ) from exc

    if not _calendar_scope_is_valid(connection):
        require_reauthorization(CalendarValidationError("Required scope is unavailable."))
    try:
        cipher = CalendarTokenCipher.from_settings()
        access_token = cipher.decrypt(connection.encrypted_access_token)
    except CalendarConfigurationError as exc:
        raise HTTPException(
            status_code=503,
            detail="Google Calendar token encryption is not configured.",
        ) from exc
    except CalendarValidationError as exc:
        require_reauthorization(exc)

    expiring = (
        connection.token_expires_at is not None
        and _aware_utc(connection.token_expires_at) <= datetime.now(UTC) + timedelta(minutes=1)
    )
    if not expiring:
        return access_token
    if not connection.encrypted_refresh_token:
        require_reauthorization(CalendarValidationError("A refresh token is unavailable."))
    try:
        refresh_token = cipher.decrypt(connection.encrypted_refresh_token)
        tokens = refresh_google_token(refresh_token)
    except CalendarValidationError as exc:
        require_reauthorization(exc)
    except CalendarProviderError as exc:
        if exc.code in {"invalid_grant", "invalid_token", "missing_scope"}:
            require_reauthorization(exc)
        raise HTTPException(
            status_code=502,
            detail="Google Calendar token refresh is temporarily unavailable. Retry shortly.",
        ) from exc

    connection.encrypted_access_token = cipher.encrypt(tokens.access_token)
    if tokens.refresh_token is not None:
        connection.encrypted_refresh_token = cipher.encrypt(tokens.refresh_token)
    connection.token_expires_at = (
        tokens.expires_at.astimezone(UTC).replace(tzinfo=None)
        if tokens.expires_at
        else None
    )
    connection.granted_scope = tokens.scope
    connection.reauthorization_required = False
    connection.updated_at = _utcnow()
    session.commit()
    return tokens.access_token.get_secret_value()


def _analysis_deadlines(analysis: StartupTenderAnalysis) -> list[dict]:
    if not isinstance(analysis.result_payload, dict):
        raise HTTPException(status_code=500, detail="Stored deadline data is invalid.")
    values = analysis.result_payload.get("deadlines", [])
    if not isinstance(values, list):
        raise HTTPException(status_code=500, detail="Stored deadline data is invalid.")
    result: list[dict] = []
    for value in values:
        if not isinstance(value, dict):
            raise HTTPException(status_code=500, detail="Stored deadline data is invalid.")
        item = dict(value)
        source = item.get("source")
        item["source"] = {
            **(source if isinstance(source, dict) else {}),
            "document": analysis.filename,
        }
        result.append(item)
    return result


def _stored_calendar_preference(
    row: CalendarDeadlinePreference,
) -> tuple[DeadlineSyncOverride | None, list[ReminderOverride] | None, list[str] | None]:
    """Validate preference JSON before it can influence an outbound provider call."""

    try:
        override = (
            DeadlineSyncOverride.model_validate(row.confirmed_override)
            if row.confirmed_override is not None
            else None
        )
        reminders = (
            CalendarDeadlineSettings(
                reminders=row.reminder_rules,
                attendees=[],
            ).reminders
            if row.reminder_rules is not None
            else None
        )
        attendees = (
            CalendarDeadlineSettings(
                reminders=[],
                attendees=row.attendees,
            ).attendees
            if row.attendees is not None
            else None
        )
    except (TypeError, ValidationError) as exc:
        raise HTTPException(
            status_code=500,
            detail="Stored calendar preferences are invalid. Disconnect and reconnect Calendar.",
        ) from exc
    if override is not None and override.deadline_id != row.deadline_id:
        raise HTTPException(status_code=500, detail="Stored calendar preferences are invalid.")
    return override, reminders, attendees


def _merge_deadline_override(
    stored: DeadlineSyncOverride | None,
    supplied: DeadlineSyncOverride | None,
) -> DeadlineSyncOverride | None:
    if stored is None:
        return supplied
    if supplied is None:
        return stored
    merged = stored.model_dump(mode="python")
    for field_name in supplied.model_fields_set:
        merged[field_name] = getattr(supplied, field_name)
    return DeadlineSyncOverride.model_validate(merged)


def _effective_calendar_inputs(
    payload: CalendarSyncRequest,
    preference_rows: list[CalendarDeadlinePreference],
) -> tuple[
    CalendarSyncRequest,
    dict[str, CalendarDeadlineSettings],
    dict[str, DeadlineSyncOverride | None],
]:
    """Merge omitted inputs with the last successful per-deadline sync state.

    ``model_fields_set`` is important here: an omitted array retains saved state,
    while an explicit ``[]`` removes reminders or attendees on the next PATCH.
    """

    stored_by_id = {row.deadline_id: row for row in preference_rows}
    supplied_by_id = {item.deadline_id: item for item in payload.deadline_overrides}
    global_reminders = payload.effective_reminders()
    global_reminders_explicit = (
        payload.reminders is not None or "reminder_minutes" in payload.model_fields_set
    )
    global_attendees_explicit = "attendees" in payload.model_fields_set
    effective_overrides: dict[str, DeadlineSyncOverride | None] = {}
    effective_settings: dict[str, CalendarDeadlineSettings] = {}

    for deadline_id in payload.deadline_ids:
        preference_row = stored_by_id.get(deadline_id)
        if preference_row is None:
            stored_override = None
            stored_reminders = None
            stored_attendees = None
        else:
            stored_override, stored_reminders, stored_attendees = _stored_calendar_preference(
                preference_row
            )
        supplied_override = supplied_by_id.get(deadline_id)
        merged_override = _merge_deadline_override(stored_override, supplied_override)
        effective_overrides[deadline_id] = merged_override

        per_deadline_reminders_explicit = bool(
            supplied_override
            and (
                "reminders" in supplied_override.model_fields_set
                or "reminder_minutes" in supplied_override.model_fields_set
            )
        )
        if per_deadline_reminders_explicit:
            if supplied_override.reminders is not None:
                effective_reminders = supplied_override.reminders
            elif supplied_override.reminder_minutes is not None:
                effective_reminders = [
                    ReminderOverride(method="popup", minutes=value)
                    for value in supplied_override.reminder_minutes
                ]
            else:
                effective_reminders = global_reminders
        elif global_reminders_explicit:
            effective_reminders = global_reminders
        elif stored_reminders is not None:
            effective_reminders = stored_reminders
        else:
            effective_reminders = global_reminders

        per_deadline_attendees_explicit = bool(
            supplied_override and "attendees" in supplied_override.model_fields_set
        )
        if per_deadline_attendees_explicit:
            effective_attendees = (
                supplied_override.attendees
                if supplied_override.attendees is not None
                else payload.attendees
            )
        elif global_attendees_explicit:
            effective_attendees = payload.attendees
        elif stored_attendees is not None:
            effective_attendees = stored_attendees
        else:
            effective_attendees = payload.attendees

        effective_settings[deadline_id] = CalendarDeadlineSettings(
            reminders=effective_reminders,
            attendees=effective_attendees,
        )

    merged_request = payload.model_copy(
        update={
            "deadline_overrides": [
                value for value in effective_overrides.values() if value is not None
            ]
        }
    )
    return merged_request, effective_settings, effective_overrides


@router.get(
    "/analyses/{analysis_id}/calendar/state",
    response_model=CalendarAnalysisStateResponse,
)
def calendar_analysis_state(
    analysis_id: str,
    request: Request,
    response: Response,
    calendar_id: Annotated[str, Query(min_length=1, max_length=1024)] = "primary",
    session: Session = Depends(get_session),
) -> CalendarAnalysisStateResponse:
    """Return only calendar state owned by the signed browser connection."""

    analysis = session.get(StartupTenderAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Tender analysis not found.")
    connection = _calendar_connection(request, session)
    if connection is None or _calendar_connection_needs_reauthorization(connection):
        raise HTTPException(status_code=401, detail="Connect Google Calendar to load sync state.")
    try:
        normalized_calendar_id = CalendarSyncRequest(
            deadline_ids=["calendar-state"],
            calendar_id=calendar_id,
        ).calendar_id
    except ValidationError as exc:
        raise HTTPException(status_code=422, detail="The calendar ID is invalid.") from exc

    preference_rows = session.scalars(
        select(CalendarDeadlinePreference).where(
            CalendarDeadlinePreference.connection_id == connection.id,
            CalendarDeadlinePreference.analysis_id == analysis.id,
            CalendarDeadlinePreference.calendar_id == normalized_calendar_id,
        )
    ).all()
    event_rows = session.scalars(
        select(CalendarEventSync).where(
            CalendarEventSync.connection_id == connection.id,
            CalendarEventSync.analysis_id == analysis.id,
            CalendarEventSync.calendar_id == normalized_calendar_id,
        )
    ).all()
    event_by_deadline = {row.deadline_id: row for row in event_rows}
    deadline_order = {
        str(item.get("id")): index
        for index, item in enumerate(_analysis_deadlines(analysis))
        if item.get("id") is not None
    }
    deadline_states = []
    for row in sorted(
        preference_rows,
        key=lambda value: deadline_order.get(value.deadline_id, len(deadline_order)),
    ):
        stored_override, stored_reminders, stored_attendees = _stored_calendar_preference(row)
        event_row = event_by_deadline.get(row.deadline_id)
        deadline_states.append(
            {
                "deadline_id": row.deadline_id,
                "calendar_id": row.calendar_id,
                "override": stored_override,
                "reminders": stored_reminders,
                "attendees": stored_attendees,
                "event_id": event_row.provider_event_id if event_row else None,
                "event_link": event_row.provider_event_link if event_row else None,
                "payload_hash": event_row.payload_hash if event_row else None,
                "status": event_row.status if event_row else None,
                "last_synced_at": event_row.last_synced_at if event_row else row.updated_at,
            }
        )
    response.headers["Cache-Control"] = "private, no-store"
    return CalendarAnalysisStateResponse(
        analysis_id=analysis.id,
        calendar_id=normalized_calendar_id,
        deadlines=deadline_states,
    )


@router.get("/analyses/{analysis_id}/calendar.ics")
def export_calendar_ics(
    analysis_id: str, session: Session = Depends(get_session)
) -> Response:
    analysis = session.get(StartupTenderAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Tender analysis not found.")
    deadlines = [
        item
        for item in _analysis_deadlines(analysis)
        if item.get("deadline_at") and not item.get("needs_review", True)
    ]
    if not deadlines:
        raise HTTPException(
            status_code=422,
            detail="No confirmed dated milestones are available for calendar export.",
        )
    try:
        content = build_ics_calendar(deadlines, analysis_id=analysis.id)
    except CalendarValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    stem = "".join(
        character if character.isascii() and (character.isalnum() or character in "-_") else "-"
        for character in Path(analysis.filename).stem
    ).strip("-")[:80] or "tender"
    return Response(
        content=content.encode("utf-8"),
        media_type="text/calendar; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{stem}-deadlines.ics"',
            "Cache-Control": "private, no-store",
        },
    )


@router.post(
    "/analyses/{analysis_id}/calendar/sync",
    response_model=CalendarSyncResponse,
)
def sync_calendar(
    analysis_id: str,
    payload: CalendarSyncRequest,
    request: Request,
    session: Session = Depends(get_session),
) -> CalendarSyncResponse:
    if not settings.google_calendar_configured:
        raise HTTPException(status_code=503, detail="Google Calendar OAuth is not configured.")
    analysis = session.get(StartupTenderAnalysis, analysis_id)
    if analysis is None:
        raise HTTPException(status_code=404, detail="Tender analysis not found.")
    connection = _calendar_connection(request, session)
    if connection is None or connection.reauthorization_required:
        raise HTTPException(status_code=401, detail="Connect Google Calendar before syncing.")
    access_token = _calendar_access_token(connection, session)
    existing_rows = session.scalars(
        select(CalendarEventSync).where(
            CalendarEventSync.connection_id == connection.id,
            CalendarEventSync.analysis_id == analysis.id,
            CalendarEventSync.calendar_id == payload.calendar_id,
        )
    ).all()
    preference_rows = session.scalars(
        select(CalendarDeadlinePreference).where(
            CalendarDeadlinePreference.connection_id == connection.id,
            CalendarDeadlinePreference.analysis_id == analysis.id,
            CalendarDeadlinePreference.calendar_id == payload.calendar_id,
        )
    ).all()
    effective_payload, effective_settings, effective_overrides = _effective_calendar_inputs(
        payload,
        list(preference_rows),
    )
    existing = [
        ExistingCalendarEvent(
            deadline_id=row.deadline_id,
            event_id=row.provider_event_id,
            event_link=row.provider_event_link,
            payload_hash=row.payload_hash,
        )
        for row in existing_rows
    ]
    try:
        result = sync_google_calendar_batch(
            _analysis_deadlines(analysis),
            effective_payload,
            analysis_id=analysis.id,
            access_token=access_token,
            existing_events=existing,
            deadline_settings=effective_settings,
        )
    except CalendarValidationError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except CalendarProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    existing_by_deadline = {row.deadline_id: row for row in existing_rows}
    preference_by_deadline = {row.deadline_id: row for row in preference_rows}
    for item in result.results:
        if item.status not in {"CREATED", "UPDATED", "UNCHANGED"}:
            continue
        if not item.event_id or not item.payload_hash:
            continue
        synced_at = _utcnow()
        event_row = existing_by_deadline.get(item.deadline_id)
        if event_row is None:
            event_row = CalendarEventSync(
                id=f"SYNC-{uuid4().hex[:16]}",
                connection_id=connection.id,
                analysis_id=analysis.id,
                deadline_id=item.deadline_id,
                calendar_id=payload.calendar_id,
                provider_event_id=item.event_id,
                provider_event_link=item.event_link,
                payload_hash=item.payload_hash,
                status=item.status,
                error_message=None,
                last_synced_at=synced_at,
            )
            session.add(event_row)
        else:
            event_row.provider_event_id = item.event_id
            event_row.provider_event_link = item.event_link
            event_row.payload_hash = item.payload_hash
            event_row.status = item.status
            event_row.error_message = None
            event_row.last_synced_at = synced_at

        deadline_settings = effective_settings.get(item.deadline_id)
        if deadline_settings is None:
            continue
        confirmed_override = effective_overrides.get(item.deadline_id)
        preference_row = preference_by_deadline.get(item.deadline_id)
        if preference_row is None:
            preference_row = CalendarDeadlinePreference(
                id=f"CALPREF-{uuid4().hex[:16]}",
                connection_id=connection.id,
                analysis_id=analysis.id,
                deadline_id=item.deadline_id,
                calendar_id=effective_payload.calendar_id,
                confirmed_override=None,
                reminder_rules=[],
                attendees=[],
                updated_at=synced_at,
            )
            session.add(preference_row)
        preference_row.confirmed_override = (
            confirmed_override.model_dump(
                mode="json",
                exclude={"reminder_minutes", "reminders", "attendees"},
            )
            if confirmed_override is not None and confirmed_override.confirmed
            else None
        )
        preference_row.reminder_rules = [
            reminder.model_dump(mode="json") for reminder in deadline_settings.reminders
        ]
        preference_row.attendees = list(deadline_settings.attendees)
        preference_row.updated_at = synced_at
    if any(item.status == "FAILED" and "HTTP 401" in (item.error or "") for item in result.results):
        connection.reauthorization_required = True
        connection.updated_at = _utcnow()
    session.commit()
    return result


@router.delete("/calendar/connection", status_code=status.HTTP_204_NO_CONTENT)
def disconnect_calendar(request: Request, session: Session = Depends(get_session)) -> Response:
    connection = _calendar_connection(request, session)
    if connection is not None:
        session.execute(
            delete(CalendarDeadlinePreference).where(
                CalendarDeadlinePreference.connection_id == connection.id
            )
        )
        session.execute(
            delete(CalendarEventSync).where(CalendarEventSync.connection_id == connection.id)
        )
        session.delete(connection)
        session.commit()
    response = Response(status_code=status.HTTP_204_NO_CONTENT)
    response.delete_cookie(_CALENDAR_COOKIE, path="/api/startup")
    return response
