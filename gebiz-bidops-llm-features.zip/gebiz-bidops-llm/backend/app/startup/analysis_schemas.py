"""Strict contracts used by the startup tender-analysis pipeline.

The public ``AnalysisResult`` mirrors the frontend contract.  The other models are
internal, but intentionally typed so model output and source provenance can be
validated before anything is shown to a user.
"""

import re
from datetime import date, datetime
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

type ObligationLevel = Literal["MANDATORY", "SCORED", "OPTIONAL", "UNCLEAR"]
type DeadlineKind = Literal[
    "CLARIFICATION",
    "SUBMISSION",
    "BID_BOND",
    "BRIEFING",
    "DELIVERY",
    "PAYMENT",
    "OTHER",
]
type Confidence = Literal["HIGH", "MEDIUM", "LOW"]
type ChecklistPriority = Literal["CRITICAL", "HIGH", "MEDIUM", "LOW"]
type FactKind = Literal[
    "OVERVIEW",
    "PRODUCT_FEATURE",
    "DELIVERY_PHASE",
    "PAYMENT",
    "DEADLINE",
    "ELIGIBILITY",
    "ACTION",
    "RISK",
    "JARGON",
]

_MAX_ITEM_SOURCES = 10

_MONTH_NUMBERS = {
    "jan": 1,
    "january": 1,
    "feb": 2,
    "february": 2,
    "mar": 3,
    "march": 3,
    "apr": 4,
    "april": 4,
    "may": 5,
    "jun": 6,
    "june": 6,
    "jul": 7,
    "july": 7,
    "aug": 8,
    "august": 8,
    "sep": 9,
    "sept": 9,
    "september": 9,
    "oct": 10,
    "october": 10,
    "nov": 11,
    "november": 11,
    "dec": 12,
    "december": 12,
}
_MONTH_PATTERN = "|".join(sorted(_MONTH_NUMBERS, key=len, reverse=True))
_WEEKDAY_NUMBERS = {
    "mon": 0,
    "monday": 0,
    "tue": 1,
    "tues": 1,
    "tuesday": 1,
    "wed": 2,
    "wednesday": 2,
    "thu": 3,
    "thur": 3,
    "thurs": 3,
    "thursday": 3,
    "fri": 4,
    "friday": 4,
    "sat": 5,
    "saturday": 5,
    "sun": 6,
    "sunday": 6,
}
_WEEKDAY_PATTERN = "|".join(sorted(_WEEKDAY_NUMBERS, key=len, reverse=True))


def _valid_timezone(value: str) -> str:
    candidate = value.strip()
    if not candidate or len(candidate) > 100:
        raise ValueError("timezone must be a non-empty IANA time-zone name")
    try:
        ZoneInfo(candidate)
    except (ValueError, ZoneInfoNotFoundError) as exc:
        raise ValueError("timezone must be a valid IANA time-zone name") from exc
    return candidate


def _optional_timezone(value: str | None) -> str | None:
    return _valid_timezone(value) if value is not None else None


def _aware_datetime(value: datetime | None) -> datetime | None:
    if value is not None and (value.tzinfo is None or value.utcoffset() is None):
        raise ValueError("date-time values must include a UTC offset")
    return value


def _calendar_dates_in_text(value: str) -> tuple[set[date], bool]:
    """Return explicit dates and whether a numeric date is order-ambiguous."""
    candidates: set[date] = set()
    ambiguous = False

    def add(year: int, month: int, day: int) -> None:
        try:
            candidates.add(date(year, month, day))
        except ValueError:
            return

    for match in re.finditer(r"(?<!\d)(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})(?!\d)", value):
        add(int(match.group(1)), int(match.group(2)), int(match.group(3)))
    for match in re.finditer(r"(?<!\d)(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2})(?!\d)", value):
        day, month, year = (int(match.group(index)) for index in (1, 2, 3))
        ambiguous = ambiguous or (day <= 12 and month <= 12 and day != month)
        add(year, month, day)
    for match in re.finditer(
        rf"(?<!\w)(\d{{1,2}})(?:st|nd|rd|th)?\s+({_MONTH_PATTERN})\.?[,]?\s+(20\d{{2}})(?!\d)",
        value,
        re.IGNORECASE,
    ):
        add(int(match.group(3)), _MONTH_NUMBERS[match.group(2).casefold()], int(match.group(1)))
    for match in re.finditer(
        rf"(?<!\w)({_MONTH_PATTERN})\.?\s+(\d{{1,2}})(?:st|nd|rd|th)?[,]?\s+(20\d{{2}})(?!\d)",
        value,
        re.IGNORECASE,
    ):
        add(int(match.group(3)), _MONTH_NUMBERS[match.group(1).casefold()], int(match.group(2)))
    return candidates, ambiguous


def _clock_times_in_text(value: str) -> set[tuple[int, int]]:
    candidates: set[tuple[int, int]] = set()
    for match in re.finditer(
        r"(?<!\d)(1[0-2]|0?[1-9])(?:[:.](\d{2}))?\s*([ap])\.?\s*m\.?(?!\w)",
        value,
        re.IGNORECASE,
    ):
        hour = int(match.group(1)) % 12
        if match.group(3).casefold() == "p":
            hour += 12
        minute = int(match.group(2) or 0)
        if minute < 60:
            candidates.add((hour, minute))
    for match in re.finditer(r"(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?!\d)", value):
        # A value such as ``5:00 PM`` was already parsed by the 12-hour pattern
        # above. Do not also treat its numeric prefix as a distinct 05:00 time.
        if re.match(r"\s*[ap]\.?\s*m\.?", value[match.end() :], re.IGNORECASE):
            continue
        candidates.add((int(match.group(1)), int(match.group(2))))
    compact_clock = r"(?<!\d)([01]\d|2[0-3])([0-5]\d)\s*(?:h|hrs?)(?!\w)"
    for match in re.finditer(compact_clock, value, re.IGNORECASE):
        candidates.add((int(match.group(1)), int(match.group(2))))
    if re.search(r"\bnoon\b", value, re.IGNORECASE):
        candidates.add((12, 0))
    if re.search(r"\bmidnight\b", value, re.IGNORECASE):
        candidates.add((0, 0))
    return candidates


def _weekdays_in_text(value: str) -> set[int]:
    return {
        _WEEKDAY_NUMBERS[match.group(1).casefold()]
        for match in re.finditer(
            rf"(?<!\w)({_WEEKDAY_PATTERN})\.?(?!\w)",
            value,
            re.IGNORECASE,
        )
    }


def _timezone_is_explicit(value: str, timezone: str, local: datetime) -> bool:
    folded = value.casefold()
    if timezone.casefold() in folded:
        return True
    if timezone == "Asia/Singapore" and re.search(
        r"\b(?:sgt|singapore\s+(?:standard\s+|local\s+)?time)\b", folded
    ):
        return True
    offset = local.utcoffset()
    offset_minutes = int(offset.total_seconds() // 60) if offset is not None else None
    for match in re.finditer(
        r"\b(?:utc|gmt)\s*([+-])\s*(\d{1,2})(?::?(\d{2}))?\b",
        folded,
    ):
        minutes = int(match.group(2)) * 60 + int(match.group(3) or 0)
        if match.group(1) == "-":
            minutes *= -1
        if minutes == offset_minutes:
            return True
    return bool(offset_minutes == 0 and re.search(r"\b(?:utc|gmt)\b", folded))


def _deadline_shape_is_safe(
    *,
    date_text: str,
    deadline_at: datetime | None,
    all_day: bool,
    timezone: str,
    confidence: Confidence,
    needs_review: bool,
) -> None:
    if deadline_at is None and not needs_review:
        raise ValueError("a deadline without deadline_at must require review")
    if confidence != "HIGH" and not needs_review:
        raise ValueError("medium- and low-confidence deadlines must require review")
    years = {int(value) for value in re.findall(r"(?<!\d)(20\d{2})(?!\d)", date_text)}
    local = deadline_at.astimezone(ZoneInfo(timezone)) if deadline_at else None
    local_year = local.year if local else None
    if local_year is not None and len(years) == 1 and local_year not in years:
        raise ValueError("deadline_at year must match the year in date_text")
    if local is None:
        return

    local_wall_time = local.replace(tzinfo=None)
    zone = ZoneInfo(timezone)
    fold_zero = local_wall_time.replace(tzinfo=zone, fold=0).utcoffset()
    fold_one = local_wall_time.replace(tzinfo=zone, fold=1).utcoffset()
    if not needs_review and fold_zero != fold_one:
        raise ValueError("a daylight-saving fold is ambiguous and must require review")

    calendar_dates, ambiguous_date = _calendar_dates_in_text(date_text)
    if calendar_dates and local.date() not in calendar_dates:
        raise ValueError("deadline_at date must match an explicit date in date_text")
    if not needs_review and not calendar_dates:
        raise ValueError("a deadline without a verifiable source date must require review")
    if not needs_review and (ambiguous_date or len(calendar_dates) != 1):
        raise ValueError("an ambiguous source date must require review")

    weekdays = _weekdays_in_text(date_text)
    if weekdays and local.weekday() not in weekdays:
        raise ValueError("deadline_at date must match the weekday in date_text")
    if not needs_review and len(weekdays) > 1:
        raise ValueError("multiple source weekdays must require review")

    clock_times = _clock_times_in_text(date_text)
    local_time = (local.hour, local.minute)
    if clock_times and local_time not in clock_times:
        raise ValueError("deadline_at time must match an explicit time in date_text")
    if all_day:
        if clock_times and not needs_review:
            raise ValueError("a source date with a clock time cannot be trusted as all-day")
        return
    if not needs_review and len(clock_times) > 1:
        raise ValueError("multiple source clock times must require review")
    if not needs_review and not clock_times:
        raise ValueError("a timed deadline without a verifiable source time must require review")
    if not needs_review and not _timezone_is_explicit(date_text, timezone, local):
        raise ValueError("a timed deadline without an explicit source timezone must require review")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SourceCitation(StrictModel):
    page: int | None = Field(default=None, ge=1)
    section: str | None = Field(default=None, max_length=500)
    snippet: str = Field(min_length=1, max_length=2_000)


class AnalysisOverview(StrictModel):
    tender_title: str | None = Field(default=None, max_length=500)
    agency: str | None = Field(default=None, max_length=500)
    reference_number: str | None = Field(default=None, max_length=200)
    summary: str = Field(min_length=1, max_length=8_000)
    buyer_goal: str = Field(min_length=1, max_length=4_000)


class ProductFeature(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    obligation_level: ObligationLevel
    acceptance_criteria: list[str] = Field(default_factory=list, max_length=100)
    source: SourceCitation
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class DeliveryPhase(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    sequence: int | None = Field(default=None, ge=1)
    name: str = Field(min_length=1, max_length=500)
    deliverables: list[str] = Field(default_factory=list, max_length=100)
    timing: str | None = Field(default=None, max_length=1_000)
    due_at: datetime | None = None
    timezone: str | None = Field(default=None, max_length=100)
    source: SourceCitation
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("due_at")
    @classmethod
    def due_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return _optional_timezone(value)

    @model_validator(mode="after")
    def due_at_has_timezone(self) -> "DeliveryPhase":
        if self.due_at is not None and self.timezone is None:
            raise ValueError("due_at requires an IANA timezone")
        return self


class PaymentMilestone(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    milestone: str = Field(min_length=1, max_length=500)
    trigger: str = Field(min_length=1, max_length=2_000)
    amount: str | None = Field(default=None, max_length=500)
    timing: str | None = Field(default=None, max_length=1_000)
    due_at: datetime | None = None
    timezone: str | None = Field(default=None, max_length=100)
    source: SourceCitation
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("due_at")
    @classmethod
    def due_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return _optional_timezone(value)

    @model_validator(mode="after")
    def due_at_has_timezone(self) -> "PaymentMilestone":
        if self.due_at is not None and self.timezone is None:
            raise ValueError("due_at requires an IANA timezone")
        return self


class Deadline(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    kind: DeadlineKind
    title: str = Field(min_length=1, max_length=500)
    date_text: str = Field(min_length=1, max_length=1_000)
    deadline_at: datetime | None = None
    all_day: bool
    timezone: str = Field(min_length=1, max_length=100)
    confidence: Confidence
    needs_review: bool
    source: SourceCitation

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str) -> str:
        return _valid_timezone(value)

    @field_validator("deadline_at")
    @classmethod
    def deadline_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @model_validator(mode="after")
    def unresolved_deadline_requires_review(self) -> "Deadline":
        _deadline_shape_is_safe(
            date_text=self.date_text,
            deadline_at=self.deadline_at,
            all_day=self.all_day,
            timezone=self.timezone,
            confidence=self.confidence,
            needs_review=self.needs_review,
        )
        return self


class EligibilityRequirement(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    obligation_level: ObligationLevel
    source: SourceCitation
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class StartupChecklistItem(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    title: str = Field(min_length=1, max_length=500)
    description: str = Field(min_length=1, max_length=4_000)
    category: str = Field(min_length=1, max_length=100)
    priority: ChecklistPriority
    due_at: datetime | None = None
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("due_at")
    @classmethod
    def due_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)


class Risk(StrictModel):
    id: str = Field(min_length=1, max_length=100)
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    mitigation: str | None = Field(default=None, max_length=4_000)
    source: SourceCitation
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class GlossaryTerm(StrictModel):
    term: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    source: SourceCitation
    sources: list[SourceCitation] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class AnalysisResult(StrictModel):
    overview: AnalysisOverview
    product_features: list[ProductFeature] = Field(default_factory=list, max_length=250)
    delivery_phases: list[DeliveryPhase] = Field(default_factory=list, max_length=250)
    payment_milestones: list[PaymentMilestone] = Field(default_factory=list, max_length=250)
    deadlines: list[Deadline] = Field(default_factory=list, max_length=250)
    eligibility_requirements: list[EligibilityRequirement] = Field(
        default_factory=list, max_length=250
    )
    startup_checklist: list[StartupChecklistItem] = Field(default_factory=list, max_length=500)
    risks: list[Risk] = Field(default_factory=list, max_length=250)
    clarification_questions: list[str] = Field(default_factory=list, max_length=250)
    glossary: list[GlossaryTerm] = Field(default_factory=list, max_length=250)
    warnings: list[str] = Field(default_factory=list, max_length=250)
    human_review_required: Literal[True] = True


class ExtractedBlock(StrictModel):
    block_id: str = Field(pattern=r"^BLOCK-[0-9]{5}$")
    page: int | None = Field(default=None, ge=1)
    section: str | None = Field(default=None, max_length=500)
    locator: str = Field(min_length=1, max_length=500)
    text: str = Field(min_length=1, max_length=100_000)


class ExtractedDocument(StrictModel):
    filename: str = Field(min_length=1, max_length=255)
    media_type: Literal[
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "text/plain",
        "text/markdown",
    ]
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    page_count: int | None = Field(default=None, ge=1)
    pages_with_text: int = Field(ge=0)
    scanned_pages: list[int] = Field(default_factory=list, max_length=750)
    character_count: int = Field(ge=1)
    blocks: list[ExtractedBlock] = Field(min_length=1)
    warnings: list[str] = Field(default_factory=list, max_length=250)

    @model_validator(mode="after")
    def extraction_counts_are_consistent(self) -> "ExtractedDocument":
        if self.character_count != sum(len(block.text) for block in self.blocks):
            raise ValueError("character_count must equal the extracted block text length")
        if self.page_count is None:
            if self.scanned_pages:
                raise ValueError("scanned_pages require a physical page_count")
        else:
            if self.pages_with_text > self.page_count:
                raise ValueError("pages_with_text cannot exceed page_count")
            if any(page > self.page_count for page in self.scanned_pages):
                raise ValueError("scanned_pages cannot exceed page_count")
        if len(self.scanned_pages) != len(set(self.scanned_pages)):
            raise ValueError("scanned_pages must not contain duplicates")
        return self


class DocumentChunk(StrictModel):
    chunk_id: str = Field(pattern=r"^CHUNK-[0-9]{4}$")
    blocks: list[ExtractedBlock] = Field(min_length=1)
    character_count: int = Field(ge=1)

    @model_validator(mode="after")
    def character_count_is_consistent(self) -> "DocumentChunk":
        expected = sum(len(block.text) for block in self.blocks) + 2 * (len(self.blocks) - 1)
        if self.character_count != expected:
            raise ValueError("character_count must equal the chunk block text length")
        return self


class FactSource(StrictModel):
    block_id: str = Field(pattern=r"^BLOCK-[0-9]{5}$")
    page: int | None = Field(default=None, ge=1)
    section: str | None = Field(default=None, max_length=500)
    snippet: str = Field(min_length=1, max_length=2_000)


class ChunkFact(StrictModel):
    kind: FactKind
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    obligation_level: ObligationLevel = "UNCLEAR"
    details: list[str] = Field(default_factory=list, max_length=100)
    sequence: int | None = Field(default=None, ge=1)
    timing: str | None = Field(default=None, max_length=1_000)
    date_text: str | None = Field(default=None, max_length=1_000)
    deadline_at: datetime | None = None
    deadline_kind: DeadlineKind | None = None
    all_day: bool | None = None
    timezone: str | None = Field(default=None, max_length=100)
    confidence: Confidence | None = None
    needs_review: bool = True
    amount: str | None = Field(default=None, max_length=500)
    trigger: str | None = Field(default=None, max_length=2_000)
    mitigation: str | None = Field(default=None, max_length=4_000)
    term: str | None = Field(default=None, max_length=500)
    source: FactSource

    @field_validator("deadline_at")
    @classmethod
    def deadline_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return _optional_timezone(value)

    @model_validator(mode="after")
    def kind_has_required_detail(self) -> "ChunkFact":
        if self.kind == "DEADLINE" and (
            not self.date_text
            or not self.deadline_kind
            or self.all_day is None
            or not self.timezone
            or not self.confidence
        ):
            raise ValueError(
                "DEADLINE facts require date_text, deadline_kind, all_day, timezone, and confidence"
            )
        if self.kind == "DEADLINE":
            _deadline_shape_is_safe(
                date_text=self.date_text or "",
                deadline_at=self.deadline_at,
                all_day=bool(self.all_day),
                timezone=self.timezone or "UTC",
                confidence=self.confidence or "LOW",
                needs_review=self.needs_review,
            )
        if self.kind == "JARGON" and not self.term:
            raise ValueError("JARGON facts require term")
        return self


class ChunkFactSet(StrictModel):
    facts: list[ChunkFact] = Field(default_factory=list, max_length=40)
    warnings: list[str] = Field(default_factory=list, max_length=20)


class GroundedFact(StrictModel):
    fact_id: str = Field(pattern=r"^FACT-[0-9A-F]{16}$")
    kind: FactKind
    title: str
    plain_english: str
    obligation_level: ObligationLevel
    details: list[str]
    sequence: int | None
    timing: str | None
    date_text: str | None
    deadline_at: datetime | None
    deadline_kind: DeadlineKind | None
    all_day: bool | None
    timezone: str | None
    confidence: Confidence | None
    needs_review: bool
    amount: str | None
    trigger: str | None
    mitigation: str | None
    term: str | None
    source: SourceCitation

    @field_validator("deadline_at")
    @classmethod
    def deadline_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return _optional_timezone(value)


class DraftOverview(StrictModel):
    tender_title: str | None = Field(default=None, max_length=500)
    agency: str | None = Field(default=None, max_length=500)
    reference_number: str | None = Field(default=None, max_length=200)
    summary: str = Field(min_length=1, max_length=8_000)
    buyer_goal: str = Field(min_length=1, max_length=4_000)
    supporting_fact_ids: list[str] = Field(default_factory=list, max_length=_MAX_ITEM_SOURCES)


class DraftProductFeature(StrictModel):
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    obligation_level: ObligationLevel
    acceptance_criteria: list[str] = Field(default_factory=list, max_length=100)
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class DraftDeliveryPhase(StrictModel):
    sequence: int | None = Field(default=None, ge=1)
    name: str = Field(min_length=1, max_length=500)
    deliverables: list[str] = Field(default_factory=list, max_length=100)
    timing: str | None = Field(default=None, max_length=1_000)
    due_at: datetime | None = None
    timezone: str | None = Field(default=None, max_length=100)
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("due_at")
    @classmethod
    def due_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return _optional_timezone(value)

    @model_validator(mode="after")
    def due_at_has_timezone(self) -> "DraftDeliveryPhase":
        if self.due_at is not None and self.timezone is None:
            raise ValueError("due_at requires an IANA timezone")
        return self


class DraftPaymentMilestone(StrictModel):
    milestone: str = Field(min_length=1, max_length=500)
    trigger: str = Field(min_length=1, max_length=2_000)
    amount: str | None = Field(default=None, max_length=500)
    timing: str | None = Field(default=None, max_length=1_000)
    due_at: datetime | None = None
    timezone: str | None = Field(default=None, max_length=100)
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("due_at")
    @classmethod
    def due_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return _optional_timezone(value)

    @model_validator(mode="after")
    def due_at_has_timezone(self) -> "DraftPaymentMilestone":
        if self.due_at is not None and self.timezone is None:
            raise ValueError("due_at requires an IANA timezone")
        return self


class DraftDeadline(StrictModel):
    kind: DeadlineKind
    title: str = Field(min_length=1, max_length=500)
    date_text: str = Field(min_length=1, max_length=1_000)
    deadline_at: datetime | None = None
    all_day: bool
    timezone: str = Field(min_length=1, max_length=100)
    confidence: Confidence
    needs_review: bool
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str) -> str:
        return _valid_timezone(value)

    @field_validator("deadline_at")
    @classmethod
    def deadline_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)

    @model_validator(mode="after")
    def unresolved_deadline_requires_review(self) -> "DraftDeadline":
        _deadline_shape_is_safe(
            date_text=self.date_text,
            deadline_at=self.deadline_at,
            all_day=self.all_day,
            timezone=self.timezone,
            confidence=self.confidence,
            needs_review=self.needs_review,
        )
        return self


class DraftEligibilityRequirement(StrictModel):
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    obligation_level: ObligationLevel
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class DraftChecklistItem(StrictModel):
    title: str = Field(min_length=1, max_length=500)
    description: str = Field(min_length=1, max_length=4_000)
    category: str = Field(min_length=1, max_length=100)
    priority: ChecklistPriority
    due_at: datetime | None = None
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)

    @field_validator("due_at")
    @classmethod
    def due_at_has_offset(cls, value: datetime | None) -> datetime | None:
        return _aware_datetime(value)


class DraftRisk(StrictModel):
    title: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    mitigation: str | None = Field(default=None, max_length=4_000)
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class DraftClarificationQuestion(StrictModel):
    question: str
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class DraftGlossaryTerm(StrictModel):
    term: str = Field(min_length=1, max_length=500)
    plain_english: str = Field(min_length=1, max_length=4_000)
    supporting_fact_ids: list[str] = Field(min_length=1, max_length=_MAX_ITEM_SOURCES)


class GroundedAnalysisDraft(StrictModel):
    overview: DraftOverview
    product_features: list[DraftProductFeature] = Field(default_factory=list, max_length=250)
    delivery_phases: list[DraftDeliveryPhase] = Field(default_factory=list, max_length=250)
    payment_milestones: list[DraftPaymentMilestone] = Field(
        default_factory=list, max_length=250
    )
    deadlines: list[DraftDeadline] = Field(default_factory=list, max_length=250)
    eligibility_requirements: list[DraftEligibilityRequirement] = Field(
        default_factory=list, max_length=250
    )
    startup_checklist: list[DraftChecklistItem] = Field(default_factory=list, max_length=500)
    risks: list[DraftRisk] = Field(default_factory=list, max_length=250)
    clarification_questions: list[DraftClarificationQuestion] = Field(
        default_factory=list, max_length=250
    )
    glossary: list[DraftGlossaryTerm] = Field(default_factory=list, max_length=250)
    warnings: list[str] = Field(default_factory=list, max_length=250)


class DocumentMetrics(StrictModel):
    filename: str
    media_type: str
    sha256: str
    page_count: int | None
    pages_with_text: int
    scanned_pages: list[int]
    block_count: int
    character_count: int
    chunks_total: int
    chunks_analysed: int


class ProviderMetrics(StrictModel):
    mode: str
    model_id: str
    calls: int = Field(ge=1)
    attempts: int = Field(ge=1)
    duration_ms: float = Field(ge=0)
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    total_tokens: int | None = Field(default=None, ge=0)


class TenderAnalysisEnvelope(StrictModel):
    result: AnalysisResult
    document: DocumentMetrics
    provider: ProviderMetrics
