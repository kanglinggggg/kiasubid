"""AI-assisted startup tender preparation capabilities."""
