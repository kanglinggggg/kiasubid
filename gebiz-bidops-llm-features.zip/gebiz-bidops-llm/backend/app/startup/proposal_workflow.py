"""Persistent, deterministic state transitions around the B2 language-model calls."""

import json
from datetime import UTC, datetime
from typing import Any

from app.models import StartupProposalSession, StartupTenderAnalysis
from app.startup.proposal import ProposalBuilder
from app.startup.proposal_schemas import ProposalAnswer, ProposalQuestion

CONTEXT_REDUCTION_NOTICE = (
    "The mentor received a reduced B1 context because item or input limits were reached. "
    "Review the full B1 analysis alongside every question and the generated draft."
)


class ProposalWorkflowConflict(ValueError):
    pass


def _compact_text(value: Any, limit: int = 1_500) -> Any:
    if isinstance(value, str):
        return value[:limit]
    if isinstance(value, list):
        return [_compact_text(item, limit) for item in value]
    if isinstance(value, dict):
        return {key: _compact_text(item, limit) for key, item in value.items()}
    return value


def proposal_context(analysis: StartupTenderAnalysis) -> dict[str, Any]:
    """Create a bounded context while preserving every identifier used for grounding."""
    source = analysis.result_payload
    context: dict[str, Any] = {
        "analysis_id": analysis.id,
        "document": {"filename": analysis.filename},
        "overview": source.get("overview", {}),
    }
    limits = {
        "product_features": 80,
        "delivery_phases": 80,
        "payment_milestones": 80,
        "deadlines": 80,
        "eligibility_requirements": 80,
        "startup_checklist": 100,
        "risks": 80,
    }
    for key, limit in limits.items():
        items = source.get(key, [])
        if not isinstance(items, list):
            items = []
        compact_items = []
        for item in items[:limit]:
            if not isinstance(item, dict):
                continue
            compact_item = {
                name: value for name, value in item.items() if name not in {"source", "sources"}
            }
            compact_items.append(_compact_text(compact_item))
        context[key] = compact_items
        context[f"{key}_total"] = len(items)

    def encoded_size() -> int:
        return len(json.dumps(context, ensure_ascii=False, separators=(",", ":")))

    if any(context[f"{key}_total"] > len(context[key]) for key in limits):
        context["context_notice"] = CONTEXT_REDUCTION_NOTICE
    if encoded_size() > 140_000:
        context["context_notice"] = CONTEXT_REDUCTION_NOTICE
        ordered_keys = list(limits)
        while encoded_size() > 140_000 and any(context[key] for key in ordered_keys):
            largest_key = max(
                (key for key in ordered_keys if context[key]),
                key=lambda key: len(json.dumps(context[key][-1], ensure_ascii=False)),
            )
            context[largest_key].pop()
        if encoded_size() > 140_000:
            context["overview"] = _compact_text(context["overview"], 500)
    return context


def create_proposal_session(
    *,
    analysis: StartupTenderAnalysis,
    company_name: str,
    solution_name: str,
    builder: ProposalBuilder,
    session_id: str,
) -> StartupProposalSession:
    context = proposal_context(analysis)
    context["supplier"] = {"company_name": company_name, "solution_name": solution_name}
    plan = builder.create_question_plan(context)
    timestamp = datetime.now(UTC).replace(tzinfo=None)
    return StartupProposalSession(
        id=session_id,
        analysis_id=analysis.id,
        company_name=company_name,
        solution_name=solution_name,
        status="IN_PROGRESS",
        revision=0,
        current_index=0,
        questions=[item.model_dump(mode="json") for item in plan.result.questions],
        answers=[],
        last_feedback=None,
        draft=None,
        provider_mode=plan.mode,
        model_id=plan.model_id,
        created_at=timestamp,
        updated_at=timestamp,
    )


def answer_current_question(
    *,
    proposal_session: StartupProposalSession,
    analysis: StartupTenderAnalysis,
    question_id: str,
    raw_answer: str,
    expected_revision: int,
    builder: ProposalBuilder,
) -> None:
    if proposal_session.status == "GENERATED":
        raise ProposalWorkflowConflict("The generated proposal session is read-only.")
    if expected_revision != proposal_session.revision:
        previous = proposal_session.answers[-1] if proposal_session.answers else None
        if (
            expected_revision == proposal_session.revision - 1
            and previous
            and previous.get("question_id") == question_id
            and previous.get("raw_answer") == raw_answer.strip()
        ):
            return
        raise ProposalWorkflowConflict(
            "This proposal session changed in another request. Reload it before continuing."
        )
    if proposal_session.current_index >= len(proposal_session.questions):
        raise ProposalWorkflowConflict("All proposal questions have already been answered.")
    question = ProposalQuestion.model_validate(
        proposal_session.questions[proposal_session.current_index]
    )
    if question.id != question_id:
        raise ProposalWorkflowConflict(
            "The submitted question is not the current question. Reload the session."
        )

    context = proposal_context(analysis)
    context["supplier"] = {
        "company_name": proposal_session.company_name,
        "solution_name": proposal_session.solution_name,
    }
    prior_answers = [ProposalAnswer.model_validate(item) for item in proposal_session.answers]
    critique = builder.critique_answer(context, question, raw_answer, prior_answers)
    answer = ProposalAnswer(
        question_id=question.id,
        section=question.section,
        question=question.question,
        raw_answer=raw_answer.strip(),
        formalized_answer=critique.result.formalized_answer,
        context_refs=critique.result.context_refs,
    )
    answers = [*proposal_session.answers, answer.model_dump(mode="json")]
    questions = list(proposal_session.questions)
    is_follow_up = question.id.endswith("-followup")
    if critique.result.needs_follow_up and not is_follow_up:
        follow_up_id = f"{question.id}-followup"
        if len(follow_up_id) > 64:
            follow_up_id = f"F{proposal_session.current_index + 1:02d}-followup"
        existing_ids = {str(item.get("id")) for item in questions}
        suffix = 1
        while follow_up_id in existing_ids:
            suffix += 1
            follow_up_id = f"F{proposal_session.current_index + 1:02d}-{suffix}-followup"
            if len(follow_up_id) > 64:
                follow_up_id = f"F{suffix}-followup"
        follow_up = ProposalQuestion(
            id=follow_up_id,
            section=question.section,
            question=critique.result.follow_up_question or "Please add the missing detail.",
            why_it_matters="This detail is needed to make the response specific and verifiable.",
            answer_guidance=["State only facts the team can verify."],
            required=False,
            context_refs=critique.result.context_refs,
        )
        questions.insert(proposal_session.current_index + 1, follow_up.model_dump(mode="json"))

    proposal_session.answers = answers
    proposal_session.questions = questions
    proposal_session.current_index += 1
    proposal_session.revision += 1
    proposal_session.last_feedback = critique.result.model_dump(mode="json")
    proposal_session.provider_mode = critique.mode
    proposal_session.model_id = critique.model_id
    proposal_session.status = (
        "READY"
        if proposal_session.current_index >= len(proposal_session.questions)
        else "IN_PROGRESS"
    )
    proposal_session.updated_at = datetime.now(UTC).replace(tzinfo=None)


def generate_proposal_draft(
    *,
    proposal_session: StartupProposalSession,
    analysis: StartupTenderAnalysis,
    expected_revision: int,
    builder: ProposalBuilder,
) -> None:
    if proposal_session.status == "GENERATED" and expected_revision in {
        proposal_session.revision,
        proposal_session.revision - 1,
    }:
        return
    if expected_revision != proposal_session.revision:
        raise ProposalWorkflowConflict(
            "This proposal session changed in another request. Reload it before generating."
        )
    if proposal_session.status != "READY":
        remaining = len(proposal_session.questions) - proposal_session.current_index
        raise ProposalWorkflowConflict(
            f"Answer the remaining {remaining} proposal question(s) before generating the draft."
        )
    context = proposal_context(analysis)
    context["supplier"] = {
        "company_name": proposal_session.company_name,
        "solution_name": proposal_session.solution_name,
    }
    answers = [ProposalAnswer.model_validate(item) for item in proposal_session.answers]
    draft = builder.generate_draft(context, answers)
    proposal_session.draft = draft.result.model_dump(mode="json")
    proposal_session.provider_mode = draft.mode
    proposal_session.model_id = draft.model_id
    proposal_session.status = "GENERATED"
    proposal_session.revision += 1
    proposal_session.updated_at = datetime.now(UTC).replace(tzinfo=None)
