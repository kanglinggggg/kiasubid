"""Safe, page/block-preserving extraction for uploaded tender documents."""

import hashlib
import io
import re
import unicodedata
import zipfile
from collections.abc import Iterable
from pathlib import Path
from xml.etree import ElementTree

from app.config import Settings, settings
from app.startup.analysis_schemas import DocumentChunk, ExtractedBlock, ExtractedDocument

PDF_MEDIA_TYPE = "application/pdf"
DOCX_MEDIA_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
)
TEXT_MEDIA_TYPE = "text/plain"
MARKDOWN_MEDIA_TYPE = "text/markdown"

_EXTENSION_MEDIA_TYPES = {
    ".pdf": PDF_MEDIA_TYPE,
    ".docx": DOCX_MEDIA_TYPE,
    ".txt": TEXT_MEDIA_TYPE,
    ".md": MARKDOWN_MEDIA_TYPE,
    ".markdown": MARKDOWN_MEDIA_TYPE,
}
_WORD_NAMESPACE = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_W = f"{{{_WORD_NAMESPACE}}}"
_DOCX_MEMBER_LIMIT = 10_000
_DOCX_UNCOMPRESSED_LIMIT = 256 * 1024 * 1024
_DOCX_COMPRESSION_RATIO_LIMIT = 1_000
_BASE_BLOCK_CHARACTERS = 80_000


class DocumentIngestionError(ValueError):
    """An upload could not be safely or faithfully converted to text."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def _safe_filename(filename: str) -> str:
    leaf = Path(filename.replace("\\", "/")).name
    clean = "".join(
        character
        for character in leaf
        if not unicodedata.category(character).startswith("C")
    )
    clean = clean.strip().strip(".")
    if not clean:
        raise DocumentIngestionError("INVALID_FILENAME", "The uploaded filename is empty.")
    return clean[:255]


def _canonical_text(value: str) -> str:
    value = value.replace("\r\n", "\n").replace("\r", "\n")
    value = value.replace("\u00a0", " ").replace("\x00", "")
    lines = [re.sub(r"[\t ]+", " ", line).strip() for line in value.split("\n")]
    return "\n".join(lines).strip()


def _decode_text(content: bytes) -> str:
    if content.startswith((b"\xff\xfe", b"\xfe\xff")):
        encoding = "utf-16"
    else:
        encoding = "utf-8-sig"
        if b"\x00" in content:
            raise DocumentIngestionError(
                "BINARY_TEXT_FILE", "The uploaded text file contains binary data."
            )
    try:
        return content.decode(encoding)
    except UnicodeDecodeError as exc:
        raise DocumentIngestionError(
            "UNSUPPORTED_TEXT_ENCODING", "Text and Markdown uploads must use UTF-8 or UTF-16."
        ) from exc


def _looks_like_pdf(content: bytes) -> bool:
    return b"%PDF-" in content[:1_024]


def _validate_docx_archive(content: bytes) -> zipfile.ZipFile:
    try:
        archive = zipfile.ZipFile(io.BytesIO(content))
        members = archive.infolist()
    except (OSError, zipfile.BadZipFile) as exc:
        raise DocumentIngestionError("CORRUPT_DOCX", "The DOCX archive is corrupt.") from exc

    if (
        "[Content_Types].xml" not in archive.namelist()
        or "word/document.xml" not in archive.namelist()
    ):
        archive.close()
        raise DocumentIngestionError(
            "INVALID_DOCX", "The upload is a ZIP file, but not a valid DOCX document."
        )
    if len(members) > _DOCX_MEMBER_LIMIT:
        archive.close()
        raise DocumentIngestionError("DOCX_ARCHIVE_LIMIT", "The DOCX contains too many files.")

    total_size = 0
    total_compressed = 0
    for member in members:
        parts = Path(member.filename.replace("\\", "/")).parts
        if member.filename.startswith(("/", "\\")) or ".." in parts:
            archive.close()
            raise DocumentIngestionError(
                "UNSAFE_DOCX_PATH", "The DOCX contains an unsafe archive path."
            )
        total_size += member.file_size
        total_compressed += member.compress_size
        if total_size > _DOCX_UNCOMPRESSED_LIMIT:
            archive.close()
            raise DocumentIngestionError(
                "DOCX_ARCHIVE_LIMIT", "The expanded DOCX is larger than the safe limit."
            )
    ratio = total_size / max(total_compressed, 1)
    if total_size > 1_000_000 and ratio > _DOCX_COMPRESSION_RATIO_LIMIT:
        archive.close()
        raise DocumentIngestionError(
            "DOCX_ARCHIVE_LIMIT", "The DOCX compression ratio exceeds the safe limit."
        )
    return archive


def _detect_media_type(extension: str, content: bytes) -> str:
    if _looks_like_pdf(content):
        detected = PDF_MEDIA_TYPE
    elif zipfile.is_zipfile(io.BytesIO(content)):
        archive = _validate_docx_archive(content)
        archive.close()
        detected = DOCX_MEDIA_TYPE
    else:
        _decode_text(content)
        detected = MARKDOWN_MEDIA_TYPE if extension in {".md", ".markdown"} else TEXT_MEDIA_TYPE

    expected = _EXTENSION_MEDIA_TYPES[extension]
    text_types = {TEXT_MEDIA_TYPE, MARKDOWN_MEDIA_TYPE}
    if detected != expected and not ({detected, expected} <= text_types):
        raise DocumentIngestionError(
            "FILE_TYPE_MISMATCH",
            f"The file contents do not match the {extension} filename extension.",
        )
    return expected


def _split_text(value: str, limit: int) -> list[str]:
    remaining = value.strip()
    parts: list[str] = []
    while len(remaining) > limit:
        boundary = max(
            remaining.rfind("\n", limit // 2, limit),
            remaining.rfind(". ", limit // 2, limit),
            remaining.rfind("; ", limit // 2, limit),
        )
        if boundary < limit // 2:
            boundary = limit
        elif remaining[boundary : boundary + 2] in {". ", "; "}:
            boundary += 1
        parts.append(remaining[:boundary].strip())
        remaining = remaining[boundary:].strip()
    if remaining:
        parts.append(remaining)
    return parts


def _make_blocks(
    raw_blocks: Iterable[tuple[int | None, str | None, str, str]],
) -> list[ExtractedBlock]:
    result: list[ExtractedBlock] = []
    for page, section, locator, raw_text in raw_blocks:
        text = _canonical_text(raw_text)
        if not text:
            continue
        parts = _split_text(text, _BASE_BLOCK_CHARACTERS)
        for part_index, part in enumerate(parts, 1):
            part_locator = f"{locator}, part {part_index}" if len(parts) > 1 else locator
            result.append(
                ExtractedBlock(
                    block_id=f"BLOCK-{len(result) + 1:05d}",
                    page=page,
                    section=section,
                    locator=part_locator,
                    text=part,
                )
            )
    return result


def _extract_pdf(
    content: bytes, *, max_pages: int, max_characters: int
) -> tuple[list[ExtractedBlock], int, int, list[int], list[str]]:
    try:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(content), strict=False)
        if reader.is_encrypted and reader.decrypt("") == 0:
            raise DocumentIngestionError(
                "ENCRYPTED_PDF", "Password-protected PDF files are not supported."
            )
        page_count = len(reader.pages)
    except DocumentIngestionError:
        raise
    except Exception as exc:
        raise DocumentIngestionError("CORRUPT_PDF", "The PDF could not be read.") from exc

    if page_count == 0:
        raise DocumentIngestionError("EMPTY_DOCUMENT", "The PDF contains no pages.")
    if page_count > max_pages:
        raise DocumentIngestionError(
            "PAGE_LIMIT_EXCEEDED",
            f"The PDF has {page_count} pages; the limit is {max_pages}.",
        )

    raw_blocks: list[tuple[int | None, str | None, str, str]] = []
    pages_with_text = 0
    character_count = 0
    empty_pages: list[int] = []
    for index, page in enumerate(reader.pages, 1):
        try:
            text = _canonical_text(page.extract_text() or "")
        except Exception as exc:
            raise DocumentIngestionError(
                "PDF_EXTRACTION_FAILED", f"Text extraction failed on PDF page {index}."
            ) from exc
        if not text:
            empty_pages.append(index)
            continue
        pages_with_text += 1
        character_count += len(text)
        if character_count > max_characters:
            raise DocumentIngestionError(
                "CHARACTER_LIMIT_EXCEEDED",
                f"Extracted text exceeds the {max_characters:,}-character limit.",
            )
        raw_blocks.append((index, f"Page {index}", f"Page {index}", text))

    if not raw_blocks or character_count < max(40, page_count * 4):
        raise DocumentIngestionError(
            "OCR_REQUIRED",
            "The PDF contains too little machine-readable text and likely requires OCR.",
        )
    warnings: list[str] = []
    if empty_pages:
        preview = ", ".join(str(page) for page in empty_pages[:12])
        remainder = "…" if len(empty_pages) > 12 else ""
        warnings.append(
            f"No machine-readable text was found on page(s) {preview}{remainder}; "
            "review them manually."
        )
    return _make_blocks(raw_blocks), page_count, pages_with_text, empty_pages, warnings


def _docx_style_names(archive: zipfile.ZipFile) -> dict[str, str]:
    if "word/styles.xml" not in archive.namelist():
        return {}
    try:
        root = ElementTree.fromstring(archive.read("word/styles.xml"))
    except ElementTree.ParseError:
        return {}
    styles: dict[str, str] = {}
    for style in root.iter(f"{_W}style"):
        style_id = style.get(f"{_W}styleId")
        name_node = style.find(f"{_W}name")
        name = name_node.get(f"{_W}val") if name_node is not None else None
        if style_id and name:
            styles[style_id] = name
    return styles


def _xml_text(element: ElementTree.Element) -> str:
    pieces: list[str] = []
    for node in element.iter():
        if node.tag == f"{_W}t" and node.text:
            pieces.append(node.text)
        elif node.tag == f"{_W}tab":
            pieces.append("\t")
        elif node.tag in {f"{_W}br", f"{_W}cr"}:
            pieces.append("\n")
    return "".join(pieces)


def _paragraph_style(element: ElementTree.Element, styles: dict[str, str]) -> str | None:
    properties = element.find(f"{_W}pPr")
    style = properties.find(f"{_W}pStyle") if properties is not None else None
    style_id = style.get(f"{_W}val") if style is not None else None
    return styles.get(style_id, style_id) if style_id else None


def _extract_docx(
    content: bytes, *, max_characters: int
) -> tuple[list[ExtractedBlock], None, int, list[int], list[str]]:
    archive = _validate_docx_archive(content)
    try:
        styles = _docx_style_names(archive)
        root = ElementTree.fromstring(archive.read("word/document.xml"))
    except (KeyError, ElementTree.ParseError) as exc:
        archive.close()
        raise DocumentIngestionError("CORRUPT_DOCX", "The DOCX XML is corrupt.") from exc
    finally:
        archive.close()

    body = root.find(f"{_W}body")
    if body is None:
        raise DocumentIngestionError("CORRUPT_DOCX", "The DOCX has no document body.")

    raw_blocks: list[tuple[int | None, str | None, str, str]] = []
    current_section: str | None = None
    paragraph_number = 0
    table_number = 0
    character_count = 0
    for child in body:
        if child.tag == f"{_W}p":
            paragraph_number += 1
            text = _canonical_text(_xml_text(child))
            if not text:
                continue
            style_name = (_paragraph_style(child, styles) or "").casefold()
            if style_name.startswith("heading") or style_name.startswith("title"):
                current_section = text[:500]
            locator = f"Paragraph {paragraph_number}"
            raw_blocks.append((None, current_section, locator, text))
            character_count += len(text)
        elif child.tag == f"{_W}tbl":
            table_number += 1
            for row_number, row in enumerate(child.findall(f"{_W}tr"), 1):
                cells = [
                    _canonical_text(_xml_text(cell)) for cell in row.findall(f"{_W}tc")
                ]
                text = " | ".join(cell for cell in cells if cell)
                if not text:
                    continue
                locator = f"Table {table_number}, row {row_number}"
                raw_blocks.append((None, current_section, locator, text))
                character_count += len(text)
        if character_count > max_characters:
            raise DocumentIngestionError(
                "CHARACTER_LIMIT_EXCEEDED",
                f"Extracted text exceeds the {max_characters:,}-character limit.",
            )
    blocks = _make_blocks(raw_blocks)
    if not blocks:
        raise DocumentIngestionError("EMPTY_DOCUMENT", "The DOCX contains no readable text.")
    warnings = [
        "DOCX page numbers are not stored reliably; citations use headings and block locations."
    ]
    return blocks, None, 1, [], warnings


def _extract_text_document(
    content: bytes, *, markdown: bool, max_characters: int
) -> tuple[list[ExtractedBlock], None, int, list[int], list[str]]:
    text = _canonical_text(_decode_text(content))
    if not text:
        raise DocumentIngestionError("EMPTY_DOCUMENT", "The document contains no readable text.")
    if len(text) > max_characters:
        raise DocumentIngestionError(
            "CHARACTER_LIMIT_EXCEEDED",
            f"Extracted text exceeds the {max_characters:,}-character limit.",
        )

    raw_blocks: list[tuple[int | None, str | None, str, str]] = []
    current_section: str | None = None
    parts = [part for part in re.split(r"\n\s*\n", text) if part.strip()]
    for index, part in enumerate(parts, 1):
        clean = _canonical_text(part)
        if markdown:
            first_line = clean.splitlines()[0]
            heading = re.match(r"^#{1,6}\s+(.+)$", first_line)
            if heading:
                current_section = heading.group(1).strip()[:500]
        raw_blocks.append((None, current_section, f"Block {index}", clean))
    return _make_blocks(raw_blocks), None, 1, [], []


class DocumentIngestor:
    def __init__(self, app_settings: Settings = settings):
        self._settings = app_settings

    def ingest(self, *, filename: str, content: bytes) -> ExtractedDocument:
        safe_name = _safe_filename(filename)
        extension = Path(safe_name).suffix.casefold()
        if extension not in _EXTENSION_MEDIA_TYPES:
            raise DocumentIngestionError(
                "UNSUPPORTED_FILE_TYPE", "Supported file types are PDF, DOCX, TXT, and Markdown."
            )
        if not content:
            raise DocumentIngestionError("EMPTY_UPLOAD", "The uploaded file is empty.")

        max_bytes = int(getattr(self._settings, "startup_upload_max_bytes", 30 * 1024 * 1024))
        max_pages = int(getattr(self._settings, "startup_analysis_max_pages", 750))
        max_characters = int(
            getattr(self._settings, "startup_analysis_max_characters", 3_000_000)
        )
        if len(content) > max_bytes:
            raise DocumentIngestionError(
                "UPLOAD_TOO_LARGE", f"The upload exceeds the {max_bytes:,}-byte limit."
            )
        media_type = _detect_media_type(extension, content)

        if media_type == PDF_MEDIA_TYPE:
            blocks, page_count, pages_with_text, scanned_pages, warnings = _extract_pdf(
                content, max_pages=max_pages, max_characters=max_characters
            )
        elif media_type == DOCX_MEDIA_TYPE:
            blocks, page_count, pages_with_text, scanned_pages, warnings = _extract_docx(
                content, max_characters=max_characters
            )
        else:
            blocks, page_count, pages_with_text, scanned_pages, warnings = _extract_text_document(
                content,
                markdown=media_type == MARKDOWN_MEDIA_TYPE,
                max_characters=max_characters,
            )

        character_count = sum(len(block.text) for block in blocks)
        return ExtractedDocument(
            filename=safe_name,
            media_type=media_type,
            sha256=hashlib.sha256(content).hexdigest(),
            page_count=page_count,
            pages_with_text=pages_with_text,
            scanned_pages=scanned_pages,
            character_count=character_count,
            blocks=blocks,
            warnings=warnings,
        )


def chunk_document(
    document: ExtractedDocument, *, max_characters: int, max_chunks: int = 1_000
) -> list[DocumentChunk]:
    """Create bounded chunks without losing source block/page identity."""
    if max_characters < 1_000:
        raise ValueError("max_characters must be at least 1,000")
    if max_chunks < 1:
        raise ValueError("max_chunks must be positive")

    split_blocks: list[ExtractedBlock] = []
    for block in document.blocks:
        parts = _split_text(block.text, max_characters)
        if len(parts) == 1:
            split_blocks.append(block)
            continue
        for index, part in enumerate(parts, 1):
            split_blocks.append(
                block.model_copy(
                    update={
                        "locator": f"{block.locator}, chunk part {index}",
                        "text": part,
                    }
                )
            )
    bounded_blocks = [
        block.model_copy(update={"block_id": f"BLOCK-{index:05d}"})
        for index, block in enumerate(split_blocks, 1)
    ]

    chunks: list[DocumentChunk] = []
    current: list[ExtractedBlock] = []
    current_characters = 0
    for block in bounded_blocks:
        separator_size = 2 if current else 0
        if current and current_characters + separator_size + len(block.text) > max_characters:
            chunks.append(
                DocumentChunk(
                    chunk_id=f"CHUNK-{len(chunks) + 1:04d}",
                    blocks=current,
                    character_count=current_characters,
                )
            )
            current = []
            current_characters = 0
        if current:
            current_characters += 2
        current.append(block)
        current_characters += len(block.text)
    if current:
        chunks.append(
            DocumentChunk(
                chunk_id=f"CHUNK-{len(chunks) + 1:04d}",
                blocks=current,
                character_count=current_characters,
            )
        )
    if len(chunks) > max_chunks:
        raise DocumentIngestionError(
            "CHUNK_LIMIT_EXCEEDED",
            f"The extracted document requires {len(chunks)} chunks; the limit is {max_chunks}.",
        )
    return chunks
