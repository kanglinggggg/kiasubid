from datetime import datetime
from typing import Literal
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator

DEFAULT_REMINDER_MINUTES = [10_080, 1_440, 120]
MAX_REMINDER_MINUTES = 40_320

DeadlineKind = Literal[
    "CLARIFICATION",
    "SUBMISSION",
    "BID_BOND",
    "BRIEFING",
    "DELIVERY",
    "PAYMENT",
    "OTHER",
]
DeadlineConfidence = Literal["HIGH", "MEDIUM", "LOW"]
ReminderMethod = Literal["popup", "email"]
CalendarSyncItemStatus = Literal["CREATED", "UPDATED", "UNCHANGED", "FAILED", "SKIPPED"]
CalendarSyncStatus = Literal["COMPLETE", "PARTIAL", "FAILED"]


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


def validate_timezone(value: str) -> str:
    candidate = value.strip()
    if not candidate or len(candidate) > 100:
        raise ValueError("timezone must be a non-empty IANA time-zone name")
    try:
        ZoneInfo(candidate)
    except (ValueError, ZoneInfoNotFoundError) as exc:
        raise ValueError("timezone must be a valid IANA time-zone name") from exc
    return candidate


def normalize_deadline_kind(value: str) -> str:
    candidate = str(value).strip().upper()
    aliases = {
        "CLARIFICATION_DEADLINE": "CLARIFICATION",
        "TENDER_SUBMISSION": "SUBMISSION",
        "SUBMISSION_DEADLINE": "SUBMISSION",
        "BID_BOND_DEADLINE": "BID_BOND",
        "DOCUMENT_SUBMISSION": "SUBMISSION",
        "DELIVERY_MILESTONE": "DELIVERY",
        "MILESTONE": "DELIVERY",
        "PAYMENT_MILESTONE": "PAYMENT",
        "TENDER_DEPOSIT": "OTHER",
        "SITE_VISIT": "OTHER",
    }
    return aliases.get(candidate, candidate)


def validate_email_address(value: str) -> str:
    """Apply a deliberately conservative address grammar and reject header injection."""
    candidate = value.strip()
    if (
        not candidate
        or len(candidate) > 254
        or any(ord(character) < 32 or ord(character) == 127 for character in candidate)
        or candidate.count("@") != 1
    ):
        raise ValueError("attendee must be a valid email address")
    local, domain = candidate.rsplit("@", 1)
    if not local or len(local) > 64 or local.startswith(".") or local.endswith("."):
        raise ValueError("attendee must be a valid email address")
    if ".." in local or not all(
        character.isascii()
        and (character.isalnum() or character in ".!#$%&'*+/=?^_`{|}~-")
        for character in local
    ):
        raise ValueError("attendee must be a valid email address")
    try:
        ascii_domain = domain.rstrip(".").encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise ValueError("attendee must be a valid email address") from exc
    labels = ascii_domain.split(".")
    if (
        len(ascii_domain) > 253
        or len(labels) < 2
        or any(
            not label
            or len(label) > 63
            or label.startswith("-")
            or label.endswith("-")
            or not all(character.isalnum() or character == "-" for character in label)
            for label in labels
        )
    ):
        raise ValueError("attendee must be a valid email address")
    return f"{local}@{ascii_domain}"


def _aware_datetime(value: datetime | None) -> datetime | None:
    if value is not None and (value.tzinfo is None or value.utcoffset() is None):
        raise ValueError("deadline_at must be an RFC3339 date-time with a UTC offset")
    return value


def _unique_reminder_minutes(values: list[int]) -> list[int]:
    if len(values) > 5:
        raise ValueError("Google Calendar supports at most five reminder overrides")
    if len(values) != len(set(values)):
        raise ValueError("reminder minutes must not contain duplicates")
    if any(
        not isinstance(value, int)
        or isinstance(value, bool)
        or value < 0
        or value > MAX_REMINDER_MINUTES
        for value in values
    ):
        raise ValueError("reminder minutes must be between 0 and 40320")
    return values


def _unique_attendees(values: list[str]) -> list[str]:
    normalized = [validate_email_address(value) for value in values]
    keys = [value.casefold() for value in normalized]
    if len(keys) != len(set(keys)):
        raise ValueError("attendees must not contain duplicates")
    return normalized


class DeadlineSource(StrictModel):
    page: int | None = Field(default=None, ge=1)
    section: str | None = Field(default=None, max_length=1000)
    snippet: str = Field(default="", max_length=100_000)
    document: str | None = Field(default=None, max_length=500)


class CalendarDeadline(StrictModel):
    """Calendar-facing projection of a source-backed startup analysis deadline."""

    id: str = Field(min_length=1, max_length=200)
    kind: DeadlineKind
    title: str = Field(min_length=1, max_length=500)
    date_text: str = Field(min_length=1, max_length=2000)
    deadline_at: datetime | None = None
    all_day: bool = False
    timezone: str = "Asia/Singapore"
    confidence: DeadlineConfidence
    needs_review: bool
    source: DeadlineSource

    _timezone_is_valid = field_validator("timezone")(validate_timezone)
    _deadline_has_offset = field_validator("deadline_at")(_aware_datetime)
    _kind_is_normalized = field_validator("kind", mode="before")(normalize_deadline_kind)

    @model_validator(mode="after")
    def unresolved_deadline_requires_review(self) -> "CalendarDeadline":
        if self.deadline_at is None and not self.needs_review:
            raise ValueError("a deadline without deadline_at must require review")
        return self


class ReminderOverride(StrictModel):
    method: ReminderMethod = "popup"
    minutes: int = Field(ge=0, le=MAX_REMINDER_MINUTES)

    @field_validator("minutes", mode="before")
    @classmethod
    def minutes_are_an_integer(cls, value: object) -> object:
        if not isinstance(value, int) or isinstance(value, bool):
            raise ValueError("reminder minutes must be an integer")
        return value


class DeadlineSyncOverride(StrictModel):
    deadline_id: str = Field(min_length=1, max_length=200)
    deadline_at: datetime | None = None
    all_day: bool | None = None
    timezone: str | None = Field(default=None, min_length=1, max_length=100)
    title: str | None = Field(default=None, min_length=1, max_length=500)
    confirmed: bool
    reminder_minutes: list[int] | None = Field(default=None, max_length=5)
    reminders: list[ReminderOverride] | None = Field(default=None, max_length=5)
    attendees: list[str] | None = Field(default=None, max_length=50)

    @field_validator("timezone")
    @classmethod
    def timezone_is_valid(cls, value: str | None) -> str | None:
        return None if value is None else validate_timezone(value)

    _deadline_has_offset = field_validator("deadline_at")(_aware_datetime)

    @field_validator("reminder_minutes")
    @classmethod
    def reminder_minutes_are_valid(cls, value: list[int] | None) -> list[int] | None:
        return None if value is None else _unique_reminder_minutes(value)

    @field_validator("attendees")
    @classmethod
    def attendees_are_valid(cls, value: list[str] | None) -> list[str] | None:
        return None if value is None else _unique_attendees(value)

    @model_validator(mode="after")
    def reminders_are_unique(self) -> "DeadlineSyncOverride":
        if self.reminders is not None:
            reminder_keys = [(item.method, item.minutes) for item in self.reminders]
            if len(reminder_keys) != len(set(reminder_keys)):
                raise ValueError("reminders must not contain duplicates")
        return self


class CalendarSyncRequest(StrictModel):
    deadline_ids: list[str] = Field(min_length=1, max_length=250)
    calendar_id: str = Field(default="primary", min_length=1, max_length=1024)
    reminder_minutes: list[int] = Field(
        default_factory=lambda: list(DEFAULT_REMINDER_MINUTES), max_length=5
    )
    attendees: list[str] = Field(default_factory=list, max_length=50)
    deadline_overrides: list[DeadlineSyncOverride] = Field(default_factory=list, max_length=250)
    reminders: list[ReminderOverride] | None = Field(default=None, max_length=5)

    @field_validator("deadline_ids")
    @classmethod
    def deadline_ids_are_unique(cls, value: list[str]) -> list[str]:
        normalized = [item.strip() for item in value]
        if any(not item for item in normalized) or len(normalized) != len(set(normalized)):
            raise ValueError("deadline_ids must be non-empty and unique")
        return normalized

    @field_validator("calendar_id")
    @classmethod
    def calendar_id_is_safe(cls, value: str) -> str:
        candidate = value.strip()
        if not candidate or any(
            ord(character) < 32 or ord(character) == 127 for character in candidate
        ):
            raise ValueError("calendar_id contains invalid characters")
        return candidate

    @field_validator("reminder_minutes")
    @classmethod
    def reminder_minutes_are_valid(cls, value: list[int]) -> list[int]:
        return _unique_reminder_minutes(value)

    @field_validator("attendees")
    @classmethod
    def attendees_are_valid(cls, value: list[str]) -> list[str]:
        return _unique_attendees(value)

    @model_validator(mode="after")
    def overrides_are_unique(self) -> "CalendarSyncRequest":
        override_ids = [item.deadline_id for item in self.deadline_overrides]
        if len(override_ids) != len(set(override_ids)):
            raise ValueError("deadline_overrides must contain each deadline at most once")
        if self.reminders is not None:
            reminder_keys = [(item.method, item.minutes) for item in self.reminders]
            if len(reminder_keys) != len(set(reminder_keys)):
                raise ValueError("reminders must not contain duplicates")
        return self

    def effective_reminders(self) -> list[ReminderOverride]:
        if self.reminders is not None:
            return list(self.reminders)
        popup_rows = [
            ReminderOverride(method="popup", minutes=value)
            for value in self.reminder_minutes
        ]
        if "reminder_minutes" in self.model_fields_set:
            return popup_rows
        email_capacity = max(0, 5 - len(popup_rows))
        return [
            *popup_rows,
            *(
                ReminderOverride(method="email", minutes=value)
                for value in self.reminder_minutes[:email_capacity]
            ),
        ]


class CalendarStatus(StrictModel):
    configured: bool
    connected: bool
    provider: Literal["GOOGLE"] = "GOOGLE"
    account_email: str | None = None
    reauthorization_required: bool = False
    scope: str | None = None
    ics_available: Literal[True] = True
    message: str = ""


class GoogleOAuthAuthorization(StrictModel):
    authorization_url: str
    state: str
    code_verifier: SecretStr


class GoogleTokenSet(StrictModel):
    access_token: SecretStr
    refresh_token: SecretStr | None = None
    expires_at: datetime | None = None
    scope: str
    token_type: Literal["Bearer"] = "Bearer"


class ExistingCalendarEvent(StrictModel):
    deadline_id: str
    event_id: str
    payload_hash: str
    event_link: str | None = None


class CalendarDeadlineSettings(StrictModel):
    """Validated effective notification settings for one deadline."""

    reminders: list[ReminderOverride] = Field(default_factory=list, max_length=5)
    attendees: list[str] = Field(default_factory=list, max_length=50)

    @model_validator(mode="after")
    def settings_are_unique(self) -> "CalendarDeadlineSettings":
        reminder_keys = [(item.method, item.minutes) for item in self.reminders]
        if len(reminder_keys) != len(set(reminder_keys)):
            raise ValueError("reminders must not contain duplicates")
        self.attendees = _unique_attendees(self.attendees)
        return self


class CalendarDeadlineState(StrictModel):
    deadline_id: str
    calendar_id: str
    override: DeadlineSyncOverride | None = None
    reminders: list[ReminderOverride] | None = None
    attendees: list[str] | None = None
    event_id: str | None = None
    event_link: str | None = None
    payload_hash: str | None = None
    status: CalendarSyncItemStatus | None = None
    last_synced_at: datetime | None = None


class CalendarAnalysisStateResponse(StrictModel):
    analysis_id: str
    calendar_id: str
    deadlines: list[CalendarDeadlineState]


class CalendarSyncItem(StrictModel):
    deadline_id: str
    status: CalendarSyncItemStatus
    event_id: str | None = None
    event_link: str | None = None
    error: str | None = None
    payload_hash: str | None = None


class CalendarSyncResponse(StrictModel):
    status: CalendarSyncStatus
    calendar_id: str
    results: list[CalendarSyncItem]
