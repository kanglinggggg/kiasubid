from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

ProposalSectionKey = Literal[
    "SOLUTION",
    "TECHNICAL_ARCHITECTURE",
    "DELIVERY",
    "SECURITY_PRIVACY",
    "TEAM_GOVERNANCE",
    "SERVICE_SUPPORT",
    "RISK_CONTINUITY",
    "COMMERCIAL",
    "OTHER",
]
ProposalVerdict = Literal["STRONG", "NEEDS_DETAIL", "RISKY_CLAIM"]
CoverageStatus = Literal["COVERED", "PARTIAL", "OPEN_ITEM"]
ProviderMode = Literal["BEDROCK", "GROQ"]

MAX_PROPOSAL_ANSWER_CHARACTERS = 4_000
MAX_PROPOSAL_TOTAL_ANSWER_CHARACTERS = 120_000
MAX_PROPOSAL_SESSION_ANSWERS = 20
MAX_PROPOSAL_PROMPT_CHARACTERS = 280_000
PROPOSAL_REPAIR_PROMPT_RESERVE_CHARACTERS = 10_000

CORE_QUESTION_SECTIONS = frozenset(
    {
        "SOLUTION",
        "TECHNICAL_ARCHITECTURE",
        "DELIVERY",
        "SECURITY_PRIVACY",
        "TEAM_GOVERNANCE",
    }
)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


def _unique_non_empty(values: list[str], field_name: str) -> list[str]:
    if any(not value for value in values):
        raise ValueError(f"{field_name} cannot contain blank values")
    if len(values) != len(set(values)):
        raise ValueError(f"{field_name} cannot contain duplicate values")
    return values


class ProposalQuestion(StrictModel):
    id: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
    section: ProposalSectionKey
    question: str = Field(min_length=5, max_length=1000)
    why_it_matters: str = Field(min_length=5, max_length=1000)
    answer_guidance: list[str] = Field(min_length=1, max_length=5)
    required: bool
    context_refs: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("answer_guidance", "context_refs")
    @classmethod
    def list_values_are_unique(cls, values: list[str], info) -> list[str]:
        return _unique_non_empty(values, info.field_name)


class ProposalQuestionPlan(StrictModel):
    mentor_intro: str = Field(min_length=10, max_length=1500)
    questions: list[ProposalQuestion] = Field(min_length=5, max_length=10)

    @model_validator(mode="after")
    def has_unique_ids_and_core_coverage(self) -> "ProposalQuestionPlan":
        question_ids = [question.id for question in self.questions]
        if len(question_ids) != len(set(question_ids)):
            raise ValueError("question ids must be unique")
        covered = {question.section for question in self.questions if question.required}
        missing = CORE_QUESTION_SECTIONS - covered
        if missing:
            raise ValueError(
                "required questions must cover these core sections: "
                + ", ".join(sorted(missing))
            )
        return self


class ProposalAnswer(StrictModel):
    question_id: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
    section: ProposalSectionKey
    question: str = Field(min_length=5, max_length=1000)
    raw_answer: str = Field(min_length=2, max_length=MAX_PROPOSAL_ANSWER_CHARACTERS)
    formalized_answer: str = Field(min_length=2, max_length=MAX_PROPOSAL_ANSWER_CHARACTERS)
    context_refs: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("context_refs")
    @classmethod
    def context_references_are_unique(cls, values: list[str]) -> list[str]:
        return _unique_non_empty(values, "context_refs")


class ProposalCritique(StrictModel):
    question_id: str = Field(pattern=r"^[A-Za-z][A-Za-z0-9_-]{0,63}$")
    verdict: ProposalVerdict
    mentor_feedback: str = Field(min_length=5, max_length=2000)
    strengths: list[str] = Field(default_factory=list, max_length=3)
    gaps: list[str] = Field(default_factory=list, max_length=3)
    formalized_answer: str = Field(min_length=2, max_length=MAX_PROPOSAL_ANSWER_CHARACTERS)
    answer_quotes: list[str] = Field(min_length=1, max_length=10)
    evidence_needed: list[str] = Field(default_factory=list, max_length=10)
    unsupported_claims: list[str] = Field(default_factory=list, max_length=10)
    context_refs: list[str] = Field(default_factory=list, max_length=50)
    needs_follow_up: bool
    follow_up_question: str | None = Field(default=None, max_length=1000)

    @field_validator(
        "strengths",
        "gaps",
        "answer_quotes",
        "evidence_needed",
        "unsupported_claims",
        "context_refs",
    )
    @classmethod
    def list_values_are_unique(cls, values: list[str], info) -> list[str]:
        return _unique_non_empty(values, info.field_name)

    @model_validator(mode="after")
    def follow_up_shape_is_consistent(self) -> "ProposalCritique":
        if self.needs_follow_up and not self.follow_up_question:
            raise ValueError("needs_follow_up=true requires follow_up_question")
        if not self.needs_follow_up and self.follow_up_question is not None:
            raise ValueError("follow_up_question must be null when needs_follow_up=false")
        return self


class GroundedParagraph(StrictModel):
    text: str = Field(min_length=2, max_length=6000)
    supporting_answer_ids: list[str] = Field(default_factory=list, max_length=30)
    context_refs: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("supporting_answer_ids", "context_refs")
    @classmethod
    def references_are_unique(cls, values: list[str], info) -> list[str]:
        return _unique_non_empty(values, info.field_name)

    @model_validator(mode="after")
    def paragraph_has_provenance(self) -> "GroundedParagraph":
        if not self.supporting_answer_ids and not self.context_refs:
            raise ValueError("every proposal paragraph must have a grounding reference")
        return self


class ProposalSection(StrictModel):
    section_key: ProposalSectionKey
    heading: str = Field(min_length=2, max_length=200)
    paragraphs: list[GroundedParagraph] = Field(min_length=1, max_length=20)


class RequirementCoverage(StrictModel):
    context_ref: str = Field(min_length=1, max_length=200)
    status: CoverageStatus
    section_keys: list[ProposalSectionKey] = Field(default_factory=list, max_length=10)
    explanation: str = Field(min_length=2, max_length=1000)

    @field_validator("section_keys")
    @classmethod
    def section_keys_are_unique(cls, values: list[str]) -> list[str]:
        return _unique_non_empty(values, "section_keys")


class ProposalOpenItem(StrictModel):
    text: str = Field(min_length=2, max_length=1000)
    related_answer_ids: list[str] = Field(default_factory=list, max_length=30)
    context_refs: list[str] = Field(default_factory=list, max_length=50)

    @field_validator("related_answer_ids", "context_refs")
    @classmethod
    def references_are_unique(cls, values: list[str], info) -> list[str]:
        return _unique_non_empty(values, info.field_name)


class ProposalDraftContent(StrictModel):
    title: str = Field(min_length=3, max_length=300)
    executive_summary: list[GroundedParagraph] = Field(min_length=1, max_length=4)
    sections: list[ProposalSection] = Field(min_length=5, max_length=10)
    requirement_coverage: list[RequirementCoverage] = Field(default_factory=list, max_length=100)
    open_items: list[ProposalOpenItem] = Field(default_factory=list, max_length=50)

    @model_validator(mode="after")
    def sections_and_coverage_are_unique(self) -> "ProposalDraftContent":
        section_keys = [section.section_key for section in self.sections]
        if len(section_keys) != len(set(section_keys)):
            raise ValueError("proposal section keys must be unique")
        missing = CORE_QUESTION_SECTIONS - set(section_keys)
        if missing:
            raise ValueError(
                "proposal must contain these core sections: " + ", ".join(sorted(missing))
            )
        coverage_refs = [item.context_ref for item in self.requirement_coverage]
        if len(coverage_refs) != len(set(coverage_refs)):
            raise ValueError("requirement_coverage context_ref values must be unique")
        return self


class ProposalDraft(ProposalDraftContent):
    review_notice: str = Field(min_length=10, max_length=500)
    markdown: str = Field(min_length=10, max_length=100_000)


class InvocationEnvelope(StrictModel):
    mode: ProviderMode
    model_id: str = Field(min_length=1, max_length=500)
    attempts: int = Field(ge=1)
    duration_ms: float = Field(ge=0)
    input_tokens: int | None = Field(default=None, ge=0)
    output_tokens: int | None = Field(default=None, ge=0)
    total_tokens: int | None = Field(default=None, ge=0)


class ProposalQuestionPlanEnvelope(InvocationEnvelope):
    result: ProposalQuestionPlan


class ProposalCritiqueEnvelope(InvocationEnvelope):
    result: ProposalCritique


class ProposalDraftEnvelope(InvocationEnvelope):
    result: ProposalDraft
