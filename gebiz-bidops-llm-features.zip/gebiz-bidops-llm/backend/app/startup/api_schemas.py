"""HTTP boundary schemas for the Startup Studio workflows."""

import re
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.startup.proposal_schemas import MAX_PROPOSAL_ANSWER_CHARACTERS

_EMAIL_PATTERN = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def _validated_emails(value: list[str] | None) -> list[str] | None:
    if value is None:
        return None
    normalized = [item.strip().casefold() for item in value]
    if len(normalized) != len(set(normalized)):
        raise ValueError("attendee email addresses must be unique")
    if any(not _EMAIL_PATTERN.fullmatch(item) or len(item) > 254 for item in normalized):
        raise ValueError("each attendee must be a valid email address")
    return normalized


class ApiModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class AnalysisJobError(ApiModel):
    code: str
    message: str


class AnalysisJobResponse(ApiModel):
    id: str
    status: Literal["QUEUED", "EXTRACTING", "ANALYSING", "COMPLETED", "FAILED"]
    stage: str
    progress: int = Field(ge=0, le=100)
    analysis_id: str | None = None
    error: AnalysisJobError | None = None
    created_at: datetime
    updated_at: datetime


class ProposalSessionCreate(ApiModel):
    analysis_id: str = Field(min_length=1, max_length=100)
    company_name: str = Field(min_length=2, max_length=200)
    solution_name: str = Field(min_length=2, max_length=200)


class ProposalAnswerSubmit(ApiModel):
    question_id: str = Field(min_length=1, max_length=100)
    answer: str = Field(min_length=2, max_length=MAX_PROPOSAL_ANSWER_CHARACTERS)
    revision: int = Field(ge=0)


class ProposalGenerateRequest(ApiModel):
    revision: int = Field(ge=0)


class DeadlineOverride(ApiModel):
    deadline_id: str = Field(min_length=1, max_length=100)
    deadline_at: datetime | None = None
    all_day: bool | None = None
    timezone: str | None = Field(default=None, min_length=1, max_length=100)
    title: str | None = Field(default=None, min_length=1, max_length=300)
    confirmed: bool = False
    reminder_minutes: list[int] | None = Field(default=None, max_length=5)
    attendees: list[str] | None = Field(default=None, max_length=50)

    @field_validator("reminder_minutes")
    @classmethod
    def reminders_are_unique_and_supported(cls, value: list[int] | None) -> list[int] | None:
        if value is None:
            return None
        if len(value) != len(set(value)):
            raise ValueError("reminder minutes must be unique")
        if any(minutes < 0 or minutes > 40_320 for minutes in value):
            raise ValueError("reminders must be between 0 and 40320 minutes")
        return value

    @field_validator("attendees")
    @classmethod
    def attendee_addresses_are_valid(cls, value: list[str] | None) -> list[str] | None:
        return _validated_emails(value)


class CalendarSyncRequest(ApiModel):
    deadline_ids: list[str] = Field(min_length=1, max_length=250)
    calendar_id: str = Field(default="primary", min_length=1, max_length=500)
    reminder_minutes: list[int] = Field(default_factory=lambda: [10_080, 1_440, 120], max_length=5)
    attendees: list[str] = Field(default_factory=list, max_length=50)
    deadline_overrides: list[DeadlineOverride] = Field(default_factory=list, max_length=250)

    @field_validator("deadline_ids")
    @classmethod
    def deadline_ids_are_unique(cls, value: list[str]) -> list[str]:
        if len(value) != len(set(value)):
            raise ValueError("deadline_ids must be unique")
        return value

    @field_validator("reminder_minutes")
    @classmethod
    def reminders_are_unique_and_supported(cls, value: list[int]) -> list[int]:
        if len(value) != len(set(value)):
            raise ValueError("reminder minutes must be unique")
        if any(minutes < 0 or minutes > 40_320 for minutes in value):
            raise ValueError("reminders must be between 0 and 40320 minutes")
        return value

    @field_validator("attendees")
    @classmethod
    def attendee_addresses_are_valid(cls, value: list[str]) -> list[str]:
        return _validated_emails(value) or []


class CalendarStatusResponse(ApiModel):
    configured: bool
    connected: bool
    provider: Literal["GOOGLE"] = "GOOGLE"
    account_email: str | None = None
    reauthorization_required: bool = False
    scope: str | None = None
    ics_available: bool = True
    message: str


class ProposalSessionResponse(ApiModel):
    """Loose enough to keep persisted sessions forward-compatible, strict at top level."""

    id: str
    analysis_id: str
    company_name: str
    solution_name: str
    status: Literal["IN_PROGRESS", "READY", "GENERATED"]
    revision: int
    progress: dict[str, int]
    current_question: dict[str, Any] | None
    questions: list[dict[str, Any]]
    answers: list[dict[str, Any]]
    last_feedback: dict[str, Any] | None
    draft: dict[str, Any] | None
    mode: str
    model_id: str
    created_at: datetime
    updated_at: datetime
