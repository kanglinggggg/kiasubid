import base64
import hashlib
import json
import re
import secrets
from collections.abc import Mapping, Sequence
from datetime import UTC, datetime, timedelta
from typing import Any, Protocol
from urllib.parse import quote, urlencode, urlsplit
from zoneinfo import ZoneInfo

from cryptography.fernet import Fernet, InvalidToken
from pydantic import SecretStr, ValidationError

from app.config import Settings, settings
from app.startup.calendar_schemas import (
    DEFAULT_REMINDER_MINUTES,
    MAX_REMINDER_MINUTES,
    CalendarDeadline,
    CalendarDeadlineSettings,
    CalendarSyncItem,
    CalendarSyncRequest,
    CalendarSyncResponse,
    DeadlineSyncOverride,
    ExistingCalendarEvent,
    GoogleOAuthAuthorization,
    GoogleTokenSet,
    ReminderOverride,
    validate_email_address,
)

GOOGLE_AUTHORIZATION_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
GOOGLE_CALENDAR_API_ROOT = "https://www.googleapis.com/calendar/v3"
GOOGLE_CALENDAR_SCOPES = ("https://www.googleapis.com/auth/calendar.events",)

_PKCE_PATTERN = re.compile(r"^[A-Za-z0-9._~-]{43,128}$")
_OAUTH_STATE_PATTERN = re.compile(r"^[A-Za-z0-9._~-]{32,512}$")
_GOOGLE_EVENT_ID_PATTERN = re.compile(r"^[a-v0-9]{5,1024}$")
_SAFE_PROVIDER_CODE = re.compile(r"^[A-Za-z0-9_.-]{1,100}$")


class CalendarError(RuntimeError):
    pass


class CalendarConfigurationError(CalendarError):
    pass


class CalendarValidationError(CalendarError):
    pass


class CalendarProviderError(CalendarError):
    def __init__(self, message: str, *, status_code: int | None = None, code: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class HttpResponse(Protocol):
    status_code: int

    def json(self) -> Any: ...


class HttpClient(Protocol):
    def post(self, url: str, **kwargs: Any) -> HttpResponse: ...

    def request(self, method: str, url: str, **kwargs: Any) -> HttpResponse: ...


def _secret(value: SecretStr | str | None) -> str:
    if isinstance(value, SecretStr):
        return value.get_secret_value()
    return value or ""


def _owned_http_client() -> Any:
    try:
        import httpx
    except ImportError as exc:  # pragma: no cover - dependency is present in the application lock
        raise CalendarConfigurationError("The HTTP client dependency is unavailable.") from exc
    return httpx.Client(timeout=20, follow_redirects=False)


def _google_client_configuration(app_settings: Settings) -> tuple[str, str, str]:
    client_id = (app_settings.google_client_id or "").strip()
    client_secret = _secret(app_settings.google_client_secret)
    redirect_uri = (app_settings.google_redirect_uri or "").strip()
    if not client_id or not client_secret or not redirect_uri:
        raise CalendarConfigurationError("Google Calendar OAuth is not configured.")
    return client_id, client_secret, redirect_uri


def _validate_pkce_verifier(code_verifier: str) -> str:
    if not _PKCE_PATTERN.fullmatch(code_verifier):
        raise CalendarValidationError("The PKCE code verifier is invalid.")
    return code_verifier


def create_google_authorization(
    *,
    app_settings: Settings = settings,
    state: str | None = None,
    code_verifier: str | None = None,
    force_consent: bool = False,
) -> GoogleOAuthAuthorization:
    client_id, _, redirect_uri = _google_client_configuration(app_settings)
    oauth_state = state or secrets.token_urlsafe(32)
    if not _OAUTH_STATE_PATTERN.fullmatch(oauth_state):
        raise CalendarValidationError(
            "OAuth state must be an opaque value of 32 to 512 characters."
        )
    verifier = _validate_pkce_verifier(code_verifier or secrets.token_urlsafe(64))
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest()).decode(
        "ascii"
    ).rstrip("=")
    parameters = {
        "access_type": "offline",
        "client_id": client_id,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "include_granted_scopes": "true",
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": " ".join(GOOGLE_CALENDAR_SCOPES),
        "state": oauth_state,
    }
    if force_consent:
        parameters["prompt"] = "consent"
    return GoogleOAuthAuthorization(
        authorization_url=f"{GOOGLE_AUTHORIZATION_ENDPOINT}?{urlencode(parameters)}",
        state=oauth_state,
        code_verifier=SecretStr(verifier),
    )


def _response_payload(response: HttpResponse) -> dict[str, Any]:
    try:
        payload = response.json()
    except Exception as exc:
        raise CalendarProviderError(
            "Google returned a response that was not valid JSON.",
            status_code=getattr(response, "status_code", None),
        ) from exc
    if not isinstance(payload, dict):
        raise CalendarProviderError(
            "Google returned an unexpected response.",
            status_code=getattr(response, "status_code", None),
        )
    return payload


def _provider_code(payload: Mapping[str, Any]) -> str | None:
    error = payload.get("error")
    candidate: Any
    if isinstance(error, str):
        candidate = error
    elif isinstance(error, Mapping):
        candidate = error.get("status") or error.get("code")
        errors = error.get("errors")
        if isinstance(errors, list) and errors and isinstance(errors[0], Mapping):
            candidate = errors[0].get("reason") or candidate
    else:
        candidate = None
    normalized = str(candidate) if candidate is not None else ""
    return normalized if _SAFE_PROVIDER_CODE.fullmatch(normalized) else None


def _checked_payload(response: HttpResponse, operation: str) -> dict[str, Any]:
    payload = _response_payload(response)
    if not 200 <= response.status_code < 300:
        code = _provider_code(payload)
        suffix = f" ({code})" if code else ""
        raise CalendarProviderError(
            f"{operation} failed with HTTP {response.status_code}{suffix}.",
            status_code=response.status_code,
            code=code,
        )
    return payload


def _parse_token_payload(
    payload: Mapping[str, Any], *, retained_refresh_token: str | None = None
) -> GoogleTokenSet:
    access_token = payload.get("access_token")
    token_type = payload.get("token_type", "Bearer")
    if (
        not isinstance(access_token, str)
        or not access_token
        or str(token_type).casefold() != "bearer"
    ):
        raise CalendarProviderError("Google returned an invalid OAuth token response.")
    expires_in = payload.get("expires_in")
    expires_at = None
    if expires_in is not None:
        if not isinstance(expires_in, (int, float)) or expires_in <= 0:
            raise CalendarProviderError("Google returned an invalid OAuth token lifetime.")
        expires_at = datetime.now(UTC) + timedelta(seconds=float(expires_in))
    response_refresh = payload.get("refresh_token")
    if response_refresh is not None and (
        not isinstance(response_refresh, str) or not response_refresh
    ):
        raise CalendarProviderError("Google returned an invalid OAuth refresh token.")
    scope = payload.get("scope")
    if scope is None:
        scope = " ".join(GOOGLE_CALENDAR_SCOPES)
    if not isinstance(scope, str):
        raise CalendarProviderError("Google returned an invalid OAuth scope.")
    if not set(GOOGLE_CALENDAR_SCOPES).issubset(set(scope.split())):
        raise CalendarProviderError(
            "Google Calendar permission was not granted.", code="missing_scope"
        )
    refresh_token = response_refresh or retained_refresh_token
    return GoogleTokenSet(
        access_token=SecretStr(access_token),
        refresh_token=SecretStr(refresh_token) if refresh_token else None,
        expires_at=expires_at,
        scope=scope,
        token_type="Bearer",
    )


def exchange_google_code(
    code: str,
    code_verifier: str | SecretStr,
    *,
    app_settings: Settings = settings,
    client: HttpClient | None = None,
) -> GoogleTokenSet:
    client_id, client_secret, redirect_uri = _google_client_configuration(app_settings)
    authorization_code = code.strip()
    if not authorization_code or len(authorization_code) > 4096 or any(
        ord(character) < 32 or ord(character) == 127 for character in authorization_code
    ):
        raise CalendarValidationError("The OAuth authorization code is invalid.")
    verifier = _validate_pkce_verifier(_secret(code_verifier))
    owned = client is None
    http = client or _owned_http_client()
    try:
        try:
            response = http.post(
                GOOGLE_TOKEN_ENDPOINT,
                data={
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "code": authorization_code,
                    "code_verifier": verifier,
                    "grant_type": "authorization_code",
                    "redirect_uri": redirect_uri,
                },
                headers={"Accept": "application/json"},
                timeout=20,
            )
        except Exception as exc:
            raise CalendarProviderError(
                "Google OAuth code exchange could not be completed."
            ) from exc
        return _parse_token_payload(_checked_payload(response, "Google OAuth code exchange"))
    finally:
        if owned:
            http.close()


def refresh_google_token(
    refresh_token: str | SecretStr,
    *,
    app_settings: Settings = settings,
    client: HttpClient | None = None,
) -> GoogleTokenSet:
    client_id, client_secret, _ = _google_client_configuration(app_settings)
    retained_refresh_token = _secret(refresh_token)
    if not retained_refresh_token or len(retained_refresh_token) > 4096 or any(
        ord(character) < 32 or ord(character) == 127 for character in retained_refresh_token
    ):
        raise CalendarValidationError("The OAuth refresh token is invalid.")
    owned = client is None
    http = client or _owned_http_client()
    try:
        try:
            response = http.post(
                GOOGLE_TOKEN_ENDPOINT,
                data={
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "grant_type": "refresh_token",
                    "refresh_token": retained_refresh_token,
                },
                headers={"Accept": "application/json"},
                timeout=20,
            )
        except Exception as exc:
            raise CalendarProviderError(
                "Google OAuth token refresh could not be completed."
            ) from exc
        payload = _checked_payload(response, "Google OAuth token refresh")
        return _parse_token_payload(payload, retained_refresh_token=retained_refresh_token)
    finally:
        if owned:
            http.close()


class CalendarTokenCipher:
    """Encrypt calendar tokens with a domain-separated key derived from the app secret."""

    def __init__(self, app_secret: str | SecretStr):
        secret = _secret(app_secret)
        if len(secret.encode("utf-8")) < 32:
            raise CalendarConfigurationError("APP_SECRET_KEY must contain at least 32 bytes.")
        derived = hashlib.sha256(b"gebiz-bidops/calendar-token/v1\x00" + secret.encode()).digest()
        self._fernet = Fernet(base64.urlsafe_b64encode(derived))

    @classmethod
    def from_settings(cls, app_settings: Settings = settings) -> "CalendarTokenCipher":
        if app_settings.app_secret_key is None:
            raise CalendarConfigurationError("APP_SECRET_KEY is not configured.")
        return cls(app_settings.app_secret_key)

    def encrypt(self, token: str | SecretStr) -> str:
        plaintext = _secret(token)
        if not plaintext or len(plaintext) > 16_384:
            raise CalendarValidationError("The token cannot be encrypted.")
        return self._fernet.encrypt(plaintext.encode("utf-8")).decode("ascii")

    def decrypt(self, encrypted_token: str) -> str:
        if not encrypted_token or len(encrypted_token) > 65_536:
            raise CalendarValidationError("The encrypted calendar token is invalid.")
        try:
            return self._fernet.decrypt(encrypted_token.encode("ascii")).decode("utf-8")
        except (InvalidToken, UnicodeError, ValueError) as exc:
            raise CalendarValidationError("The encrypted calendar token is invalid.") from exc


def from_analysis_deadline(value: CalendarDeadline | Mapping[str, Any] | Any) -> CalendarDeadline:
    if isinstance(value, CalendarDeadline):
        return value
    if isinstance(value, Mapping):
        payload = dict(value)
    elif hasattr(value, "model_dump"):
        payload = value.model_dump(mode="python")
    else:
        raise CalendarValidationError("Deadline data has an unsupported shape.")
    try:
        return CalendarDeadline.model_validate(payload)
    except ValidationError as exc:
        raise CalendarValidationError("Deadline data failed calendar validation.") from exc


def validate_reminder_minutes(values: Sequence[int]) -> list[int]:
    normalized = list(values)
    if len(normalized) > 5:
        raise CalendarValidationError("Google Calendar supports at most five reminders.")
    if len(normalized) != len(set(normalized)):
        raise CalendarValidationError("Reminder minutes must not contain duplicates.")
    if any(
        not isinstance(value, int)
        or isinstance(value, bool)
        or value < 0
        or value > MAX_REMINDER_MINUTES
        for value in normalized
    ):
        raise CalendarValidationError("Reminder minutes must be integers between 0 and 40320.")
    return normalized


def validate_attendees(values: Sequence[str]) -> list[str]:
    if len(values) > 50:
        raise CalendarValidationError("At most 50 attendees may be included.")
    try:
        normalized = [validate_email_address(value) for value in values]
    except ValueError as exc:
        raise CalendarValidationError(str(exc)) from exc
    keys = [value.casefold() for value in normalized]
    if len(keys) != len(set(keys)):
        raise CalendarValidationError("Attendees must not contain duplicates.")
    return normalized


def stable_google_event_id(analysis_id: str, deadline_id: str) -> str:
    material = f"{analysis_id}\x00{deadline_id}".encode("utf-8")
    return f"b{hashlib.sha256(material).hexdigest()[:39]}"


def stable_ical_uid(analysis_id: str, deadline_id: str) -> str:
    material = f"{analysis_id}\x00{deadline_id}".encode("utf-8")
    return f"bidops-{hashlib.sha256(material).hexdigest()}@calendar.gebiz-bidops.local"


def _clean_plain_text(value: str, *, maximum: int) -> str:
    cleaned = "".join(
        character
        if character in "\n\t" or (ord(character) >= 32 and ord(character) != 127)
        else " "
        for character in value
    )
    return " ".join(cleaned.split())[:maximum]


def _ics_escape(value: str) -> str:
    normalized = value.replace("\r\n", "\n").replace("\r", "\n")
    normalized = "".join(
        character
        if character == "\n" or (ord(character) >= 32 and ord(character) != 127)
        else " "
        for character in normalized
    )
    return (
        normalized.replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\n", "\\n")
    )


def _fold_ics_line(line: str) -> list[str]:
    if not line:
        return [""]
    folded: list[str] = []
    current = ""
    current_bytes = 0
    first = True
    for character in line:
        encoded_length = len(character.encode("utf-8"))
        capacity = 75 if first else 74
        if current and current_bytes + encoded_length > capacity:
            folded.append(("" if first else " ") + current)
            first = False
            current = character
            current_bytes = encoded_length
        else:
            current += character
            current_bytes += encoded_length
    folded.append(("" if first else " ") + current)
    return folded


def _ics_trigger(minutes: int) -> str:
    if minutes == 0:
        return "-PT0M"
    if minutes % 10_080 == 0:
        return f"-P{minutes // 10_080}W"
    days, remainder = divmod(minutes, 1_440)
    hours, minute_remainder = divmod(remainder, 60)
    value = "-P"
    if days:
        value += f"{days}D"
    if hours or minute_remainder or not days:
        value += "T"
        if hours:
            value += f"{hours}H"
        if minute_remainder or not hours:
            value += f"{minute_remainder}M"
    return value


def _event_local_time(deadline: CalendarDeadline) -> datetime:
    if deadline.deadline_at is None:
        raise CalendarValidationError(f"Deadline {deadline.id} has no confirmed date or time.")
    return deadline.deadline_at.astimezone(ZoneInfo(deadline.timezone))


def _require_syncable(deadline: CalendarDeadline) -> CalendarDeadline:
    if deadline.needs_review:
        raise CalendarValidationError(f"Deadline {deadline.id} requires human review.")
    _event_local_time(deadline)
    return deadline


def build_ics_calendar(
    deadlines: Sequence[CalendarDeadline | Mapping[str, Any] | Any],
    *,
    analysis_id: str,
    reminder_minutes: Sequence[int] = DEFAULT_REMINDER_MINUTES,
    calendar_name: str = "GeBIZ BidOps Deadlines",
    generated_at: datetime | None = None,
) -> str:
    reminders = validate_reminder_minutes(reminder_minutes)
    stamp = generated_at or datetime.now(UTC)
    if stamp.tzinfo is None or stamp.utcoffset() is None:
        raise CalendarValidationError("generated_at must include a UTC offset.")
    stamp_text = stamp.astimezone(UTC).strftime("%Y%m%dT%H%M%SZ")
    logical_lines = [
        "BEGIN:VCALENDAR",
        "PRODID:-//GeBIZ BidOps//Startup Deadline Calendar//EN",
        "VERSION:2.0",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
        f"X-WR-CALNAME:{_ics_escape(_clean_plain_text(calendar_name, maximum=200))}",
    ]
    seen_ids: set[str] = set()
    for raw_deadline in deadlines:
        deadline = _require_syncable(from_analysis_deadline(raw_deadline))
        if deadline.id in seen_ids:
            raise CalendarValidationError(f"Duplicate deadline ID: {deadline.id}.")
        seen_ids.add(deadline.id)
        local = _event_local_time(deadline)
        source_bits = []
        if deadline.source.document:
            source_bits.append(deadline.source.document)
        if deadline.source.page is not None:
            source_bits.append(f"page {deadline.source.page}")
        if deadline.source.section:
            source_bits.append(f"section {deadline.source.section}")
        source_label = ", ".join(source_bits) or "uploaded tender"
        summary = f"[{deadline.kind.replace('_', ' ').title()}] {deadline.title}"
        description = f"Original date wording: {deadline.date_text}\nSource: {source_label}"
        logical_lines.extend(
            [
                "BEGIN:VEVENT",
                f"UID:{stable_ical_uid(analysis_id, deadline.id)}",
                f"DTSTAMP:{stamp_text}",
                f"SUMMARY:{_ics_escape(_clean_plain_text(summary, maximum=500))}",
                f"DESCRIPTION:{_ics_escape(description)}",
                f"CATEGORIES:{_ics_escape(deadline.kind)}",
                "TRANSP:TRANSPARENT",
                "STATUS:CONFIRMED",
            ]
        )
        if deadline.all_day:
            start_date = local.date()
            logical_lines.extend(
                [
                    f"DTSTART;VALUE=DATE:{start_date.strftime('%Y%m%d')}",
                    f"DTEND;VALUE=DATE:{(start_date + timedelta(days=1)).strftime('%Y%m%d')}",
                ]
            )
        else:
            start_utc = deadline.deadline_at.astimezone(UTC)
            end_utc = start_utc + timedelta(minutes=15)
            logical_lines.extend(
                [
                    f"DTSTART:{start_utc.strftime('%Y%m%dT%H%M%SZ')}",
                    f"DTEND:{end_utc.strftime('%Y%m%dT%H%M%SZ')}",
                ]
            )
        for minutes in reminders:
            logical_lines.extend(
                [
                    "BEGIN:VALARM",
                    f"TRIGGER:{_ics_trigger(minutes)}",
                    "ACTION:DISPLAY",
                    f"DESCRIPTION:{_ics_escape('Tender deadline: ' + deadline.title)}",
                    "END:VALARM",
                ]
            )
        logical_lines.append("END:VEVENT")
    logical_lines.append("END:VCALENDAR")
    physical_lines = [folded for line in logical_lines for folded in _fold_ics_line(line)]
    return "\r\n".join(physical_lines) + "\r\n"


def _safe_calendar_text(value: str, *, maximum: int) -> str:
    """Keep Calendar's plain-text fields readable while removing control characters."""
    return _clean_plain_text(value, maximum=maximum)


def _event_source_label(deadline: CalendarDeadline) -> str:
    values = []
    if deadline.source.document:
        values.append(_clean_plain_text(deadline.source.document, maximum=300))
    if deadline.source.page is not None:
        values.append(f"page {deadline.source.page}")
    if deadline.source.section:
        values.append(f"section {_clean_plain_text(deadline.source.section, maximum=300)}")
    return ", ".join(values) or "uploaded tender"


def build_google_event_payload(
    deadline: CalendarDeadline | Mapping[str, Any] | Any,
    *,
    analysis_id: str,
    reminders: Sequence[ReminderOverride] | None = None,
    reminder_minutes: Sequence[int] | None = None,
    attendees: Sequence[str] = (),
) -> dict[str, Any]:
    item = _require_syncable(from_analysis_deadline(deadline))
    if reminders is not None and reminder_minutes is not None:
        raise CalendarValidationError("Supply reminders or reminder_minutes, not both.")
    if reminders is None:
        minute_values = validate_reminder_minutes(
            DEFAULT_REMINDER_MINUTES if reminder_minutes is None else reminder_minutes
        )
        reminder_rows = [ReminderOverride(method="popup", minutes=value) for value in minute_values]
    else:
        if len(reminders) > 5:
            raise CalendarValidationError("Google Calendar supports at most five reminders.")
        reminder_rows = [ReminderOverride.model_validate(value) for value in reminders]
        keys = [(value.method, value.minutes) for value in reminder_rows]
        if len(keys) != len(set(keys)):
            raise CalendarValidationError("Reminders must not contain duplicates.")
    attendee_values = validate_attendees(attendees)
    local = _event_local_time(item)
    if item.all_day:
        start_date = local.date()
        start: dict[str, str] = {"date": start_date.isoformat()}
        end: dict[str, str] = {"date": (start_date + timedelta(days=1)).isoformat()}
    else:
        end_local = (item.deadline_at.astimezone(UTC) + timedelta(minutes=15)).astimezone(
            ZoneInfo(item.timezone)
        )
        start = {"dateTime": local.isoformat(timespec="seconds"), "timeZone": item.timezone}
        end = {"dateTime": end_local.isoformat(timespec="seconds"), "timeZone": item.timezone}
    summary = f"[{item.kind.replace('_', ' ').title()}] {item.title}"
    description = (
        "Tender deadline managed by GeBIZ BidOps.\n"
        f"Original date wording: {_safe_calendar_text(item.date_text, maximum=1000)}\n"
        f"Source: {_safe_calendar_text(_event_source_label(item), maximum=1000)}"
    )
    payload: dict[str, Any] = {
        "id": stable_google_event_id(analysis_id, item.id),
        "summary": _safe_calendar_text(summary, maximum=500),
        "description": description,
        "start": start,
        "end": end,
        "transparency": "transparent",
        "visibility": "private",
        "guestsCanInviteOthers": False,
        "guestsCanModify": False,
        "guestsCanSeeOtherGuests": False,
        "reminders": {
            "useDefault": False,
            "overrides": [row.model_dump() for row in reminder_rows],
        },
        "extendedProperties": {
            "private": {
                "bidopsAnalysisId": _clean_plain_text(analysis_id, maximum=512),
                "bidopsDeadlineId": _clean_plain_text(item.id, maximum=512),
                "bidopsSchemaVersion": "1",
            }
        },
    }
    # PATCH uses replacement semantics for arrays.  Always send this field so a
    # later sync with no attendees removes guests added by an earlier sync.
    payload["attendees"] = [{"email": value} for value in attendee_values]
    return payload


def google_event_payload_hash(payload: Mapping[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _safe_event_link(value: Any) -> str | None:
    if not isinstance(value, str) or len(value) > 4096:
        return None
    parsed = urlsplit(value)
    if parsed.scheme != "https" or (parsed.hostname or "").casefold() not in {
        "calendar.google.com",
        "www.google.com",
    }:
        return None
    return value


def _apply_deadline_override(
    deadline: CalendarDeadline, override: DeadlineSyncOverride | None
) -> CalendarDeadline:
    if override is None:
        return _require_syncable(deadline)
    if deadline.needs_review and not override.confirmed:
        raise CalendarValidationError(f"Deadline {deadline.id} requires human confirmation.")
    if not override.confirmed:
        return _require_syncable(deadline)
    corrected_at = override.deadline_at or deadline.deadline_at
    if corrected_at is None:
        raise CalendarValidationError(
            f"Deadline {deadline.id} needs a confirmed RFC3339 date and time."
        )
    corrected = deadline.model_copy(
        update={
            "deadline_at": corrected_at,
            "all_day": deadline.all_day if override.all_day is None else override.all_day,
            "timezone": override.timezone or deadline.timezone,
            "title": override.title or deadline.title,
            "needs_review": False,
        }
    )
    return _require_syncable(CalendarDeadline.model_validate(corrected.model_dump()))


def _existing_event_map(
    values: Mapping[str, ExistingCalendarEvent | Mapping[str, Any]]
    | Sequence[ExistingCalendarEvent | Mapping[str, Any]]
    | None,
) -> dict[str, ExistingCalendarEvent]:
    if values is None:
        return {}
    iterable = values.values() if isinstance(values, Mapping) else values
    result: dict[str, ExistingCalendarEvent] = {}
    for raw in iterable:
        item = (
            raw
            if isinstance(raw, ExistingCalendarEvent)
            else ExistingCalendarEvent.model_validate(raw)
        )
        if item.deadline_id in result:
            raise CalendarValidationError("Existing calendar links contain duplicate deadlines.")
        if not _GOOGLE_EVENT_ID_PATTERN.fullmatch(item.event_id):
            raise CalendarValidationError("An existing Google Calendar event ID is invalid.")
        result[item.deadline_id] = item
    return result


def _http_request(client: Any, method: str, url: str, **kwargs: Any) -> HttpResponse:
    try:
        request = getattr(client, "request", None)
        if callable(request):
            return request(method, url, **kwargs)
        operation = getattr(client, method.lower())
        return operation(url, **kwargs)
    except CalendarProviderError:
        raise
    except Exception as exc:
        raise CalendarProviderError("The Google Calendar request could not be completed.") from exc


def _event_endpoint(calendar_id: str, event_id: str | None = None) -> str:
    base = f"{GOOGLE_CALENDAR_API_ROOT}/calendars/{quote(calendar_id, safe='')}/events"
    return f"{base}/{quote(event_id, safe='')}" if event_id else base


def _event_response(response: HttpResponse, operation: str) -> dict[str, Any]:
    return _checked_payload(response, operation)


def _sync_one_event(
    *,
    client: Any,
    access_token: str,
    calendar_id: str,
    deadline: CalendarDeadline,
    payload: dict[str, Any],
    payload_hash: str,
    existing: ExistingCalendarEvent | None,
) -> CalendarSyncItem:
    event_id = existing.event_id if existing else str(payload["id"])
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    # ``attendees`` is always explicit, including ``[]`` when guests are being
    # removed.  ``sendUpdates=all`` lets Google notify removed guests as well as
    # newly invited ones; it is harmless when the array is already empty.
    params = {"sendUpdates": "all"}
    if existing and existing.payload_hash == payload_hash:
        return CalendarSyncItem(
            deadline_id=deadline.id,
            status="UNCHANGED",
            event_id=event_id,
            event_link=existing.event_link,
            payload_hash=payload_hash,
        )

    if existing:
        patch_payload = {key: value for key, value in payload.items() if key != "id"}
        response = _http_request(
            client,
            "PATCH",
            _event_endpoint(calendar_id, event_id),
            headers=headers,
            params=params,
            json=patch_payload,
            timeout=20,
        )
        if response.status_code == 404:
            existing = None
        else:
            result = _event_response(response, "Google Calendar event update")
            return CalendarSyncItem(
                deadline_id=deadline.id,
                status="UPDATED",
                event_id=str(result.get("id") or event_id),
                event_link=_safe_event_link(result.get("htmlLink")),
                payload_hash=payload_hash,
            )

    response = _http_request(
        client,
        "POST",
        _event_endpoint(calendar_id),
        headers=headers,
        params=params,
        json=payload,
        timeout=20,
    )
    if response.status_code != 409:
        result = _event_response(response, "Google Calendar event creation")
        return CalendarSyncItem(
            deadline_id=deadline.id,
            status="CREATED",
            event_id=str(result.get("id") or payload["id"]),
            event_link=_safe_event_link(result.get("htmlLink")),
            payload_hash=payload_hash,
        )

    # A deterministic ID makes retry-after-crash safe. Verify ownership before updating a 409.
    event_id = str(payload["id"])
    current_response = _http_request(
        client,
        "GET",
        _event_endpoint(calendar_id, event_id),
        headers=headers,
        timeout=20,
    )
    current = _event_response(current_response, "Google Calendar event recovery")
    extended = current.get("extendedProperties")
    private = extended.get("private", {}) if isinstance(extended, Mapping) else {}
    expected_private = payload["extendedProperties"]["private"]
    if not isinstance(private, Mapping) or any(
        private.get(key) != expected_private[key]
        for key in ("bidopsAnalysisId", "bidopsDeadlineId")
    ):
        raise CalendarProviderError(
            "The deterministic Google event ID is already in use.", code="id_collision"
        )
    patch_payload = {key: value for key, value in payload.items() if key != "id"}
    updated_response = _http_request(
        client,
        "PATCH",
        _event_endpoint(calendar_id, event_id),
        headers=headers,
        params=params,
        json=patch_payload,
        timeout=20,
    )
    updated = _event_response(updated_response, "Google Calendar event recovery update")
    return CalendarSyncItem(
        deadline_id=deadline.id,
        status="UPDATED",
        event_id=str(updated.get("id") or event_id),
        event_link=_safe_event_link(updated.get("htmlLink")),
        payload_hash=payload_hash,
    )


def sync_google_calendar_batch(
    deadlines: Sequence[CalendarDeadline | Mapping[str, Any] | Any],
    request: CalendarSyncRequest | Mapping[str, Any],
    *,
    analysis_id: str,
    access_token: str | SecretStr,
    existing_events: Mapping[str, ExistingCalendarEvent | Mapping[str, Any]]
    | Sequence[ExistingCalendarEvent | Mapping[str, Any]]
    | None = None,
    deadline_settings: Mapping[str, CalendarDeadlineSettings | Mapping[str, Any]]
    | None = None,
    client: HttpClient | None = None,
) -> CalendarSyncResponse:
    try:
        if isinstance(request, CalendarSyncRequest):
            sync_request = request
        elif isinstance(request, Mapping):
            sync_request = CalendarSyncRequest.model_validate(request)
        elif hasattr(request, "model_dump"):
            sync_request = CalendarSyncRequest.model_validate(request.model_dump(mode="python"))
        else:
            raise CalendarValidationError("Calendar sync request has an unsupported shape.")
    except ValidationError as exc:
        raise CalendarValidationError("Calendar sync request failed validation.") from exc
    token = _secret(access_token)
    if not token or len(token) > 16_384 or any(
        ord(character) < 32 or ord(character) == 127 for character in token
    ):
        raise CalendarValidationError("A valid Google access token is required.")

    deadline_rows = [from_analysis_deadline(item) for item in deadlines]
    if len({item.id for item in deadline_rows}) != len(deadline_rows):
        raise CalendarValidationError("Deadline data contains duplicate IDs.")
    deadline_by_id = {item.id: item for item in deadline_rows}
    override_by_id = {item.deadline_id: item for item in sync_request.deadline_overrides}
    unexpected_overrides = set(override_by_id) - set(sync_request.deadline_ids)
    if unexpected_overrides:
        raise CalendarValidationError("A deadline override does not match a selected deadline.")
    existing_by_id = _existing_event_map(existing_events)
    try:
        settings_by_id = {
            deadline_id: (
                value
                if isinstance(value, CalendarDeadlineSettings)
                else CalendarDeadlineSettings.model_validate(value)
            )
            for deadline_id, value in (deadline_settings or {}).items()
        }
    except ValidationError as exc:
        raise CalendarValidationError("Per-deadline calendar settings failed validation.") from exc
    unexpected_settings = set(settings_by_id) - set(sync_request.deadline_ids)
    if unexpected_settings:
        raise CalendarValidationError(
            "Per-deadline calendar settings do not match a selected deadline."
        )

    owned = client is None
    http = client or _owned_http_client()
    results: list[CalendarSyncItem] = []
    try:
        for deadline_id in sync_request.deadline_ids:
            source_deadline = deadline_by_id.get(deadline_id)
            if source_deadline is None:
                results.append(
                    CalendarSyncItem(
                        deadline_id=deadline_id,
                        status="SKIPPED",
                        error="The selected deadline does not exist in this analysis.",
                    )
                )
                continue
            override = override_by_id.get(deadline_id)
            try:
                deadline = _apply_deadline_override(source_deadline, override)
                effective_settings = settings_by_id.get(deadline_id)
                if effective_settings is not None:
                    reminders = effective_settings.reminders
                elif override and override.reminders is not None:
                    reminders = override.reminders
                elif override and override.reminder_minutes is not None:
                    reminders = [
                        ReminderOverride(method="popup", minutes=value)
                        for value in override.reminder_minutes
                    ]
                else:
                    reminders = sync_request.effective_reminders()
                if effective_settings is not None:
                    attendees = effective_settings.attendees
                else:
                    attendees = (
                        override.attendees
                        if override and override.attendees is not None
                        else sync_request.attendees
                    )
                payload = build_google_event_payload(
                    deadline,
                    analysis_id=analysis_id,
                    reminders=reminders,
                    attendees=attendees,
                )
                payload_hash = google_event_payload_hash(payload)
                results.append(
                    _sync_one_event(
                        client=http,
                        access_token=token,
                        calendar_id=sync_request.calendar_id,
                        deadline=deadline,
                        payload=payload,
                        payload_hash=payload_hash,
                        existing=existing_by_id.get(deadline_id),
                    )
                )
            except CalendarValidationError as exc:
                results.append(
                    CalendarSyncItem(
                        deadline_id=deadline_id,
                        status="SKIPPED",
                        error=str(exc),
                    )
                )
            except CalendarProviderError as exc:
                results.append(
                    CalendarSyncItem(
                        deadline_id=deadline_id,
                        status="FAILED",
                        event_id=(
                            existing_by_id[deadline_id].event_id
                            if deadline_id in existing_by_id
                            else None
                        ),
                        error=str(exc),
                    )
                )
    finally:
        if owned:
            http.close()

    successful = sum(item.status in {"CREATED", "UPDATED", "UNCHANGED"} for item in results)
    unsuccessful = len(results) - successful
    overall = "COMPLETE" if not unsuccessful else "FAILED" if not successful else "PARTIAL"
    return CalendarSyncResponse(
        status=overall,
        calendar_id=sync_request.calendar_id,
        results=results,
    )
