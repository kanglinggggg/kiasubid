"""Serialization helpers for persisted Startup Studio state."""

from typing import Any

from app.models import StartupAnalysisJob, StartupProposalSession, StartupTenderAnalysis


def analysis_job_payload(job: StartupAnalysisJob) -> dict[str, Any]:
    error = None
    if job.error_code or job.error_message:
        error = {
            "code": job.error_code or "ANALYSIS_FAILED",
            "message": job.error_message or "The analysis could not be completed.",
        }
    return {
        "id": job.id,
        "status": job.status,
        "stage": job.stage,
        "progress": job.progress,
        "analysis_id": job.analysis_id,
        "error": error,
        "created_at": job.created_at,
        "updated_at": job.updated_at,
    }


def tender_analysis_payload(analysis: StartupTenderAnalysis) -> dict[str, Any]:
    payload = dict(analysis.result_payload)
    payload.update(
        {
            "id": analysis.id,
            "mode": analysis.provider_mode,
            "model_id": analysis.model_id,
            "document": {
                "filename": analysis.filename,
                "media_type": analysis.media_type,
                "page_count": analysis.page_count,
                "character_count": analysis.character_count,
                "sha256": analysis.document_sha256,
                "scanned_pages": analysis.scanned_pages,
            },
            "metrics": {
                "model_calls": analysis.model_calls,
                "attempts": analysis.attempts,
                "duration_ms": analysis.duration_ms,
                "input_tokens": analysis.input_tokens,
                "output_tokens": analysis.output_tokens,
                "total_tokens": analysis.total_tokens,
            },
            "warnings": list(dict.fromkeys([*payload.get("warnings", []), *analysis.warnings])),
            "created_at": analysis.created_at,
        }
    )
    return payload


def proposal_session_payload(session: StartupProposalSession) -> dict[str, Any]:
    answered = len(session.answers)
    total = len(session.questions)
    current_question = (
        session.questions[session.current_index]
        if session.current_index < len(session.questions)
        else None
    )
    return {
        "id": session.id,
        "analysis_id": session.analysis_id,
        "company_name": session.company_name,
        "solution_name": session.solution_name,
        "status": session.status,
        "revision": session.revision,
        "progress": {
            "answered": answered,
            "total": total,
            "percent": round(answered / total * 100) if total else 0,
        },
        "current_question": current_question,
        "questions": session.questions,
        "answers": session.answers,
        "last_feedback": session.last_feedback,
        "draft": session.draft,
        "mode": session.provider_mode,
        "model_id": session.model_id,
        "created_at": session.created_at,
        "updated_at": session.updated_at,
    }
