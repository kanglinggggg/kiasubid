"""Deterministic bid-control services."""
