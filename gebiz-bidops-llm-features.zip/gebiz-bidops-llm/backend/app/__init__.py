"""GeBIZ BidOps backend."""
