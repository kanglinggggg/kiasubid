"""Synthetic demo fixtures."""
