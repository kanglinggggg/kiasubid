# GeBIZ BidOps

> Know the moment your bid stops being safe.

GeBIZ BidOps is a supplier-side bid preparation and control layer for Singapore SMEs. It turns
tender documents, obligations, company evidence, assessments, tasks, and tender changes into
persistent working state. It does not replace GeBIZ, submit a bid, or make a commercial
bid/no-bid decision.

The application has two workspaces. **SME Control Room** demonstrates the stateful corrigendum and
recovery workflow. **Startup Studio** accepts a real PDF, DOCX, TXT, or Markdown tender, explains
it in plain English with source references, guides a team through a proposal draft, and turns
reviewed deadlines into Google Calendar events or a downloadable `.ics` calendar.

## Product

The hard part of tendering starts after opportunity discovery. Small bid teams must continually answer:

- Which mandatory obligations are verified?
- What evidence supports each conclusion, and is it still valid?
- What changed after an amendment?
- Which earlier assessments are now unsafe?
- Can a newly discovered gap still be recovered before closing?

BidOps models this as:

```text
Requirement → Evidence → Assessment → Change → Impact → Recovery Action
```

Operational feasibility uses four explicit states: `FEASIBLE`, `RECOVERABLE`, `BLOCKED`, and `UNCERTAIN`. Submission Coverage is tracked independently and never overrides a broken mandatory gate.

The exact implemented formulas, precedence, thresholds, and API trace fields are documented in [Deterministic calculation rules](docs/CALCULATION_RULES.md). The current runtime AI boundary is documented in [Current AI boundary](docs/AI_BOUNDARY.md).

## Why this is more than a chatbot

BidOps does not answer a prompt and stop. A corrigendum moves through a stateful workflow that
updates the bid record, rechecks evidence, and leaves the final decision with the team:

```text
Persistent bid state
+ change event
+ semantic impact interpretation
+ evidence retrieval
+ deterministic re-verification
+ dependency-aware replanning
+ human checkpoint
```

LangGraph coordinates the steps. Bedrock handles the language comparison; ordinary code handles
numeric thresholds, certification validity, version history, critical gates, task dependencies,
coverage, and deadline slack. The main synthetic fixture also has a built-in interpretation, so the
Control Room demo remains reliable without cloud credentials while still creating the same
persisted state changes. Startup Studio does **not** use that fixture-specific fallback: document
analysis and proposal generation require a configured Bedrock or Groq model and fail visibly if
the provider is unavailable.

## Architecture

```mermaid
flowchart TD
    A[Uploaded tender] --> B[Safe text extraction]
    B --> C[Grounded LLM analysis]
    C --> D[Checklist and deadlines]
    D --> E[Proposal mentor]
    D --> F[Calendar review and sync]

    G[Tender / Corrigendum] --> H[Validated interpretation]
    H --> I[LangGraph control workflow]
    I --> J[Rules, evidence and recovery]
    J --> K[(SQLite state)]
```

### Project layout

```text
backend/app/
  demo/          synthetic company, tender, evidence, and assessments
  graph/         typed LangGraph state and corrigendum workflow
  llm/           Bedrock/Groq clients and strict structured-output validation
  rules/         typed reusable procurement rules and deterministic evaluators
  services/      assessment, feasibility, coverage, and deadline rules
  startup/       document analysis, proposal mentor, and calendar integration
  database.py    SQLite engine and session lifecycle
  models.py      SQLAlchemy domain entities
  main.py        FastAPI endpoints
  serializers.py bid control-room read model

frontend/src/
  api/           typed API client
  components/    metrics, requirement control, detail, activity drawer
  types/         shared frontend contract
  views/         SME Control Room and Startup Studio workflows
  App.tsx        workspace shell
```

## Setup

Prerequisites: Node.js 20+ and [`uv`](https://docs.astral.sh/uv/). `uv` will provision a compatible Python runtime when needed.

### One-command local start

From PowerShell:

```powershell
cd C:\GeBIZ
powershell -ExecutionPolicy Bypass -File .\scripts\start.ps1
```

This creates `.env` when absent, installs locked Python and Node dependencies, starts FastAPI and
Vite in the background, waits for both health checks, and writes logs under `data/logs/`. Open
`http://127.0.0.1:5173`.

For later starts without reinstalling dependencies:

```powershell
.\scripts\start.ps1 -SkipInstall
```

Stop only the processes recorded by the startup script:

```powershell
.\scripts\stop.ps1
```

### Backend

```powershell
cd C:\GeBIZ
uv sync
uv run uvicorn app.main:app --app-dir backend --reload
```

The API runs at `http://127.0.0.1:8000`; interactive API documentation is at `/docs`. SQLite is created at `data/bidops.db`.

### Frontend

```powershell
cd C:\GeBIZ\frontend
npm install
npm run dev
```

Open `http://127.0.0.1:5173`. Vite proxies `/api` to FastAPI.

`DEMO_MODE=true` keeps the synthetic scenario and demo clock deterministic. The hackathon region
is fixed to `AWS_DEFAULT_REGION=us-east-1`. AWS secret fields are intentionally blank: once the
lease is active, either set `AWS_PROFILE`, or place the temporary `AWS_ACCESS_KEY_ID`,
`AWS_SECRET_ACCESS_KEY`, and `AWS_SESSION_TOKEN` in the ignored local `.env`; then set an accessible
`BEDROCK_MODEL_ID` and leave `LLM_PROVIDER=bedrock`. Temporary lease credentials expire roughly
every 12 hours. No code change is required.

After lease approval and after placing temporary credentials plus an explicit cheap on-demand
model ID in `.env`, run the guarded AWS validation:

```powershell
cd C:\GeBIZ
powershell -ExecutionPolicy Bypass -File .\scripts\validate-aws-post-approval.ps1
```

It verifies STS and `us-east-1`, lists only discovered Nova Micro/Lite or Claude Haiku on-demand
candidates, rejects provisioned model identifiers, runs a minimal validated interpretation, proves
the live Bedrock-to-R17-to-`RECOVERABLE` path, and runs the known live-model regression. If the
temporary credentials have expired, refresh them locally and rerun; the script never prints them.

Use `BEDROCK_STRUCTURED_OUTPUT=true` only with a model that actually supports Bedrock's native
`outputConfig` JSON Schema feature. For compatible on-demand models such as the sandbox's Nova Lite
v1, `BEDROCK_STRUCTURED_OUTPUT=false` supplies the schema in the untrusted-data-safe prompt and
still requires strict local Pydantic and exact-provenance validation. Reports distinguish these
modes; prompted JSON must not be described as Bedrock-native constrained decoding.

For Groq, set `LLM_PROVIDER=groq`, `GROQ_API_KEY`, and either
`GROQ_MODEL_ID` or its supported alias `GROQ_MODEL`. Model IDs are never guessed. With no valid
selected-provider configuration, or when a provider call fails, the built-in demo interpretation
is used only by the narrow synthetic Control Room scenario. Startup Studio returns a clear error
instead of manufacturing an analysis or proposal. The UI displays Bedrock or Groq only after that
provider actually produced and persisted the result; otherwise the Control Room displays Demo
fallback.

The default Startup Studio limits are a 30 MiB upload, 750 pages, three million extracted
characters, and 28,000-character analysis chunks. They can be adjusted with the `STARTUP_*`
variables in `.env.example`. Machine-readable PDF, DOCX, UTF-8/UTF-16 TXT, and Markdown files are
accepted. Image-only/scanned PDFs need OCR before upload.

### Optional Google Calendar connection

Calendar file export works without credentials. For one-click Google Calendar sync, enable the
Google Calendar API in a Google Cloud project, create a Web application OAuth client, and register
this redirect URI **exactly**:

```text
http://127.0.0.1:8000/api/startup/calendar/google/callback
```

Then generate a long random application secret and set `APP_SECRET_KEY`, `GOOGLE_CLIENT_ID`,
`GOOGLE_CLIENT_SECRET`, and `GOOGLE_REDIRECT_URI` in the ignored local `.env`. Keep
`CALENDAR_COOKIE_SECURE=false` for local HTTP only; use HTTPS and set it to `true` in production.
The integration requests the `calendar.events` scope. Calendar access and refresh tokens are
encrypted at rest with a key derived from `APP_SECRET_KEY`.

## Startup Studio

1. Configure a live Bedrock or Groq provider and select **Startup Studio** in the header.
2. Upload a supported tender. The backend extracts bounded text and runs chunked analysis as a
   persisted asynchronous job, so the browser polls progress instead of holding a long request.
3. Review the plain-English overview, requested product capabilities, delivery phases, payment
   milestones, eligibility rules, risks, glossary, and action checklist. Each extracted claim keeps
   its page/section/snippet provenance where the source format provides it.
4. Start the proposal mentor, answer its questions conversationally, review the critique and
   formalised answer after each turn, then generate the sectioned Markdown draft.
5. Review every extracted date. Correct or confirm uncertain dates before syncing selected items
   to Google Calendar, or download the `.ics` file and import it into another calendar.

The output is preparation assistance, not legal advice. Extraction can miss tables, unusual
layouts, implied obligations, or dates; low-confidence and unresolved dates stay marked for human
review. See the [Startup Studio guide](docs/STARTUP_STUDIO.md) and
[runtime AI boundary](docs/AI_BOUNDARY.md).

## Demo

1. Open the Bid Control Room. Confirm `FEASIBLE`, `8 / 8` Critical Gates, `91%` Submission Coverage, and `LOW` Deadline Risk.
2. Select R17. Show three verified CISSP personnel sets and source traceability to Technical Specification page 17, section 4.3.
3. Click **Apply Corrigendum #2**. This calls the FastAPI endpoint and runs the LangGraph workflow.
4. Show R17 v2: the minimum changes from three to four, while the v1 assessment remains visible as `SUPERSEDED`.
5. Show the state transition to `RECOVERABLE` and `7 / 8` Critical Gates.
6. Show Engineer D: CISSP is verified, CV is stale, and availability is unknown. The requirement correctly remains `PARTIAL`.
7. Show the four recovery tasks, their dependencies, the verification deadline, and the impact chain.
8. Open **Audit trail** to show the recorded events from document parsing through status recomputation.
9. Point out the locked human checkpoint. BidOps never submits to GeBIZ.
10. Click the reset icon to replay the demonstration.

### Demo reset

The header reset control returns the application to the baseline `FEASIBLE / 8 of 8 / 91% /
LOW` state. The equivalent copy-paste command is:

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8000/api/demo/reset
```

## API

The primary Control Room endpoints are:

```text
GET  /api/bids/BID-DEMO-001
POST /api/tenders/interpret-requirements
POST /api/corrigenda/interpret-change
POST /api/demo/reset
POST /api/demo/bids/BID-DEMO-001/apply-corrigendum
POST /api/tasks/{task_id}/complete
POST /api/evidence/{evidence_id}/verify
POST /api/bids/BID-DEMO-001/human-approve
```

The two interpretation endpoints return validated structured objects without mutating bid state. Applying the same corrigendum twice returns `409 Conflict`; unmatched, ambiguous, or unsafe changes return useful `422` errors before an assessment is superseded.

Startup Studio exposes:

```text
POST   /api/startup/analysis-jobs?filename={name}&timezone={IANA zone}
GET    /api/startup/analysis-jobs/{job_id}
GET    /api/startup/analyses/{analysis_id}

POST   /api/startup/proposal-sessions
GET    /api/startup/proposal-sessions/{session_id}
POST   /api/startup/proposal-sessions/{session_id}/answers
POST   /api/startup/proposal-sessions/{session_id}/generate

GET    /api/startup/calendar/status
GET    /api/startup/calendar/google/authorize
GET    /api/startup/calendar/google/callback
DELETE /api/startup/calendar/connection
GET    /api/startup/analyses/{analysis_id}/calendar.ics
POST   /api/startup/analyses/{analysis_id}/calendar/sync
```

The analysis upload is the file bytes as the request body, with the original filename and IANA
timezone in the query string. Creation returns an asynchronous job; poll it until `COMPLETED` or
`FAILED`, then retrieve `analysis_id`. Proposal writes use a revision number to reject stale browser
state. Calendar sync requires an OAuth connection and accepts selected, resolved deadlines; the
`.ics` endpoint is the credential-free export path. Full request/response notes are in the
[Startup Studio guide](docs/STARTUP_STUDIO.md), and FastAPI serves the generated schema at `/docs`.

## Testing

```powershell
cd C:\GeBIZ
powershell -ExecutionPolicy Bypass -File .\scripts\check.ps1
```

This runs Ruff, all backend tests, frontend tests, the TypeScript/Vite production build, and the
deterministic external benchmark. Add `-RunLiveEvaluation` only after configuring an authorized
live provider.

Run only the GeBIZ-derived deterministic regression benchmark:

```powershell
cd C:\GeBIZ\backend
..\.venv\Scripts\python.exe -m evaluation.rule_runner --output ..\data\evaluation\deterministic_report.json
```

To add a deterministic regression case, place one schema-valid JSON object (or array) in
`backend/evaluation/rule_cases/`, then run the command above. The loader discovers JSON files
without production-code changes. Keep expected answers only in the benchmark record; they are not
sent to an LLM. The existing nine cases are known regression cases.

For genuinely unseen live interpretation, have a teammate freeze case JSON under
`backend/evaluation/cases/blind/`, then run:

```powershell
cd C:\GeBIZ
powershell -ExecutionPolicy Bypass -File .\scripts\run-blind-evaluation.ps1
```

The blind report separates requirement interpretation, corrigendum matching, ambiguity handling,
and final operational-state accuracy, and flags unsafe-green errors where a ground-truth
`BLOCKED`/`UNCERTAIN` case became `FEASIBLE`. Expected answers and deterministic facts are never
included in model inputs. Copy
`backend/evaluation/cases/blind/CASE_TEMPLATE.json.example` to a `.json` filename to add a case;
one facts object supports a single rule and an array supports multi-obligation passages. The
repository currently contains eight teammate-supplied cases that were frozen before their first
successful model run. Nova Lite scored 2/8 exact requirement interpretations, 7/8 ambiguity
decisions, and 4/8 final operational states, with zero unsafe-green errors. These results are
retained without tuning production prompts against the answer key.

That eight-case folder is now the observed **blind v1** set. It is retained as historical first-run
evidence and is not used for prompt or model selection. For the next genuinely unseen evaluation,
a teammate must place sealed cases under `backend/evaluation/cases/blind_v2/` and run:

```powershell
cd C:\GeBIZ
powershell -ExecutionPolicy Bypass -File .\scripts\run-blind-v2-evaluation.ps1
```

The blind-v2 command refuses to run while the folder has no `.json` cases. The repository does not
manufacture unseen ground truth or a performance claim.

The backend suite covers Bedrock- and Groq-shaped provider boundaries, exact source validation,
prompt-injection defenses, ambiguity, equivalent paraphrases, removal, deadline-only isolation,
malformed output retry/failure, the natural-language R17 transition, immutable version history,
evidence gaps, recovery dependencies, deterministic coverage, duplicate amendments, and explicit
`BLOCKED` and `UNCERTAIN` branches. Frontend tests verify the hero state, truthful provider label,
and backend-unavailable failure state.

Authorized external benchmark cases can be added as normalized JSON without changing Python test code. See [the benchmark harness guide](backend/tests/benchmarks/README.md).

Live interpretation evaluation is separate from those deterministic benchmarks. Known
GeBIZ-derived cases live under `backend/evaluation/cases/regression/`; development fixtures live
under `backend/evaluation/cases/development/`; genuinely unseen teammate cases belong only under
`backend/evaluation/cases/blind_v2/`. The live runner disables fallback and writes a
failure-classified JSON report with exact field differences, rule/fact bindings, attempts,
latency, and token usage. See [the interpretation evaluation guide](backend/evaluation/README.md).

To compare cheap Bedrock models without touching blind cases, run the fixed-prompt known-regression
bake-off:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run-bedrock-model-bakeoff.ps1
```

The current comparison retained `amazon.nova-lite-v1:0`: it outperformed Nova Micro v1 and the
Nova 2 Lite system inference profile on the same nine known regression cases.

Competition material: [Judge Q&A](docs/JUDGE_QA.md), [Demo runbook](docs/DEMO_RUNBOOK.md),
[Demo video script](docs/DEMO_VIDEO_SCRIPT.md), and [Pitch assets](docs/PITCH_ASSETS.md).

## Synthetic data

All company, employee, tender, evidence, project, and corrigendum data is fictional. NexusFort Technologies Pte. Ltd., Demo Government Agency, document references, certification identifiers, and project records exist only for this demonstration. The tender language is original synthetic text.

## Safety and human control

BidOps supports internal preparation and operational verification. It does not claim legal
certainty, sign declarations, make commercial decisions, fabricate GeBIZ integrations, or submit
tenders. Startup Studio drafts and calendar dates must be reviewed against the original tender;
final interpretation and submission remain the supplier's responsibility.

## Known limitations

- The bundled Control Room tender, company, evidence, and corrigendum are synthetic demo data;
  there is no GeBIZ connection or automatic submission path.
- Startup Studio accepts PDF, DOCX, TXT, and Markdown uploads, but it does not perform OCR. Scanned
  or image-only PDFs must be OCR-processed before upload. Complex tables, diagrams, headers,
  footnotes, and unusual reading order can be extracted imperfectly.
- Startup Studio's plain-English analysis, questions, critiques, and proposal draft are generated
  by the configured model. Grounding and schema checks reduce invention but cannot prove legal or
  procurement correctness. It never auto-submits a response.
- Google Calendar reminders are convenience notifications, not a guaranteed escalation service.
  Delivery depends on Google and each attendee's calendar settings. Teams should keep their own
  deadline controls.
- Live Bedrock validation uses `amazon.nova-lite-v1:0` in `us-east-1`. The R17 demo change
  passed. The final known-regression run scored 6/7 exact requirement interpretations, 2/2
  corrigendum matches, 9/9 ambiguity decisions, and 8/9 final operational states. The frozen
  eight-case blind-v1 set scored 2/8, not applicable, 7/8, and 4/8 respectively, with zero
  unsafe-green errors on its historical first run; it was not rerun or used for this round's
  selection. Native JSON-schema output with Claude Haiku 4.5 remains unavailable because
  the sandbox role lacks
  `aws-marketplace:ViewSubscriptions` and `aws-marketplace:Subscribe`; Nova Lite uses prompted JSON
  plus strict local validation.
- The nine structured GeBIZ-derived cases are a deterministic regression set that informed
  development, not an unseen-AI accuracy claim.
- SQLite is appropriate for the local single-user demonstration, not a multi-user production
  deployment. The browser-scoped Calendar connection is also a local-demo identity boundary; a
  production service needs real user authentication, authorization, secret management, retention
  controls, and a multi-user database.
